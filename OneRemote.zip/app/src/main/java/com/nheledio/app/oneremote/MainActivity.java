package com.nheledio.app.oneremote;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.SoundEffectConstants;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.nheledio.app.oneremote.Adapter.EmptyAdapter;
import com.nheledio.app.oneremote.Adapter.SelectCategoryAdapter;
import com.nheledio.app.oneremote.Adapter.SelectRemoteAdapter;
import com.nheledio.app.oneremote.MainActivity;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.SettingsActivity;
import com.nheledio.app.oneremote.UI.Snackbar;
import com.nheledio.app.oneremote.UI.SwipeRecyclerViewTouchListener;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.DayNightModeHelper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import android.util.TypedValue;
import android.content.res.TypedArray;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
	
	private Toolbar mToolbar;
	private ImageView mToolbarButton1;
	private ImageView mToolbarButton2;
	
	private CoordinatorLayout mMainLayout;
	private BottomSheetBehavior mBottomSheetBehavior;
	private ImageView mImageEmpty;
	private SwipeRefreshLayout mSwipeReferesh;
	private SwipeRecyclerViewTouchListener mSwipeRecyclerView;
    
	private RecyclerView mRemoteRecyclerView;
	private SelectRemoteAdapter mSelectAdapter;
    
	private LinkedHashMap mRemoteCategory;
	private ArrayList mRemoteSavedList;
	
    private boolean mIsBottomExpanded = false;
	private boolean mIsDoublePressed = false;
	
	private int mRemoteCount = 0;
    private int mDayNightState;
	
	private SharedPreferences mPreferences;
  
    @Override
    protected void onCreate(Bundle savedInstanceState) {
  
        Initialize();
		super.onCreate(savedInstanceState);
		
        setContentView(R.layout.activity_main);
		InitToolbar();
		
		mPreferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
		mMainLayout = findViewById(R.id.activity_main_coord_layout);
		mImageEmpty = findViewById(R.id.activity_empty);
		mSwipeReferesh = findViewById(R.id.swipe_layout);
	
		mSwipeReferesh.setEnabled(true);
		mSwipeReferesh.setRefreshing(true);
		
		InitBottomSheet();
		InitSavedRemote();
    }

	@Override
	protected void onResume() {
		super.onResume();
		
		if(mBottomSheetBehavior != null) {
			if(mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
				mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
			}
		}
		
		if(GetAllRemoteFromPreference() != null) {
			if(mRemoteCount != GetAllRemoteFromPreference().size()) {
				RefreshRemoteList();
			}
		}
	    
		if(mPreferences.getBoolean(Constant.PREF_REMOTE_HAS_CHANGES, false)) {
			mPreferences.edit().putBoolean(Constant.PREF_REMOTE_HAS_CHANGES, false).apply();
			if(GetAllRemoteFromPreference() != null) {
				RefreshRemoteList();
			}
		}
        
        if(mDayNightState != DayNightModeHelper.createInstance().getDayNightSavedState(MainActivity.this)) {
            recreate();
            return;
        }
	}
	
	@Override
	public void onClick(View p1) {
		int id = p1.getId();
		
		switch(id) {
			case R.id.toolbar_button_1:
				if(mIsBottomExpanded) {
					mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
				} else {
					mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
				}
				break;
			case R.id.toolbar_button_2:
				Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
				intent.putExtra("mode", SettingsActivity.MODE_SETTINGS_GENERAL);
				startActivity(intent);
				break;
		}
	}

	@Override
	public void onBackPressed() {
		if (mIsDoublePressed && !mIsBottomExpanded) {
			finishAffinity();
			return;
		}
		
		if(mIsBottomExpanded) {
			mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
		} else {
			mIsDoublePressed = true;
			Toast.makeText(this, "Please Click Back Again To Exit.", Toast.LENGTH_SHORT).show();

			new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						mIsDoublePressed = false;
					}
				}, 2000);
		}
	}

	
	/*  */
	
	private void Initialize() {
        AppCompatDelegate.setDefaultNightMode(DayNightModeHelper.createInstance().getDayNightSavedState(MainActivity.this));
        mDayNightState = DayNightModeHelper.createInstance().getDayNightSavedState(MainActivity.this);
    }
	
	private void InitToolbar() {
		mToolbar = findViewById(R.id.toolbar_main);
		mToolbarButton1 = mToolbar.findViewById(R.id.toolbar_button_1);
		mToolbarButton2 = mToolbar.findViewById(R.id.toolbar_button_2);
		
		mToolbarButton1.setOnClickListener(this);
		mToolbarButton2.setOnClickListener(this);
		
        setSupportActionBar(mToolbar);
	}
	
	private void InitBottomSheet() {
		try {
            mRemoteCategory = GetRemoteCategoryList();
            mRemoteCategory.put("Custom", R.drawable.ic_add);

            RecyclerView mRecyclerView = findViewById(R.id.remote_recycler_view);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 3, GridLayoutManager.VERTICAL, false);
            mRecyclerView.setLayoutManager(gridLayoutManager);

            View mBottomSheet = findViewById(R.id.remote_bottom_sheet);
            mBottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet);
            mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            mBottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                    @Override
                    public void onStateChanged(@NonNull View bottomSheet, int newState) {
                        if(newState == BottomSheetBehavior.STATE_EXPANDED) {
                            mIsBottomExpanded = true;
                            //ObjectAnimator.ofFloat(mToolbarButton1, View.ALPHA, 0.2f, 1.0f).setDuration(300).start();
                            mToolbarButton1.setImageDrawable(getResources().getDrawable(R.drawable.ic_back));
                        } else {
                            mIsBottomExpanded = false;
                            //ObjectAnimator.ofFloat(mToolbarButton1, View.ALPHA, 0.2f, 1.0f).setDuration(300).start();
                            mToolbarButton1.setImageDrawable(getResources().getDrawable(R.drawable.ic_add));
                        }
                    }

                    @Override
                    public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                        //mToolbarButton1.setRotation(360f*slideOffset);
                    }
                });

            SelectCategoryAdapter mCategoryAdapter = new SelectCategoryAdapter(MainActivity.this, mRemoteCategory, mBottomSheetBehavior);
            mRecyclerView.setAdapter(mCategoryAdapter);
       
        } catch (IOException e) {} catch (XmlPullParserException e) {}
	}
	
	private void InitSavedRemote() {
		mRemoteSavedList = GetAllRemoteFromPreference();
		
		mRemoteRecyclerView = findViewById(R.id.save_recycler_view);

		LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this);
		mRemoteRecyclerView.setLayoutManager(linearLayoutManager);
		mRemoteRecyclerView.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
		mRemoteRecyclerView.setItemAnimator(new DefaultItemAnimator());
		mRemoteRecyclerView.addOnScrollListener(SwipeScrollListener);
		
		mSelectAdapter = new SelectRemoteAdapter(MainActivity.this, mRemoteSavedList);
		if(mRemoteSavedList != null) {
			mRemoteCount = mRemoteSavedList.size();
			
			if(mRemoteSavedList.size() > 0) {
				mRemoteRecyclerView.setAdapter(mSelectAdapter);
				mImageEmpty.setVisibility(View.GONE);
			} else {
				mRemoteRecyclerView.setAdapter(new EmptyAdapter());
				mImageEmpty.setVisibility(View.VISIBLE);
			}
		} else {
			mRemoteCount = 0;
			
			mRemoteRecyclerView.setAdapter(new EmptyAdapter());
			mImageEmpty.setVisibility(View.VISIBLE);
		}

		mSwipeRecyclerView = new SwipeRecyclerViewTouchListener(MainActivity.this, mRemoteRecyclerView);
		mSwipeRecyclerView.setClickable(new SwipeRecyclerViewTouchListener.OnRowClickListener() {
				@Override
				public void onRowClicked(int position) {
                    AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    audioManager.playSoundEffect(SoundEffectConstants.CLICK);
                    
					JSONObject jsonObj = new JSONObject((LinkedHashMap)mRemoteSavedList.get(position));

					Intent intent = new Intent(MainActivity.this, RemoteActivity.class);
					intent.putExtra("data", jsonObj.toString());
					intent.putExtra("mode", RemoteActivity.MODE_REMOTE);
					startActivity(intent);
				}

				@Override
				public void onIndependentViewClicked(int independentViewID, int position) {

				}
			});

		mSwipeRecyclerView.setSwipeOptionViews(R.id.save_list_delete, R.id.save_list_edit)
			.setSwipeable(R.id.save_list_row_fg, R.id.save_list_row_bg, new SwipeRecyclerViewTouchListener.OnSwipeOptionsClickListener() {
				@Override
				public void onSwipeOptionClicked(int viewID, int position) {
                    AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    audioManager.playSoundEffect(SoundEffectConstants.CLICK);
                    
					switch (viewID){
						case R.id.save_list_delete:
							RemoveRemoteToPreferences(position);
							break;
						case R.id.save_list_edit:
							JSONObject jsonObj = new JSONObject((LinkedHashMap)mRemoteSavedList.get(position));
							
							Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
							intent.putExtra("data", jsonObj.toString());
							intent.putExtra("index", position);
							intent.putExtra("mode", SettingsActivity.MODE_SETTINGS_REMOTE);
							startActivity(intent);
							break;
					}
				}
			});

		mRemoteRecyclerView.addOnItemTouchListener(mSwipeRecyclerView);

		mSwipeReferesh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
				@Override
				public void onRefresh() {
					RefreshRemoteList();
				}
			});
			
		new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					mSwipeReferesh.setRefreshing(false);
				}
			}, 500);
	}
    
    private ArrayList GetAllRemoteFromPreference() {
        ArrayList mList = null;

        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        Set<String> mSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));
        if(mSets != null) {
            if(mSets.size()>0) {
                mList = new ArrayList();

                for(String set: mSets) {
                    try {
                        JSONObject jsonObj = new JSONObject(set);
                        Iterator<String> keysItr = jsonObj.keys();
                        LinkedHashMap item = new LinkedHashMap();

                        while(keysItr.hasNext()) {
                            String key = keysItr.next().toString();
                            String value = jsonObj.get(key).toString();

                            item.put(key, value);
                        }

                        mList.add(item);
                    } catch (JSONException e) {
                        mList = new ArrayList();
                    }
                }
            }
        }

        if(mList != null) {
            if(mList.size() > 0) {
                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_name").toString().toLowerCase().compareTo(p2.get("save_name").toString().toLowerCase());
                        }
                    });

                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_category2").toString().toLowerCase().compareTo(p2.get("save_category2").toString().toLowerCase());
                        }
                    });
            }
        }

        return mList;
	}
	 
	private LinkedHashMap GetRemoteCategoryList() throws XmlPullParserException, IOException {
		LinkedHashMap mMapCategory = null;
        
        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        
        String file_path = Constant.ASSET_FILE_LAYOUT;
        InputStream inputStream = getAssets().open(file_path);
        mParser.setInput(inputStream, null);
        
        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote/oneremote_layout.dio");
        if(mPrefs.getBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false) && file.exists()) {
            BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
            mParser.setInput(buffReader);
        }
        
        int eventType = mParser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "category";
            String subTag = "item";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        mMapCategory = new LinkedHashMap();
                    } else if (element.equals(subTag)) {
                        String category = mParser.nextText();
                        mMapCategory.put(category, getRemoteCategoryResourceID(category));
                    }
                    break;
                case XmlPullParser.END_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) { 
                        return mMapCategory;
                    }
                    break;
            }

            eventType = mParser.next();
        }
		
		return mMapCategory;
    }
	
	private void RefreshRemoteList() {
		mRemoteSavedList = GetAllRemoteFromPreference();
		mSwipeReferesh.setRefreshing(true);
		
		mSelectAdapter = new SelectRemoteAdapter(MainActivity.this, mRemoteSavedList);
		if(mRemoteSavedList != null) {
			mRemoteCount = mRemoteSavedList.size();
			
			if(mRemoteSavedList.size() > 0) {
				mRemoteRecyclerView.setAdapter(mSelectAdapter);
				mSelectAdapter.notifyDataSetChanged();
				
				mImageEmpty.setVisibility(View.GONE);
			} else {
				mRemoteRecyclerView.setAdapter(new EmptyAdapter());
				mImageEmpty.setVisibility(View.VISIBLE);
			}
		} else {
			mRemoteCount = 0;
			
			mRemoteRecyclerView.setAdapter(new EmptyAdapter());
			mImageEmpty.setVisibility(View.VISIBLE);
		}
		
		new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					mSwipeReferesh.setRefreshing(false);
				}
			}, 500);
	}
	
	private void RemoveRemoteToPreferences(int position) {
		if(mBottomSheetBehavior != null) {
			if(mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
				mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
			}
		}
		
		final LinkedHashMap mBackup = (LinkedHashMap)mRemoteSavedList.get(position);
		
		mRemoteSavedList.remove(position);
		mSelectAdapter.notifyItemRemoved(position);
		mSelectAdapter.notifyItemRangeChanged(position, mRemoteSavedList.size());
		
		mRemoteCount = mRemoteSavedList.size();
		
		if(mRemoteSavedList.size() > 0) {
			mImageEmpty.setVisibility(View.GONE);
		} else {
			mImageEmpty.setVisibility(View.VISIBLE);
		}
		
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();

		Set<String> mNewSets = new HashSet();
		
		for(LinkedHashMap map: mRemoteSavedList) {
			JSONObject jsonObj = new JSONObject(map);
			mNewSets.add(jsonObj.toString());
		}
		
		editor.putStringSet(Constant.PREF_REMOTE_LIST, mNewSets);
		editor.apply();
		
		Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
		mSnackbar.setText(mBackup.get("save_name").toString()+" Remote Deleted.", getResources().getColor(R.color.white));
		mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_delete), getResources().getColor(R.color.white));
		mSnackbar.setAction("UNDO", new View.OnClickListener() {
				@Override
				public void onClick(View p1) {
					SaveRemoteToPreference(mBackup);
				}
			});
		mSnackbar.setSnackColor(getResources().getColor(R.color.red_500));
		mSnackbar.show();
	}
	
	private void SaveRemoteToPreference(LinkedHashMap remote) {
		if(remote != null) {
			JSONObject jsonObj = new JSONObject(remote);

			SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
			SharedPreferences.Editor editor = mPrefs.edit();

			Set<String> mSets = mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, null);
			Set<String> mNewSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));

			if(mNewSets == null) {
				mNewSets = new HashSet<>();
			}

			mNewSets.add(jsonObj.toString());

			editor.putStringSet(Constant.PREF_REMOTE_LIST, mNewSets);
			editor.apply();
			
			RefreshRemoteList();
		}
	}
	
	private RecyclerView.OnScrollListener SwipeScrollListener = new RecyclerView.OnScrollListener() {
		@Override
		public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
			LinearLayoutManager manager = ((LinearLayoutManager)recyclerView.getLayoutManager());
	
			if(manager.findFirstCompletelyVisibleItemPosition() == 0) {
				mSwipeReferesh.setEnabled(true);
			} else {
				mSwipeReferesh.setEnabled(false);
				
				if(mRemoteSavedList != null) {
					if(mRemoteSavedList.size() == 0) {
						mSwipeReferesh.setEnabled(true);
					} 
				} else {
					mSwipeReferesh.setEnabled(true);
				}
			}
		}
	}; 
    
    private int getRemoteCategoryResourceID(String category) {
        int res = R.drawable.ic_default;

        for(int i=0; i<Constant.REMOTE_CATEGORY_NAME.length; i++) {
            if(category.equalsIgnoreCase(Constant.REMOTE_CATEGORY_NAME[i])) {
                res = Constant.REMOTE_CATEGORY_ID[i];
            }
        }

        return res;
	}
}
