package com.nheledio.app.oneremote.Utils;

import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.nheledio.app.oneremote.R;
import androidx.appcompat.app.AppCompatDelegate;
import android.content.res.Configuration;
import androidx.appcompat.app.AppCompatActivity;

public class DayNightModeHelper {

    private static final String PREF_KEY = "DAYNIGHT_MODE";

    private static int mDayNightMode = AppCompatDelegate.MODE_NIGHT_NO;

    private Activity mActivity;
    private SharedPreferences mPreference;
    
    public static DayNightModeHelper instance = null;
    
    public static DayNightModeHelper createInstance() {
        if(instance == null) {
            instance = new DayNightModeHelper();
        }
        
        return instance;
    }
    
    public DayNightModeHelper() {}
    
    public DayNightModeHelper(Activity activity) {
        mActivity = activity;
        mPreference = PreferenceManager.getDefaultSharedPreferences(activity);
        mDayNightMode = mPreference.getInt(PREF_KEY, AppCompatDelegate.MODE_NIGHT_NO);  
    }
    
    public int getDayNightSavedState() {
        if(mActivity !=null) {
            mPreference = PreferenceManager.getDefaultSharedPreferences(mActivity);
            mDayNightMode = mPreference.getInt(PREF_KEY, AppCompatDelegate.MODE_NIGHT_NO);
        }
        
        return mDayNightMode;
    }
      
    public int getDayNightSavedState(Activity activity) {
        mPreference = PreferenceManager.getDefaultSharedPreferences(activity);
        mDayNightMode = mPreference.getInt(PREF_KEY, AppCompatDelegate.MODE_NIGHT_NO);
        
        return mDayNightMode;
    }
    
    public DayNightModeHelper setActivity(Activity activity) {
        mActivity = activity;
        
        mPreference = PreferenceManager.getDefaultSharedPreferences(activity);
        mDayNightMode = mPreference.getInt(PREF_KEY, AppCompatDelegate.MODE_NIGHT_NO);
        
        return this;
    }
    
    public DayNightModeHelper setDayNightState(int state) {
        mDayNightMode = state;
        if(mPreference != null) {
            mPreference.edit().putInt(PREF_KEY, state).commit();
        } 
        
        return this;
    }
    
    public DayNightModeHelper setDayNightState(Activity activity, int state) {
        mPreference = PreferenceManager.getDefaultSharedPreferences(activity);
        mDayNightMode = state;
        if(mPreference != null) {
            mPreference.edit().putInt(PREF_KEY, state).commit();
        } 

        return this;
    }
}
