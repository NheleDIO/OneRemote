package com.nheledio.app.oneremote;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.textfield.TextInputEditText;
import com.nheledio.app.oneremote.Adapter.SearchRemoteAdapter;
import com.nheledio.app.oneremote.SearchActivity;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.DayNightModeHelper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener {

	private Toolbar mToolbar;
	private ImageView mToolbarButton1;
	private TextInputEditText mToolbarEditText;
	
	private CoordinatorLayout mMainLayout;
	private ImageView mImage;
	private RecyclerView mRecyclerView;
	private SearchRemoteAdapter mSearchAdapter;
	
    private String mCategory;
	private ArrayList mRemoteList;
	private LinkedHashMap<String, Integer> mListIndex;
	
	private int mRemoteCount = 0;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {

		Initialize();
		super.onCreate(savedInstanceState);
		
        setContentView(R.layout.activity_search);
		
		InitData();
		mMainLayout = findViewById(R.id.activity_search_coord_layout);
		
        InitToolbar();
		InitSearch();
    }

	@Override
	protected void onResume() {
		super.onResume();
		
		if(GetAllRemoteFromPreference() != null) {
			if(mRemoteCount != GetAllRemoteFromPreference().size()) {
				onBackPressed();
			}
		} 
	}
	
	@Override
	public void onClick(View p1) {
		int id = p1.getId();

		switch(id) {
			case R.id.toolbar_button_1:
				onBackPressed();
				break;
			
		}
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}

	/*  */

	private void Initialize() {
        AppCompatDelegate.setDefaultNightMode(DayNightModeHelper.createInstance().getDayNightSavedState(SearchActivity.this));
    }
	
	private void InitData() {
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			mCategory = extras.getString("category");
		}
        
        if(GetAllRemoteFromPreference() != null) {
            mRemoteCount = GetAllRemoteFromPreference().size();
        } else {
            mRemoteCount = 0;
        }
	}

	private void InitToolbar() {
		mToolbar = findViewById(R.id.toolbar_search);
		mToolbarButton1 = mToolbar.findViewById(R.id.toolbar_button_1);
		mToolbarEditText = mToolbar.findViewById(R.id.toolbar_edittext);

		mImage = findViewById(R.id.activity_search);
		
		mToolbarButton1.setOnClickListener(this);
		mToolbarEditText.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
					if(mRecyclerView != null) {
						mSearchAdapter.getFilter().filter(mToolbarEditText.getText().toString());
					} 
				}

				@Override
				public void afterTextChanged(Editable p1) {}
			});

        setSupportActionBar(mToolbar);
	}
	
	private void InitSearch() {
		new AsyncTask<Void, Void, Void>() {
			@Override
			protected Void doInBackground(Void... params) {
				try {
                    mRemoteList = GetRemoteList();
					
					ArrayList mCustom = GetRemoteListCustom();
					if(mCustom != null) {
						mRemoteList.addAll(mCustom);
					}
					
                    Collections.sort(mRemoteList, new Comparator<LinkedHashMap>() {
                            @Override
                            public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                                return p1.get("name").toString().compareTo(p2.get("name").toString());
                            }
                        });

                    mListIndex = GetListIndex(mRemoteList);
                } catch (IOException e) {} catch (XmlPullParserException e) {}
                
				return null;
			}

			@Override
			protected void onPostExecute(Void aVoid) {
				if(mRemoteList.size()>0) {
					mRecyclerView = findViewById(R.id.search_recycler_view);
					mRecyclerView.setItemAnimator(new DefaultItemAnimator());
					mRecyclerView.setHasFixedSize(true);

					LinearLayoutManager linearLayoutManager = new LinearLayoutManager(SearchActivity.this);
					mRecyclerView.setLayoutManager(linearLayoutManager);

					mSearchAdapter = new SearchRemoteAdapter(SearchActivity.this, mRemoteList, mListIndex);
					mRecyclerView.setAdapter(mSearchAdapter);

					//FastScrollRecyclerViewItemDecoration decoration = new FastScrollRecyclerViewItemDecoration(SearchActivity.this);
					//mRecyclerView.addItemDecoration(decoration);

					mImage.setVisibility(View.GONE);
				} else {
					mImage.setVisibility(View.VISIBLE);
				}

				super.onPostExecute(aVoid);
			}
		}.execute();
	}
	
	private LinkedHashMap<String, Integer> GetListIndex(ArrayList items){
        LinkedHashMap<String, Integer> mapIndex = new LinkedHashMap<String, Integer>();
        for (int i = 0; i<items.size(); i++){
            String name = ((LinkedHashMap)items.get(i)).get("name").toString();
            String index = name.substring(0,1);
            index = index.toUpperCase();

            if (!mapIndex.containsKey(index)) {
                mapIndex.put(index, i);
            }
        }
        return mapIndex;
    }
	
	private ArrayList GetAllRemoteFromPreference() {
        ArrayList mList = null;

        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SearchActivity.this);

        Set<String> mSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));
        if(mSets != null) {
            if(mSets.size()>0) {
                mList = new ArrayList();

                for(String set: mSets) {
                    try {
                        JSONObject jsonObj = new JSONObject(set);
                        Iterator<String> keysItr = jsonObj.keys();
                        LinkedHashMap item = new LinkedHashMap();

                        while(keysItr.hasNext()) {
                            String key = keysItr.next().toString();
                            String value = jsonObj.get(key).toString();

                            item.put(key, value);
                        }

                        mList.add(item);
                    } catch (JSONException e) {
                        mList = new ArrayList();
                    }
                }
            }
        }

        if(mList != null) {
            if(mList.size() > 0) {
                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_name").toString().toLowerCase().compareTo(p2.get("save_name").toString().toLowerCase());
                        }
                    });

                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_category2").toString().toLowerCase().compareTo(p2.get("save_category2").toString().toLowerCase());
                        }
                    });
            }
        }

        return mList;
	}
    
    private ArrayList GetRemoteList() throws XmlPullParserException, IOException {
        ArrayList mList = new ArrayList();
        LinkedHashMap mMapRemote = null;

        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        String file_path = Constant.ASSET_FILE_CODES;
        InputStream inputStream = getAssets().open(file_path);
        mParser.setInput(inputStream, null);
        
        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SearchActivity.this);
        File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote/oneremote_codes.dio");
        if(mPrefs.getBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false) && file.exists()) {
            BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
            mParser.setInput(buffReader);
        }

        int eventType = mParser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "remote";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:
                    mList = new ArrayList();

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if (element.equals(tag)) {
                        mMapRemote = new LinkedHashMap<>();

                        mMapRemote.put("name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("category", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("configs", mParser.getAttributeValue(null, "configs"));

                        mMapRemote.put("save_name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("save_category1", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("save_config", 1);

                        if(mCategory.equalsIgnoreCase(mParser.getAttributeValue(null, "category"))) {
                            mList.add(mMapRemote);
                        }
                    } 
                    break;
                case XmlPullParser.END_TAG:

                    break;
            }

            eventType = mParser.next();
        }

        return mList;
    }
	
	private ArrayList GetRemoteListCustom() throws XmlPullParserException, IOException {
        ArrayList mList = new ArrayList();
        LinkedHashMap mMapRemote = null;

        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
        if(file.exists()) {
            BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
            mParser.setInput(buffReader);
        } else {
			return null;
		}

        int eventType = mParser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "remote";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:
                    mList = new ArrayList();

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if (element.equals(tag)) {
                        mMapRemote = new LinkedHashMap<>();

                        mMapRemote.put("name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("category", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("configs", mParser.getAttributeValue(null, "configs"));

                        mMapRemote.put("save_name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("save_category1", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("save_config", 1);

                        if(mCategory.equalsIgnoreCase(mParser.getAttributeValue(null, "category"))) {
                            mList.add(mMapRemote);
                        }
                    } 
                    break;
                case XmlPullParser.END_TAG:

                    break;
            }

            eventType = mParser.next();
        }

        return mList;
    }
}
