package com.nheledio.app.oneremote;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.nheledio.app.oneremote.Adapter.SelectLogoDialogAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.SettingsActivity;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.DayNightModeHelper;
import com.nheledio.app.oneremote.Utils.DownloadUtils;
import com.physicaloid.lib.Physicaloid.UploadCallBack;
import com.physicaloid.lib.programmer.avr.UploadErrors;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.ProgressDialog;
import android.hardware.usb.UsbManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import com.physicaloid.lib.Physicaloid;
import com.physicaloid.lib.Boards;
import java.io.IOException;
import com.nheledio.app.oneremote.UI.SeekBarWithEditText;
import android.graphics.drawable.ColorDrawable;
import com.nheledio.app.oneremote.UI.ZoomImageView;
import android.view.Window;
import android.view.WindowManager;
import android.view.Gravity;

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener {

	private Toolbar mToolbar;
	private ImageView mToolbarButton1;
	private ImageView mToolbarButton2;
	
    private int mDayNightState;
    
    private int mMode = 1;
	public static final int MODE_SETTINGS_GENERAL = 1;
	public static final int MODE_SETTINGS_REMOTE = 2;
	public static final int MODE_SETTINGS_ARDUINO = 3;
	
	private static final int TYPE_EDITTEXT = 1;
	private static final int TYPE_LOGO = 2;
	private static final int TYPE_DAYNIGHT = 3;
	private static final int TYPE_LIST = 4;
	
	private CoordinatorLayout mMainLayout;
	private LinearLayout mSettingsLayout;
	private LinkedHashMap mRemoteInfo;
	
	private int mLogoIndex = 0;
	private ArrayList mRemoteSavedList;
    
    private static final int PERMISSION_REQUEST_CODE = 1;
	
	private Physicaloid mPhysicaloid;
	
	private boolean mIsUSBAttached = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

		Initialize();
		super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_settings);
        
		InitData();
        mMainLayout = findViewById(R.id.activity_settings_coord_layout);
		mSettingsLayout = findViewById(R.id.settings_layout);
        
		InitToolbar();
		InitSettings();
    }

	@Override
	protected void onResume() {
		super.onResume();
       
	}

    @Override
    protected void onDestroy() {
        super.onDestroy();
        
    }

	@Override
	public void onClick(View p1) {
		int id = p1.getId();

		switch(id) {
			case R.id.toolbar_button_1:
				onBackPressed();
				break;

		}
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    GetAllRemoteResourcesOnline();
                } else {
                    AlertDialog.Builder alertBuild = new AlertDialog.Builder(SettingsActivity.this);
                    alertBuild.setTitle("Storage Permission");
                    alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Download Remote Configurations And Layouts.");
                    alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface p1, int p2) {
                                final Intent intent = new Intent();
                                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                intent.addCategory(Intent.CATEGORY_DEFAULT);
                                intent.setData(Uri.parse("package:" + getPackageName()));
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                                startActivity(intent);
                            }
                        });
                    alertBuild.setNegativeButton("Cancel", null);

                    AlertDialog alert = alertBuild.create();
                    alert.show();
                }
                break;
        }
	}

	/*  */

	private void Initialize() {
		AppCompatDelegate.setDefaultNightMode(DayNightModeHelper.createInstance().getDayNightSavedState(SettingsActivity.this));
        mDayNightState = DayNightModeHelper.createInstance().getDayNightSavedState(SettingsActivity.this);
    }

	private void InitData() {
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			mMode = extras.getInt("mode");
			
			if(mMode == MODE_SETTINGS_REMOTE) {
				String mData = extras.getString("data", null);
				if(mData != null) {
					mRemoteInfo = new LinkedHashMap();
					try {
						JSONObject jsonObj = new JSONObject(mData);
						Iterator iterator = jsonObj.keys();
                        
						while(iterator.hasNext()) {
							String key = iterator.next().toString();
							mRemoteInfo.put(key, jsonObj.get(key).toString());
						}
					} catch (JSONException e) {}
				}
			}
		}
	}

	private void InitToolbar() {
		mToolbar = findViewById(R.id.toolbar_search);
		mToolbarButton1 = mToolbar.findViewById(R.id.toolbar_button_1);
		mToolbarButton2 = mToolbar.findViewById(R.id.toolbar_button_2);

		mToolbarButton1.setOnClickListener(this);
		mToolbarButton2.setOnClickListener(this);

		mToolbarButton2.setVisibility(View.INVISIBLE);
		
        setSupportActionBar(mToolbar);
	}
	
	private void InitSettings() {
		if(mMode == MODE_SETTINGS_GENERAL) {
			View mBanner = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_banner, null);
			mSettingsLayout.addView(mBanner);
			
			View mPreference1 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout1 = mPreference1.findViewById(R.id.settings_list_layout);
			final TextView mTitle1 = mPreference1.findViewById(R.id.settings_list_title_text);
			final TextView mText1 = mPreference1.findViewById(R.id.settings_list_text);
			final TextView mSubtext1 = mPreference1.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck1 = mPreference1.findViewById(R.id.settings_list_checkbox);

			mTitle1.setText("General");
			
			switch(DayNightModeHelper.createInstance().getDayNightSavedState(SettingsActivity.this)) {
				case AppCompatDelegate.MODE_NIGHT_YES:
					mText1.setText("Dark");
					break;
				case AppCompatDelegate.MODE_NIGHT_NO:
					mText1.setText("Light");
					break;
			}
			
			mSubtext1.setText("Use Dark/Light Theme.");
			mCheck1.setVisibility(View.GONE);

			mLayout1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						ShowSettingsAlertDialog(TYPE_DAYNIGHT, "Theme", "", "", null, "", "", mText1, "", "");
					}
				});

			mSettingsLayout.addView(mPreference1);
            
            View mPreference4 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

            final FrameLayout mLayout4 = mPreference4.findViewById(R.id.settings_list_layout);
            final TextView mTitle4 = mPreference4.findViewById(R.id.settings_list_title_text);
            final TextView mText4 = mPreference4.findViewById(R.id.settings_list_text);
            final TextView mSubtext4 = mPreference4.findViewById(R.id.settings_list_subtext);
            final CheckBox mCheck4 = mPreference4.findViewById(R.id.settings_list_checkbox);

            mTitle4.setVisibility(View.GONE);
            mText4.setText("Resources");
            mSubtext4.setText("Download available Remote Resources.");
            mCheck4.setVisibility(View.GONE);

            mLayout4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        GetAllRemoteResourcesOnline();
                    }
                });

            mSettingsLayout.addView(mPreference4);
			
			View mPreference2 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout2 = mPreference2.findViewById(R.id.settings_list_layout);
			final TextView mTitle2 = mPreference2.findViewById(R.id.settings_list_title_text);
			final TextView mText2 = mPreference2.findViewById(R.id.settings_list_text);
			final TextView mSubtext2 = mPreference2.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck2 = mPreference2.findViewById(R.id.settings_list_checkbox);

			mTitle2.setVisibility(View.GONE);
			mText2.setText("Privacy Policy");
			mSubtext2.setText("Read our Privacy Policy.");
			mCheck2.setVisibility(View.GONE);

			mLayout2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.URL_PRIVACY_POLICY)); 
                        startActivity(intent);
					}
				});

			mSettingsLayout.addView(mPreference2);
            
            View mPreference3 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

            final FrameLayout mLayout3 = mPreference3.findViewById(R.id.settings_list_layout);
            final TextView mTitle3 = mPreference3.findViewById(R.id.settings_list_title_text);
            final TextView mText3 = mPreference3.findViewById(R.id.settings_list_text);
            final TextView mSubtext3 = mPreference3.findViewById(R.id.settings_list_subtext);
            final CheckBox mCheck3 = mPreference3.findViewById(R.id.settings_list_checkbox);

            mTitle3.setVisibility(View.GONE);
            mText3.setText("Terms & Conditions");
            mSubtext3.setText("Read our Terms & Conditions.");
            mCheck3.setChecked(true);
            mCheck3.setClickable(false);

            mLayout3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.URL_USER_AGREEMENT)); 
                        startActivity(intent);
                    }
                });

            mSettingsLayout.addView(mPreference3);
            
            View mPreference5 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

            final FrameLayout mLayout5 = mPreference5.findViewById(R.id.settings_list_layout);
            final TextView mTitle5 = mPreference5.findViewById(R.id.settings_list_title_text);
            final TextView mText5 = mPreference5.findViewById(R.id.settings_list_text);
            final TextView mSubtext5 = mPreference5.findViewById(R.id.settings_list_subtext);
            final CheckBox mCheck5 = mPreference5.findViewById(R.id.settings_list_checkbox);

            final View mMargin = mPreference5.findViewById(R.id.settings_list_margin);
            
            mTitle5.setText(Constant.APP_NAME);
            mText5.setText(Constant.APP_DEVELOPER_CONTACT);
            mSubtext5.setText("Developer");
            mCheck5.setVisibility(View.GONE);

            mMargin.setVisibility(View.VISIBLE);
            
            mLayout5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.APP_DEVELOPER_CONTACT)); 
                        startActivity(intent);
                    }
                });

            mSettingsLayout.addView(mPreference5);
            
            View mPreference6 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

            final FrameLayout mLayout6 = mPreference6.findViewById(R.id.settings_list_layout);
            final TextView mTitle6 = mPreference6.findViewById(R.id.settings_list_title_text);
            final TextView mText6 = mPreference6.findViewById(R.id.settings_list_text);
            final TextView mSubtext6 = mPreference6.findViewById(R.id.settings_list_subtext);
            final CheckBox mCheck6 = mPreference6.findViewById(R.id.settings_list_checkbox);

            mTitle6.setVisibility(View.GONE);
            
            try {
                PackageInfo mPInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                mText6.setText(mPInfo.versionName);
            } catch (PackageManager.NameNotFoundException e) {
                mText6.setText("Unknown Error");
            }
            
            mSubtext6.setText("Version");
            mCheck6.setVisibility(View.GONE);

            mLayout6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        // Check updated app
                    }
                });

            mSettingsLayout.addView(mPreference6);
            
            View mPreference7 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

            final FrameLayout mLayout7 = mPreference7.findViewById(R.id.settings_list_layout);
            final TextView mTitle7 = mPreference7.findViewById(R.id.settings_list_title_text);
            final TextView mText7 = mPreference7.findViewById(R.id.settings_list_text);
            final TextView mSubtext7 = mPreference7.findViewById(R.id.settings_list_subtext);
            final CheckBox mCheck7 = mPreference7.findViewById(R.id.settings_list_checkbox);

            mTitle7.setVisibility(View.GONE);
            mText7.setText("Support");
            mSubtext7.setText("Consider buying me a cup of ☕☕☕");
            mCheck7.setVisibility(View.GONE);

            mLayout7.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(Constant.APP_DEVELOPER_PAYPAL)); 
                        startActivity(intent);
						
                        Toast.makeText(SettingsActivity.this, "Arat epak! ;)", Toast.LENGTH_SHORT).show();
                    }
                });

            mSettingsLayout.addView(mPreference7);    
		} else if(mMode == MODE_SETTINGS_REMOTE) {
            mRemoteSavedList = GetAllRemoteFromPreference();

            if(mRemoteSavedList != null) {
                if(mRemoteSavedList.size() > 0) {
                    View mPreference1 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout1 = mPreference1.findViewById(R.id.settings_list_layout);
                    final TextView mTitle1 = mPreference1.findViewById(R.id.settings_list_title_text);
                    final TextView mText1 = mPreference1.findViewById(R.id.settings_list_text);
                    final TextView mSubtext1 = mPreference1.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck1 = mPreference1.findViewById(R.id.settings_list_checkbox);

                    mTitle1.setText("Remote");
                    mText1.setText(mRemoteInfo.get("save_name").toString());
                    mSubtext1.setText("Change remote name.");
                    mCheck1.setVisibility(View.GONE);

                    mLayout1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                ShowSettingsAlertDialog(TYPE_EDITTEXT, "Remote", "Name", mText1.getText().toString(), null, "Save", "Cancel", mText1, "save_name", "");
                            }
                        });

                    mSettingsLayout.addView(mPreference1);

                    View mPreference2 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout2 = mPreference2.findViewById(R.id.settings_list_layout);
                    final TextView mTitle2 = mPreference2.findViewById(R.id.settings_list_title_text);
                    final TextView mText2 = mPreference2.findViewById(R.id.settings_list_text);
                    final TextView mSubtext2 = mPreference2.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck2 = mPreference2.findViewById(R.id.settings_list_checkbox);

                    mTitle2.setVisibility(View.GONE);
                    mText2.setText(mRemoteInfo.get("save_category2").toString());
                    mSubtext2.setText("Change remote category.");
                    mCheck2.setVisibility(View.GONE);

                    mLayout2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                ShowSettingsAlertDialog(TYPE_EDITTEXT, "Remote", "Category", mText2.getText().toString(), null, "Save", "Cancel", mText2, "save_category2", "");
                            }
                        });

                    mSettingsLayout.addView(mPreference2);

                    View mPreference3 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout3 = mPreference3.findViewById(R.id.settings_list_layout);
                    final TextView mTitle3 = mPreference3.findViewById(R.id.settings_list_title_text);
                    final TextView mText3 = mPreference3.findViewById(R.id.settings_list_text);
                    final TextView mSubtext3 = mPreference3.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck3 = mPreference3.findViewById(R.id.settings_list_checkbox);

                    mTitle3.setVisibility(View.GONE);
                    mText3.setText("Buttons");
                    mSubtext3.setText("Fix/Customize remote buttons.");
                    mCheck3.setVisibility(View.GONE);

                    mLayout3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                JSONObject jsonObj = new JSONObject(mRemoteInfo);

                                Intent intent = new Intent(SettingsActivity.this, RemoteActivity.class);
                                intent.putExtra("data", jsonObj.toString());
                                intent.putExtra("mode", RemoteActivity.MODE_CUSTOM);
                                startActivity(intent);
                            }
                        });

                    mSettingsLayout.addView(mPreference3);

                    View mPreference4 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout4 = mPreference4.findViewById(R.id.settings_list_layout);
                    final TextView mTitle4 = mPreference4.findViewById(R.id.settings_list_title_text);
                    final TextView mText4 = mPreference4.findViewById(R.id.settings_list_text);
                    final TextView mSubtext4 = mPreference4.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck4 = mPreference4.findViewById(R.id.settings_list_checkbox);

                    mTitle4.setVisibility(View.GONE);
                    mText4.setText("Logo");
                    mSubtext4.setText("Change remote logo.");
                    mCheck4.setVisibility(View.GONE);

                    mLayout4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                ShowSettingsAlertDialog(TYPE_LOGO, "Remote", mRemoteInfo.get("save_logo").toString(), "", null, "Save", "Cancel", mText4, "save_logo", "");
                            }
                        });

                    mSettingsLayout.addView(mPreference4);
                    
                    View mPreference5 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout5 = mPreference5.findViewById(R.id.settings_list_layout);
                    final TextView mTitle5 = mPreference5.findViewById(R.id.settings_list_title_text);
                    final TextView mText5 = mPreference5.findViewById(R.id.settings_list_text);
                    final TextView mSubtext5 = mPreference5.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck5 = mPreference5.findViewById(R.id.settings_list_checkbox);

                    mTitle5.setVisibility(View.GONE);
                    mText5.setText("Sound");
                    mSubtext5.setText("Enable remote buttons touch sounds.");
                    mCheck5.setChecked(Boolean.parseBoolean(mRemoteInfo.get("save_sound").toString()));

                    mLayout5.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                mCheck5.setChecked(!mCheck5.isChecked());
                                UpdateRemoteFromPreference("save_sound", ""+mCheck5.isChecked());
                            }
                        });

                    mSettingsLayout.addView(mPreference5);

                    View mPreference6 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

                    final FrameLayout mLayout6 = mPreference6.findViewById(R.id.settings_list_layout);
                    final TextView mTitle6 = mPreference6.findViewById(R.id.settings_list_title_text);
                    final TextView mText6 = mPreference6.findViewById(R.id.settings_list_text);
                    final TextView mSubtext6 = mPreference6.findViewById(R.id.settings_list_subtext);
                    final CheckBox mCheck6  = mPreference6.findViewById(R.id.settings_list_checkbox);

                    mTitle6.setVisibility(View.GONE);
                    mText6.setText("Vibrate");
                    mSubtext6.setText("Enable remote buttons vibration.");
                    mCheck6.setChecked(Boolean.parseBoolean(mRemoteInfo.get("save_vibrate").toString()));

                    mLayout6.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View p1) {
                                mCheck6.setChecked(!mCheck6.isChecked());
                                UpdateRemoteFromPreference("save_vibrate", ""+mCheck6.isChecked());
                            }
                        });

                    mSettingsLayout.addView(mPreference6);
                }
            }
		} else if(mMode == MODE_SETTINGS_ARDUINO) {
			mPhysicaloid = new Physicaloid(this);
			
            View mPreference1 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout1 = mPreference1.findViewById(R.id.settings_list_layout);
			final TextView mTitle1 = mPreference1.findViewById(R.id.settings_list_title_text);
			final TextView mText1 = mPreference1.findViewById(R.id.settings_list_text);
			final TextView mSubtext1 = mPreference1.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck1 = mPreference1.findViewById(R.id.settings_list_checkbox);

			mTitle1.setText("Arduino");
			mText1.setText(GetPreference(Constant.PREF_ARDUINO_BOARD, Constant.ARDUINO_BOARD_NAME[0]));
			mSubtext1.setText("Change arduino board.");
			mCheck1.setVisibility(View.GONE);

			mLayout1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						ShowSettingsAlertDialog(TYPE_LIST, "Arduino", GetPreference(Constant.PREF_ARDUINO_BOARD, Constant.ARDUINO_BOARD_NAME[0]), "", Constant.ARDUINO_BOARD_NAME, "Save", "Cancel", mText1, Constant.PREF_ARDUINO_BOARD, "");
					}
				});

			mSettingsLayout.addView(mPreference1);
			
			View mPreference2 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout2 = mPreference2.findViewById(R.id.settings_list_layout);
			final TextView mTitle2 = mPreference2.findViewById(R.id.settings_list_title_text);
			final TextView mText2 = mPreference2.findViewById(R.id.settings_list_text);
			final TextView mSubtext2 = mPreference2.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck2 = mPreference2.findViewById(R.id.settings_list_checkbox);

			mTitle2.setVisibility(View.GONE);
			mText2.setText("Board Setup");
			mSubtext2.setText("View image setup for arduino board.");
			mCheck2.setVisibility(View.GONE);

			mLayout2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						View mView = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_dialog_image, null);
                        final ZoomImageView mImage = mView.findViewById(R.id.dialog_image);

                        try {
							InputStream mStream = getResources().getAssets().open("oneremote/arduino_setup.png");
							Bitmap bitmap = BitmapFactory.decodeStream(mStream);
							mImage.setImageBitmap(bitmap);

							Dialog mDialog = new Dialog(SettingsActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
							mDialog.setContentView(mView);
							mDialog.show();
						} catch (IOException e) {}
					}
				});

			mSettingsLayout.addView(mPreference2);
			
			View mPreference3 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout3 = mPreference3.findViewById(R.id.settings_list_layout);
			final TextView mTitle3 = mPreference3.findViewById(R.id.settings_list_title_text);
			final TextView mText3 = mPreference3.findViewById(R.id.settings_list_text);
			final TextView mSubtext3 = mPreference3.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck3 = mPreference3.findViewById(R.id.settings_list_checkbox);

			mTitle3.setVisibility(View.GONE);
			mText3.setText("Upload System");
			mSubtext3.setText("Upload IRDecoder system to your arduino.");
			mCheck3.setVisibility(View.GONE);

			mLayout3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						AlertDialog.Builder alertBuilder = new AlertDialog.Builder(SettingsActivity.this);
                        alertBuilder.setTitle("Upload System");
						alertBuilder.setMessage("This Will Upload The IRDecoder.cpp.hex That Will Be Use For IR Code Extraction. Do You Wish To Continue?");
                        alertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface p1, int p2) {
                                    SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
									SharedPreferences.Editor editor = mPrefs.edit();

									editor.putBoolean(Constant.PREF_ARDUINO_IS_UPLOAD, true);
									editor.apply();

									p1.dismiss();
									finish();
                                } 
                            });

                        alertBuilder.setNegativeButton("Cancel", null);

                        alertBuilder.create().show();
					}
				});

			mSettingsLayout.addView(mPreference3);
			
			View mPreference4 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout4 = mPreference4.findViewById(R.id.settings_list_layout);
			final TextView mTitle4 = mPreference4.findViewById(R.id.settings_list_title_text);
			final TextView mText4 = mPreference4.findViewById(R.id.settings_list_text);
			final TextView mSubtext4 = mPreference4.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck4 = mPreference4.findViewById(R.id.settings_list_checkbox);

			mTitle4.setText("Monitor");
			mText4.setText(""+GetPreference(Constant.PREF_ARDUINO_BAUD_RATE, Constant.ARDUINO_BAUD_RATE[0]));
			mSubtext4.setText("Change baud rate.");
			mCheck4.setVisibility(View.GONE);

			mLayout4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						ShowSettingsAlertDialog(TYPE_LIST, "Arduino", GetPreference(Constant.PREF_ARDUINO_BAUD_RATE, Constant.ARDUINO_BAUD_RATE[0]), "", Constant.ARDUINO_BAUD_RATE, "Save", "Cancel", mText4, Constant.PREF_ARDUINO_BAUD_RATE, "");
					}
				});

			mSettingsLayout.addView(mPreference4);
			
			View mPreference5 = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.settings_select_1, null);

			final FrameLayout mLayout5 = mPreference5.findViewById(R.id.settings_list_layout);
			final TextView mTitle5 = mPreference5.findViewById(R.id.settings_list_title_text);
			final TextView mText5 = mPreference5.findViewById(R.id.settings_list_text);
			final TextView mSubtext5 = mPreference5.findViewById(R.id.settings_list_subtext);
			final CheckBox mCheck5 = mPreference5.findViewById(R.id.settings_list_checkbox);

			mTitle5.setVisibility(View.GONE);
			mText5.setText("Text Size");
			mSubtext5.setText("Change text size of the monitor.");
			mCheck5.setVisibility(View.GONE);

			mLayout5.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View p1) {
						AlertDialog.Builder alertBuilder = new AlertDialog.Builder(SettingsActivity.this);
                        alertBuilder.setTitle("Text Size");

                        View dialogLayout = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.dialog_content_5, null);
                        final SeekBarWithEditText mSeekBarEditText = dialogLayout.findViewById(R.id.dialog_seekbar_edittext);
                        mSeekBarEditText.setValue(GetPreference(Constant.PREF_ARDUINO_MONITOR_TEXT_SIZE, 15));

                        alertBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface p1, int p2) {
                                    UpdatePreference(Constant.PREF_ARDUINO_MONITOR_TEXT_SIZE, mSeekBarEditText.getValue());
                                } 
                            });

                        alertBuilder.setNegativeButton("Cancel", null);

                        alertBuilder.setView(dialogLayout);
                        alertBuilder.create().show();
					}
				});

			mSettingsLayout.addView(mPreference5);
		}
	}
    
    private void GetAllRemoteResourcesOnline() {
        if(checkPermission()) {
            try{
                final File TARGET_DIR = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote");
                File TARGET_FILE_1 = new File(TARGET_DIR, "oneremote_codes.dio");
                if(!TARGET_DIR.exists()) {
                    TARGET_DIR.mkdirs();
                }

                DownloadUtils mDownload = new DownloadUtils(SettingsActivity.this, TARGET_FILE_1, "Downloading Resources ...");                                                          
                mDownload.execute(Constant.URL_REMOTE_RESOURCES_CODES);
                mDownload.setOnDownloadComplete(new DownloadUtils.OnDownloadCompleted() {
                        @Override
                        public void onDownloadCompleted(int result) {
                            if(result == DownloadUtils.DOWNLOAD_SUCCESS) {
                                File TARGET_FILE_2 = new File(TARGET_DIR, "oneremote_layout.dio");

                                DownloadUtils mDownload = new DownloadUtils(SettingsActivity.this, TARGET_FILE_2, "Downloading Resources ...");                                                          
                                mDownload.execute(Constant.URL_REMOTE_RESOURCES_LAYOUT);
                                mDownload.setOnDownloadComplete(new DownloadUtils.OnDownloadCompleted() {
                                        @Override
                                        public void onDownloadCompleted(int result) {
                                            if(result == DownloadUtils.DOWNLOAD_SUCCESS) {
                                                Toast.makeText(SettingsActivity.this, "Remote Resources Successfully Downloaded.", Toast.LENGTH_SHORT).show();

                                                SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
                                                SharedPreferences.Editor mEditor = mPrefs.edit();
                                                mEditor.putBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, true);
                                                mEditor.apply();
                                            } else {
                                                Toast.makeText(SettingsActivity.this, "Remote Resources Download Failed. Please Try Again.", Toast.LENGTH_SHORT).show();

                                                SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
                                                SharedPreferences.Editor mEditor = mPrefs.edit();
                                                mEditor.putBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false);
                                                mEditor.apply();
                                            }
                                        }
                                    });
                            } else {
                                Toast.makeText(SettingsActivity.this, "Remote Resources Download Failed. Please Try Again.", Toast.LENGTH_SHORT).show();

                                SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
                                SharedPreferences.Editor mEditor = mPrefs.edit();
                                mEditor.putBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false);
                                mEditor.apply();
                            }
                        }
                    });
            } catch(Exception e) {
                Toast.makeText(SettingsActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            requestPermission();
        }
    }

	private ArrayList GetAllRemoteFromPreference() {
        ArrayList mList = null;

        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);

        Set<String> mSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));
        if(mSets != null) {
            if(mSets.size()>0) {
                mList = new ArrayList();

                for(String set: mSets) {
                    try {
                        JSONObject jsonObj = new JSONObject(set);
                        Iterator<String> keysItr = jsonObj.keys();
                        LinkedHashMap item = new LinkedHashMap();

                        while(keysItr.hasNext()) {
                            String key = keysItr.next().toString();
                            String value = jsonObj.get(key).toString();

                            item.put(key, value);
                        }

                        mList.add(item);
                    } catch (JSONException e) {
                        mList = new ArrayList();
                    }
                }
            }
        }

        if(mList != null) {
            if(mList.size() > 0) {
                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_name").toString().toLowerCase().compareTo(p2.get("save_name").toString().toLowerCase());
                        }
                    });

                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_category2").toString().toLowerCase().compareTo(p2.get("save_category2").toString().toLowerCase());
                        }
                    });
            }
        }

        return mList;
	}

	private void ShowSettingsAlertDialog(int type, String title, String message1, final String message2, final String[] list, String positive, String negative, final TextView textView, final String key, final String value) {																	
		View mDialogLayout = null;
		AlertDialog.Builder mAlertBuilder = new AlertDialog.Builder(SettingsActivity.this);
		mAlertBuilder.setTitle(title);
		
		switch(type) {
			case TYPE_EDITTEXT:
				mDialogLayout = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.dialog_content_1, null);
				final TextInputLayout mEditLayout = mDialogLayout.findViewById(R.id.dialog_edittext_layout);
				final TextInputEditText mEditText = mDialogLayout.findViewById(R.id.dialog_edittext);
				
				mEditLayout.setHint(message1);
				mEditText.setText(message2);
				mEditText.requestFocus();
				
				mAlertBuilder.setPositiveButton(positive, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							textView.setText(mEditText.getText().toString());
							UpdateRemoteFromPreference(key, mEditText.getText().toString());
						}
					});
					
				mAlertBuilder.setNegativeButton(negative, null);
				
				mAlertBuilder.setView(mDialogLayout);
				final AlertDialog mAlert1 = mAlertBuilder.create();
				
				mEditText.addTextChangedListener(new TextWatcher() {
						@Override
						public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

						@Override
						public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
							mAlert1.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!mEditText.getText().toString().isEmpty() && !mEditText.getText().toString().equals(message2));
						}

						@Override
						public void afterTextChanged(Editable p1) {}
					});
				
				mAlert1.show();
				mAlert1.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
				
				break;
			case TYPE_LOGO:
				mDialogLayout = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.dialog_content_2, null);
				final RecyclerView mRecyclerView = mDialogLayout.findViewById(R.id.dialog_recycler_view);
				GridLayoutManager gridLayoutManager = new GridLayoutManager(SettingsActivity.this, 3, GridLayoutManager.VERTICAL, false);
				mRecyclerView.setLayoutManager(gridLayoutManager);
				
				LinkedHashMap mCategory = new LinkedHashMap();
				
				for(int i=0; i<Constant.REMOTE_CATEGORY_NAME.length; i++) {
					mCategory.put(Constant.REMOTE_CATEGORY_NAME[i], Constant.REMOTE_CATEGORY_ID[i]);
					
					if(mLogoIndex == 0) {
						if(message1.equalsIgnoreCase(Constant.REMOTE_CATEGORY_NAME[i])) {
							mLogoIndex = i;
						}
					}
				}
				
				final SelectLogoDialogAdapter mSelectAdapter = new SelectLogoDialogAdapter(SettingsActivity.this, mCategory, mLogoIndex);														
				mRecyclerView.setAdapter(mSelectAdapter);
				mLogoIndex = mSelectAdapter.getSelectedLogo();
				
				mAlertBuilder.setPositiveButton(positive, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							mLogoIndex = mSelectAdapter.getSelectedLogo();
							
							String logo = mRemoteInfo.get("save_logo").toString();
							for(int i=0; i<Constant.REMOTE_CATEGORY_NAME.length; i++) {
								if(mLogoIndex == i) {
									logo = Constant.REMOTE_CATEGORY_NAME[i];
								}
							}
							
							UpdateRemoteFromPreference(key, logo);
						}
					});

				mAlertBuilder.setNegativeButton(negative, null);

				mAlertBuilder.setView(mDialogLayout);
				final AlertDialog mAlert2 = mAlertBuilder.create();
				
				mAlert2.show();
				break;
			case TYPE_DAYNIGHT:
				final String[] items = {"Dark Mode", "Light Mode"};
				mAlertBuilder.setItems(items, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							switch(items[p2]) {
								case "Dark Mode":
                                    textView.setText("Dark");
									DayNightModeHelper.createInstance().setActivity(SettingsActivity.this).setDayNightState(AppCompatDelegate.MODE_NIGHT_YES);
									recreate();
                                    break;
								case "Light Mode":
                                    textView.setText("Light");
									DayNightModeHelper.createInstance().setActivity(SettingsActivity.this).setDayNightState(AppCompatDelegate.MODE_NIGHT_NO);
									recreate();
                                    break;
							}
						}
					});
					
				final AlertDialog mAlert3 = mAlertBuilder.create();

				mAlert3.show();
				break;
			case TYPE_LIST:
				int pos = 0;
				final String[] board = new String[]{message1};
				for(int i=0; i<Constant.ARDUINO_BOARD_NAME.length; i++) {
					if(message1.equalsIgnoreCase(Constant.ARDUINO_BOARD_NAME[i])) {
						pos = i;
						break;
					}
				}
				
				mAlertBuilder.setSingleChoiceItems(list, pos, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							board[0] = list[p2];
						}
					});

				mAlertBuilder.setPositiveButton(positive, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							textView.setText(board[0]);
							UpdatePreference(key, board[0]);
						}
					});

				mAlertBuilder.setNegativeButton(negative, null);

				mAlertBuilder.setView(mDialogLayout);
				final AlertDialog mAlert4 = mAlertBuilder.create();

				mAlert4.show();

				break;
				
		}
	}
	
	private String GetPreference(String key, String def) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
		return mPrefs.getString(key, def);
	}
	
	private int GetPreference(String key, int def) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
		return mPrefs.getInt(key, def);
	}
	
	private void UpdatePreference(String key, String value) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();
		
		editor.putString(key, value);
		editor.apply();
	}
	
	private void UpdatePreference(String key, int value) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();

		editor.putInt(key, value);
		editor.apply();
	}
	
	private void UpdateRemoteFromPreference(String key, String value) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();

		mRemoteInfo.put(key, value);
		String mRemoteID = mRemoteInfo.get("save_id").toString();
		
		int index = 0;
		for(int i=0; i<mRemoteSavedList.size(); i++) {
			if(((LinkedHashMap)mRemoteSavedList.get(i)).getOrDefault("save_id", "").equals(mRemoteID)) {
				index = i;
				break;
			}
		}
		
		mRemoteSavedList.set(index, mRemoteInfo);
		
		Set<String> mNewSets = new HashSet<String>();
		
		for(LinkedHashMap item: mRemoteSavedList) {
			JSONObject jsonObj = new JSONObject(item);
			mNewSets.add(jsonObj.toString());
		}

		editor.putStringSet(Constant.PREF_REMOTE_LIST, mNewSets);
		editor.putBoolean(Constant.PREF_REMOTE_HAS_CHANGES, true);
		editor.apply();
	}
    
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(SettingsActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
	}
    
    private void requestPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(SettingsActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            AlertDialog.Builder alertBuild = new AlertDialog.Builder(SettingsActivity.this);
            alertBuild.setTitle("Storage Permission");
            alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Save Your Remote Configurations And Custom Layouts.");
            alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        final Intent intent = new Intent();
                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.addCategory(Intent.CATEGORY_DEFAULT);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                        intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                        startActivity(intent);
                    }
                });
            alertBuild.setNegativeButton("Cancel", null);

            AlertDialog alert = alertBuild.create();
            alert.show();
        } else {
            ActivityCompat.requestPermissions(SettingsActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
	}
}
