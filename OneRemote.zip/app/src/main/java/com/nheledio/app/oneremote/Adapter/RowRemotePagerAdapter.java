package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.UI.ViewPagerAdapter;
import java.util.ArrayList;

public class RowRemotePagerAdapter extends ViewPagerAdapter {

    private Context mContext; 
    private ArrayList<Integer> mList;

    public RowRemotePagerAdapter(Context context, ArrayList<Integer> list) {
        this.mContext = context;
        this.mList = list;
    }
    
    @Override
    public Object instantiateItemObject(ViewGroup container, int position) {
        View mView = LayoutInflater.from(mContext).inflate(R.layout.remote_button_1, container, false);
        LinearLayout mRowLayout = mView.findViewById(mList.get(position));
        mRowLayout.setVisibility(View.VISIBLE);
        
        container.addView(mView);

        return mView;
    }

    @Override
    public void destroyItemObject(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return view == o;
    }

    @Override
    public int getItemPosition(Object object) {
        return super.getItemPosition(object);
    }
}
