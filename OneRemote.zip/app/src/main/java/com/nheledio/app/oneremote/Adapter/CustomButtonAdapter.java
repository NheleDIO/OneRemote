package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.nheledio.app.oneremote.Adapter.SearchRemoteAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.UI.FastScrollRecyclerViewInterface;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import org.json.JSONObject;
import android.widget.Toast;
import android.widget.ImageView;

public class CustomButtonAdapter extends RecyclerView.Adapter<CustomButtonAdapter.DefineButtonViewHolder> {

    private Context mContext;
    private LinkedHashMap mMap;
	
	private int mMode = 0;
	public static final int MODE_ADD = 0;
	public static final int MODE_EDIT = 1;

    public CustomButtonAdapter(Context context, LinkedHashMap map, int mode) {
        this.mContext = context;
        this.mMap = map;
		this.mMode = mode;
    }
	
	private OnItemClicked mListener1;

    public interface OnItemClicked{
        void onClicked(String key, int position);
    }

    public void setOnItemClicked(OnItemClicked listener) {
        this.mListener1 = listener;
    }
	
	private OnItemLongClicked mListener2;

    public interface OnItemLongClicked{
        void onLongClicked(String key, int position);
    }

    public void setOnItemLongClicked(OnItemLongClicked listener) {
        this.mListener2 = listener;
    }

    @Override
    public DefineButtonViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_select_1, parent, false);
        DefineButtonViewHolder viewHolder = new DefineButtonViewHolder(mView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(DefineButtonViewHolder holder, final int position) {
        
        holder.mListText1.setText(getMapItem(position).getKey().toString());
		if(getMapItem(position).getValue() != null && mMode == MODE_EDIT) {
			holder.mListText2.setVisibility(View.VISIBLE);
			//holder.mListImage.setVisibility(View.VISIBLE);
			holder.mListText2.setText(getMapItem(position).getValue().toString());
		}
		
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mListener1 != null) {
						mListener1.onClicked(getMapItem(position).getKey().toString(), position);
					}                                              
                }
            });
            
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View p1) {
                    if(mListener2 != null) {
						mListener2.onLongClicked(getMapItem(position).getKey().toString(), position);
					}
					
                    return false;
                }
            });
    }
    @Override
    public int getItemCount() {
        return mMap.size();
    }
	
	private LinkedHashMap.Entry getMapItem(int position) {
		int i=0;
		for(LinkedHashMap.Entry entry: mMap.entrySet()) {
			if(i==position) {
				return entry;
			}
			i++;
		}
		
		return null;
	}
	
	public void removeItemAt(String key, int position) {
		if(mMap.containsKey(key)) {
			mMap.remove(key);
			notifyItemRemoved(position);
			notifyItemRangeChanged(position, mMap.size());
		}
	}
	
	public void refreshItems(LinkedHashMap map) {
		this.mMap = map;
		notifyDataSetChanged();
	}

    public class DefineButtonViewHolder extends RecyclerView.ViewHolder {

        private TextView mListText1;
        private TextView mListText2;
		private ImageView mListImage;

        public DefineButtonViewHolder(View itemView) {
            super(itemView);

            mListText1 = itemView.findViewById(R.id.search_list_text1);
            mListText2 = itemView.findViewById(R.id.search_list_text2);
			mListImage = itemView.findViewById(R.id.search_list_image);

            mListText2.setVisibility(View.INVISIBLE);
			mListImage.setVisibility(View.INVISIBLE);
        }
    }
}
