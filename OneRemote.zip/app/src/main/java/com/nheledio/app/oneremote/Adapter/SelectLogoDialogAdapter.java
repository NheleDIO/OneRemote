package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.nheledio.app.oneremote.Adapter.SelectCategoryAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.SearchActivity;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import androidx.core.content.ContextCompat;

public class SelectLogoDialogAdapter extends RecyclerView.Adapter<SelectLogoDialogAdapter.DialogLogoViewHolder> {

    private Context mContext;
    private LinkedHashMap mCategory;
	private int mIndex;

    public SelectLogoDialogAdapter(Context context, LinkedHashMap category, int position) {

		this.mContext = context;
        this.mCategory = category;
        
		this.mIndex = position;
    }

    @Override
    public DialogLogoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.dialog_content_3, parent, false);

        DialogLogoViewHolder viewHolder = new DialogLogoViewHolder(mView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final DialogLogoViewHolder holder, final int position) {

        holder.mImage.setImageDrawable(ContextCompat.getDrawable(mContext, getItem(position).getValue()));
		if(mIndex == position) {
			holder.mImageLine.setVisibility(View.VISIBLE);
		} else {
			holder.mImageLine.setVisibility(View.GONE);
		}
		
        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					int temp = mIndex;
					mIndex = position;
					
					notifyItemChanged(temp);
					notifyItemChanged(position);
				}
			});
    }

    @Override
    public int getItemCount() {
        return mCategory.size();
    }
	
	public int getSelectedLogo() {
		return mIndex;
	}
    
    private LinkedHashMap.Entry getItem(int position) {
        int pos = 0;
        for(LinkedHashMap.Entry entry: mCategory.entrySet()) {
            if(pos == position) {
                return entry;
            }
            pos++;
        }

        return null;
    }

    public class DialogLogoViewHolder extends RecyclerView.ViewHolder {

        private ImageView mImage;
		private View mImageLine;
		
        public DialogLogoViewHolder(View itemView) {
            super(itemView);

            mImage = itemView.findViewById(R.id.logo_s1);
			mImageLine = itemView.findViewById(R.id.logo_underline);
			
			mImageLine.setVisibility(View.GONE);
        }
    }
}
