package com.nheledio.app.oneremote.UI;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.nheledio.app.oneremote.R;
import com.google.android.material.button.MaterialButton;
import androidx.cardview.widget.CardView;
import android.graphics.Color;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;

public class Snackbar extends BaseTransientBottomBar<Snackbar> {

    private Snackbar(ViewGroup parent, View content, ContentViewCallback callback) {
        super(parent, content, callback);
    }

    public static Snackbar make(@NonNull ViewGroup parent, @Duration int duration) {
        
        final View mLayoutContent = LayoutInflater.from(parent.getContext()).inflate(R.layout.snackbar_main, parent, false);
        final ContentViewCallback mViewCallback = new ContentViewCallback(mLayoutContent);
        final Snackbar mCustomSnackbar = new Snackbar(parent, mLayoutContent, mViewCallback);

        mCustomSnackbar.getView().setPadding(3, 3, 3, 3);
        mCustomSnackbar.setDuration(duration);
		mCustomSnackbar.getView().setBackgroundColor(Color.TRANSPARENT);
        return mCustomSnackbar;
    }

    public Snackbar setText(CharSequence text) {
        TextView textView = getView().findViewById(R.id.snackbar_text);
        textView.setText(text);
        
		return this;
    }
	
	public Snackbar setText(CharSequence text, int textColor) {
        TextView textView = getView().findViewById(R.id.snackbar_text);
        textView.setText(text);
		textView.setTextColor(textColor);
		
        return this;
    }

    public Snackbar setAction(CharSequence text, final View.OnClickListener listener) {
        Button actionButton = getView().findViewById(R.id.snackbar_button);
        actionButton.setText(text);
        actionButton.setVisibility(View.VISIBLE);
		
        actionButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					listener.onClick(view);
		
					dismiss();
				}
			});
        return this;
    }
	
	public Snackbar setAction(CharSequence text, int textColor, final View.OnClickListener listener) {
        Button actionView = getView().findViewById(R.id.snackbar_button);
        actionView.setText(text);
		actionView.setTextColor(textColor);
        actionView.setVisibility(View.VISIBLE);
		
        actionView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					listener.onClick(view);

					dismiss();
				}
			});
			
        return this;
    }
	
	public Snackbar setSnackColor(int color) {
        CardView cardView = getView().findViewById(R.id.snackbar_card);
		cardView.setBackgroundColor(color);
		
        return this;
    }
	
	public Snackbar setSnackImage(Drawable res) {
        ImageView imageView = getView().findViewById(R.id.snackbar_image);
		imageView.setImageDrawable(res);

        return this;
    }
	
	public Snackbar setSnackImage(Drawable res, int colorTint) {
        ImageView imageView = getView().findViewById(R.id.snackbar_image);
		imageView.setImageDrawable(res);
		imageView.setColorFilter(colorTint);

        return this;
    }

    private static class ContentViewCallback implements BaseTransientBottomBar.ContentViewCallback {

        private View content;

        public ContentViewCallback(View content) {
            this.content = content;
        }

        @Override
        public void animateContentIn(int delay, int duration) {
            ViewCompat.setScaleY(content, 0f);
            ViewCompat.animate(content).scaleY(1f).setDuration(duration).setStartDelay(delay);
        }

        @Override
        public void animateContentOut(int delay, int duration) {
            ViewCompat.setScaleY(content, 1f);
            ViewCompat.animate(content).scaleY(0f).setDuration(duration).setStartDelay(delay);
        }
    }
}
