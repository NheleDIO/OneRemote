package com.nheledio.app.oneremote.UI;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TextView.SavedState;
import com.nheledio.app.oneremote.R;
import java.security.Security;
import android.widget.ImageView;

public class SeekBarWithEditText extends LinearLayout implements SeekBar.OnSeekBarChangeListener, TextWatcher, View.OnFocusChangeListener, EditTextWithSeekBar.OnEditTextListener {

    private SeekBar mSeekBar;
    private EditTextWithSeekBar mEditText;
    private ImageView mLeft;
    private ImageView mRight;

    private boolean selectOnFocus = false;
    private boolean animateChanges = true;
    private ValueAnimator seekBarAnimator;

    private int currentValue = 0;
    private int minValue = 0;
    private int maxValue = 100;

    private boolean touching = false;

    private static final int SEEKBAR_DEFAULT_MAX = 100;
    private static final int SEEKBAR_DEFAULT_MIN = 0;
    private static final int ANIMATION_DEFAULT_DURATION = 300;

    private OnEditableSeekBarChangeListener mListener;

    public interface OnEditableSeekBarChangeListener{
        void onEditableSeekBarProgressChanged(SeekBar seekBar, int progress, boolean fromUser);
        void onStartTrackingTouch(SeekBar seekBar);
        void onStopTrackingTouch(SeekBar seekBar);
        void onEnteredValueTooHigh();
        void onEnteredValueTooLow();
        void onEditableSeekBarValueChanged(int value);
    }

    public SeekBarWithEditText(Context context) {
        super(context);
    }

    public SeekBarWithEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        inflate(getContext(), R.layout.seekbar_edittext, this);

        setSaveEnabled(true);
        
        mSeekBar = findViewById(R.id.seekbar_seekbar);
        mEditText = findViewById(R.id.seekbar_edittext);
        mLeft = findViewById(R.id.seekbar_button_left);
        mRight = findViewById(R.id.seekbar_button_right);

        mEditText.setSelectAllOnFocus(selectOnFocus);

        mSeekBar.setOnSeekBarChangeListener(this);
        mEditText.addTextChangedListener(this);
        mEditText.setOnFocusChangeListener(this);
        mEditText.setOnKeyboardDismissedListener(this);

        mSeekBar.setOnTouchListener(new OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    hideKeyboard();
                    return false;
                }
            });
            
        mLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    setValue(getValue()-1);
                }
            });
            
        mRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    setValue(getValue()+1);
                }
            });
    }

    public void setOnEditableSeekBarChangeListener(OnEditableSeekBarChangeListener listener){
        this.mListener = listener;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        currentValue = translateToRealValue(progress);

        if(fromUser) {
            setEditTextValue(currentValue);

            if(selectOnFocus) {
                mEditText.selectAll();
            } else {
                mEditText.setSelection(mEditText.getText().length());
            }
        }

        if(mListener != null)
            mListener.onEditableSeekBarProgressChanged(seekBar, currentValue, fromUser);
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        if (mListener != null)
            mListener.onStartTrackingTouch(seekBar);

        touching = true;

        mEditText.requestFocus();

        if(selectOnFocus) {
            mEditText.selectAll();
        } else {
            mEditText.setSelection(mEditText.getText().length());
        }
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        if(mListener != null)
            mListener.onStopTrackingTouch(seekBar);

        touching = false;

        currentValue = translateToRealValue(seekBar.getProgress());

        if(mListener != null)
            mListener.onEditableSeekBarValueChanged(currentValue);
    }


    @Override
    public void onEditTextKeyboardDismissed() {
        checkValue();

        if(mListener != null)
            mListener.onEditableSeekBarValueChanged(currentValue);
    }

    @Override
    public void onEditTextKeyboardDone() {
        checkValue();

        if(mListener != null)
            mListener.onEditableSeekBarValueChanged(currentValue);

        hideKeyboard();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if(touching)
            return;

        if(!s.toString().isEmpty() && isNumber(s.toString())){
            int value = Integer.parseInt(s.toString());

            if(value > maxValue && currentValue != maxValue){
                value = maxValue;
                setEditTextValue(value);

                if(selectOnFocus)
                    mEditText.selectAll();
                else
                    mEditText.setSelection(mEditText.getText().length());

                if(mListener != null) {
                    mListener.onEnteredValueTooHigh();
                    //mListener.onEditableSeekBarValueChanged(currentValue);
                }
            }

            if(value < minValue && currentValue != minValue) {
                value = minValue;
                setEditTextValue(value);

                if(selectOnFocus)
                    mEditText.selectAll();
                else
                    mEditText.setSelection(mEditText.getText().length());

                if(mListener != null) {
                    mListener.onEnteredValueTooLow();
                    //mListener.onEditableSeekBarValueChanged(currentValue);
                }
            }

            if(value >= minValue && value <= maxValue && value != currentValue) {
                currentValue = value;
                setSeekBarValue(translateFromRealValue(currentValue));

                if(mListener != null) {
                    mListener.onEditableSeekBarValueChanged(currentValue);
                }
            }
        } else {
            //currentValue = minValue;
            //setSeekBarValue(translateFromRealValue(currentValue));
        }
    }

    private void checkValue(){
        setEditTextValue(currentValue);
    }

    private boolean isNumber(String s) {
        try{
            Integer.parseInt(s);
        }catch (NumberFormatException e){
            return false;
        }
        return true;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if(v instanceof EditText) {
            if(!hasFocus) {
                boolean sendValueChanged = mEditText.getText().toString().isEmpty() || !isNumber(mEditText.getText().toString()) || !isInRange(Integer.parseInt(mEditText.getText().toString()));

                if (sendValueChanged){
                    checkValue();
                }

                if(mListener != null && sendValueChanged) {
                    mListener.onEditableSeekBarValueChanged(currentValue);
                    //setEditTextValue(translateFromRealValue(currentValue));
                }
            } else {
                if(selectOnFocus) {
                    mEditText.selectAll();      
                } else {
                    mEditText.setSelection(mEditText.getText().length());
                }
            }
        }
    }

    private void hideKeyboard(){
        InputMethodManager imm = (InputMethodManager) getContext().getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mEditText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    private void setEditTextValue(int value){
        if(mEditText != null) {
            //mEditText.removeTextChangedListener(this);
            mEditText.setText(Integer.toString(value));
            //mEditText.addTextChangedListener(this);
        }
    }

    private void setSeekBarValue(int value){
        if(mSeekBar != null){
            if(animateChanges) {
                animateSeekbar(mSeekBar.getProgress(), value);
            } else {
                mSeekBar.setProgress(value);
            }
        }
    }

    private int translateFromRealValue(int realValue){
        return realValue < 0 ? Math.abs(realValue - minValue) : realValue - minValue;
    }

    private int translateToRealValue(int sbValue){
        return minValue + sbValue;
    }

    public void setRange(int min, int max) {
        if(min > max){
            minValue = SEEKBAR_DEFAULT_MIN;
            maxValue = SEEKBAR_DEFAULT_MAX;
        }else{
            minValue = min;
            maxValue = max;
        }

        mSeekBar.setMax(getRange());

        if(!isInRange(currentValue)) {
            if (currentValue < minValue)
                currentValue = minValue;

            if (currentValue > maxValue)
                currentValue = maxValue;

            setValue(currentValue);
        }
    }

    public int getRange(){
        return maxValue < 0 ? Math.abs(maxValue - minValue) : maxValue - minValue;
    }

    public void setValue(Integer value){
        if(value == null)
            return;

        if(!isInRange(value)) {
            if (value < minValue)
                value = minValue;

            if (value > maxValue)
                value = maxValue;
        }

        currentValue = value;

        setEditTextValue(currentValue);
        setSeekBarValue(translateFromRealValue(currentValue));
    }

    private boolean isInRange(int value){

        if(value < minValue){
            if(mListener != null)
                mListener.onEnteredValueTooLow();

            return false;
        }

        if(value > maxValue){
            if(mListener != null)
                mListener.onEnteredValueTooHigh();

            return false;
        }

        return true;
    }

    public int getValue(){
        return currentValue;
    }

    public void setMaxValue(int max){
        setRange(minValue, max);
    }

    public void setMinValue(int min){
        setRange(min, maxValue);
    }

    public void setAnimateSeekBar(boolean animate){
        this.animateChanges = animate;
    }


    private static class SavedState extends BaseSavedState {
        int value;
        boolean focus;
        boolean animate;

        SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            value = in.readInt();
            focus = in.readInt() == 1;
            animate = in.readInt() == 1;
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(value);
            out.writeInt(focus ? 1 : 0);
            out.writeInt(animate ? 1 : 0);
        }

        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
    }

    @Override
    public Parcelable onSaveInstanceState() {
        Parcelable superState = super.onSaveInstanceState();
        SavedState ss = new SavedState(superState);
        ss.value = currentValue;
        ss.focus = selectOnFocus;
        ss.animate = animateChanges;
        return ss;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state) {
        SavedState ss = (SavedState) state;
        super.onRestoreInstanceState(ss.getSuperState());
        setValue(ss.value);
        animateChanges = ss.animate;
        selectOnFocus = ss.focus;
    }

    @Override
    protected void dispatchSaveInstanceState(SparseArray container) {
        super.dispatchFreezeSelfOnly(container);
    }

    @Override
    protected void dispatchRestoreInstanceState(SparseArray container) {
        super.dispatchThawSelfOnly(container);
    }

    private void animateSeekbar(int startValue, int endValue){
        if(seekBarAnimator != null && seekBarAnimator.isRunning()) {
            seekBarAnimator.cancel();
        }

        if(seekBarAnimator == null){
            seekBarAnimator = ValueAnimator.ofInt(startValue, endValue);
            seekBarAnimator.setInterpolator(new DecelerateInterpolator());
            seekBarAnimator.setDuration(ANIMATION_DEFAULT_DURATION);

            seekBarAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator animation) {
                        mSeekBar.setProgress((Integer) animation.getAnimatedValue());
                    }
                });
                
        } else {
            seekBarAnimator.setIntValues(startValue, endValue);
        }
        seekBarAnimator.start();
    }
}

