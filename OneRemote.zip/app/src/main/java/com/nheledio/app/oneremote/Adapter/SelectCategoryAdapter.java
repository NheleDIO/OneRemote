package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.nheledio.app.oneremote.Adapter.SelectCategoryAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.SearchActivity;
import java.util.LinkedHashMap;
import androidx.core.content.ContextCompat;
import com.nheledio.app.oneremote.CustomActivity;

public class SelectCategoryAdapter extends RecyclerView.Adapter<SelectCategoryAdapter.SelectRemoteViewHolder> {
	  
    private Context mContext;
	private LinkedHashMap mCategory;
	private BottomSheetBehavior mBottomSheet;
	
    public SelectCategoryAdapter(Context context, LinkedHashMap category, BottomSheetBehavior bottomSheet) {
		this.mContext = context;
        this.mCategory = category;
        
		this.mBottomSheet = bottomSheet;
    }
	
    @Override
    public SelectRemoteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.remote_select_1, parent, false);
        
        SelectRemoteViewHolder viewHolder = new SelectRemoteViewHolder(mView);
        return viewHolder;
    }
	
    @Override
    public void onBindViewHolder(SelectRemoteViewHolder holder, final int position) {
        
        holder.mText.setText(getItem(position).getKey().toString());
        holder.mImage.setImageDrawable(ContextCompat.getDrawable(mContext, getItem(position).getValue()));
        
        holder.itemView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
				mBottomSheet.setState(BottomSheetBehavior.STATE_COLLAPSED);
				
				new Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
                            if(getItem(position).getKey().toString().equalsIgnoreCase("custom")) {
                                Intent intent = new Intent(mContext, CustomActivity.class);                                                    
                                mContext.startActivity(intent);			
                            } else {
                                Intent intent = new Intent(mContext, SearchActivity.class);
                                intent.putExtra("category", getItem(position).getKey().toString());                                                    
                                mContext.startActivity(intent);			
                            }
							
						}
					}, 300);
				
																						
			}
		});
    }
	
    @Override
    public int getItemCount() {
        return mCategory.size();
    }
    
    private LinkedHashMap.Entry getItem(int position) {
        int pos = 0;
        for(LinkedHashMap.Entry entry: mCategory.entrySet()) {
            if(pos == position) {
                return entry;
            }
            pos++;
        }
        
        return null;
    }
	
    public class SelectRemoteViewHolder extends RecyclerView.ViewHolder {
       
        private TextView mText;
        private ImageView mImage;
		
        public SelectRemoteViewHolder(View itemView) {
            super(itemView);
            
            mText = itemView.findViewById(R.id.button_text_s1);
            mImage = itemView.findViewById(R.id.button_s1);
        }
    }
}
