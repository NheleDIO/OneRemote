package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.nheledio.app.oneremote.Adapter.SearchRemoteAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.UI.FastScrollRecyclerViewInterface;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class CustomRemoteAdapter extends RecyclerView.Adapter<CustomRemoteAdapter.CustomRemoteViewHolder> implements FastScrollRecyclerViewInterface, Filterable {

    private Context mContext;
    private ArrayList mBrands;
	private LinkedHashMap mMapIndex;

	private ArrayList mBrandsCopy;
	
	private OnItemClicked mListener;

    public interface OnItemClicked{
        void onClicked(int position);
    }

    public void setOnItemClicked(OnItemClicked listener) {
        this.mListener = listener;
    }

    public CustomRemoteAdapter(Context context, ArrayList brands) {

		this.mContext = context;
        this.mBrands = brands;
		//this.mMapIndex = mapIndex;

		this.mBrandsCopy = brands;
    }

    @Override
    public CustomRemoteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

		View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_select_2, parent, false);
		CustomRemoteViewHolder viewHolder = new CustomRemoteViewHolder(mView);

		return viewHolder;
    }

    @Override
    public void onBindViewHolder(CustomRemoteViewHolder holder, final int position) {

		if(position == 0) {
			holder.mListTitle.setVisibility(View.VISIBLE);
			holder.mListTitle.setText(((LinkedHashMap)mBrands.get(position)).get("category").toString());
		} else {
			if(!((LinkedHashMap)mBrands.get(position)).get("category").toString().equalsIgnoreCase(((LinkedHashMap)mBrands.get(position-1)).get("category").toString())) {
				holder.mListTitle.setVisibility(View.VISIBLE);
				holder.mListTitle.setText(((LinkedHashMap)mBrands.get(position)).get("category").toString());
			} else {
				holder.mListTitle.setVisibility(View.GONE);
			}										
		}

		holder.mListText.setText(((LinkedHashMap)mBrands.get(position)).get("name").toString());
		holder.mListSubText.setText(((LinkedHashMap)mBrands.get(position)).get("configs").toString());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if(mListener != null) {
						mListener.onClicked(position);
					}											
				}
			});
    }
    @Override
    public int getItemCount() {
        return mBrands.size();
    }

	@Override
	public LinkedHashMap<String, Integer> getMapIndex() {
		return this.mMapIndex;
	}

	@Override
	public Filter getFilter() {
		return new Filter() {
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                mBrands = (ArrayList) results.values;
                notifyDataSetChanged();
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                ArrayList filteredResults = null;
                if (constraint.toString().length() == 0) {
                    filteredResults = mBrandsCopy;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }
        };
    }

	private ArrayList getFilteredResults(String constraint) {
        ArrayList results = new ArrayList<>();

        for (LinkedHashMap item : mBrandsCopy) {
			for(LinkedHashMap.Entry entry: item.entrySet()) {
				if(entry.getKey().toString().equalsIgnoreCase("name")) {
					if (entry.getValue().toString().toLowerCase().contains(constraint.toLowerCase())) {
						results.add(item);
					}
				}
			}    
        }

        return results;
	}
	
	public void removeItemAt(int position) {
		mBrands.remove(position);
		notifyItemRemoved(position);
		notifyItemRangeChanged(position, mBrands.size());
	}
	
	public void refreshItems(ArrayList list) {
		this.mBrands = list;
		notifyDataSetChanged();
	}

    public class CustomRemoteViewHolder extends RecyclerView.ViewHolder {

		private TextView mListTitle;
        private TextView mListText;
		private TextView mListSubText;

        public CustomRemoteViewHolder(View itemView) {
            super(itemView);

			mListTitle = itemView.findViewById(R.id.custom_list_title_text);
            mListText = itemView.findViewById(R.id.custom_list_text);
			mListSubText = itemView.findViewById(R.id.custom_list_subtext);
			
			mListTitle.setVisibility(View.GONE);
        }
    }
}
