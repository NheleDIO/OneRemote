package com.nheledio.app.oneremote;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.ConsumerIrManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.nheledio.app.oneremote.Adapter.RowRemotePagerAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.UI.RemoteButton;
import com.nheledio.app.oneremote.UI.SeekBarWithEditText;
import com.nheledio.app.oneremote.UI.Snackbar;
import com.nheledio.app.oneremote.UI.ViewPager;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.DayNightModeHelper;
import com.nheledio.app.oneremote.Utils.ViewUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class RemoteActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {
	
	private Toolbar mToolbar;
	private ImageView mToolbarButton1;
	private ImageView mToolbarButton2;
	private TextView mToolbarTitle;
	
	private CoordinatorLayout mParentLayout;
	private LinearLayout mMainLayout;
	private BottomSheetBehavior mBottomSheetBehavior;
    
    private ConsumerIrManager mIRManager;

	private int mMode = 0;
	public static final int MODE_SETUP = 1;
	public static final int MODE_REMOTE = 2;
	public static final int MODE_CUSTOM = 3;
	
	private int mConfigsCount = 1;
	private int mConfigsSelected = 1;
    private int mDialogConfigsCount = 1;
	private int mDialogConfigsSelected = 1;
	
	private static final int PERMISSION_REQUEST_CODE = 1;
    
    private LinkedHashMap mRemoteAllButtonViews;
    private LinkedHashMap mRemotePartialButtonViews;
    
	private LinkedHashMap mRemoteInfo;
    private LinkedHashMap mRemoteCodes;
	private LinkedHashMap mRemoteLayout;
	
    private boolean mIsBottomExpanded = false;
	private boolean mHasError = false;
	private boolean mHasChanges = false;
	private boolean mFlag = false;
    private boolean mIsRowEditorVisible = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Initialize();
		super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_remote);
		
		InitData();
		InitToolbar();
		
		mParentLayout = findViewById(R.id.activity_remote_coord_layout);
		mMainLayout = findViewById(R.id.remote_layout);
		
		InitRemote();
		InitBottomSheet();
    }
	
	@Override
	public void onClick(View p1) {
		int id = p1.getId();

		switch(id) {
			case R.id.toolbar_button_1:
				onBackPressed();
				break;
                
			case R.id.toolbar_button_2:
				if(mMode == MODE_CUSTOM) {
					PopupMenu menu = new PopupMenu(this, mToolbarButton2);
					menu.getMenu().add("Add");
                    menu.getMenu().add("Default");
					menu.getMenu().add("Save");
					menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							@Override
							public boolean onMenuItemClick(MenuItem p1) {
								switch(p1.getTitle().toString()) {
									case "Add":
										ShowRemoteRowAlertDialog(null, null);
										break;
                                    case "Default":
                                        mHasChanges = true;
                                        
                                        mRemoteAllButtonViews = new LinkedHashMap();
                                        mRemoteInfo.put("save_buttons", "default");
                                        
                                        try {
                                            mRemoteCodes = GetRemoteButtonCodes();
                                            mRemoteLayout = GetRemoteButtonLayout();
                                        } catch (XmlPullParserException e) {} catch (IOException e) {} catch (Exception e) {} 
                                        
                                        if(mRemoteCodes != null && mRemoteLayout != null) {
                                            mMainLayout.removeAllViews();
                                            if(mRemoteLayout.size() == 0){
                                                SetupRemoteButtonDefaultAll(""+mConfigsSelected);
                                            } else {
                                                SetupRemoteButtonView(mMainLayout, mRemoteLayout, mMode, true);
                                            }
                                        } else if(mRemoteCodes != null && mRemoteLayout == null) {
                                            SetupRemoteButtonDefaultAll(""+mConfigsSelected);
                                        }
										break;
									case "Save":
										SaveRemoteToFile();
										break;
								}
								return false;
							}
						});
					menu.show();
				}
				break;
		}
	}
	
	@Override
	public boolean onLongClick(View p1) {
		return false;
	}
	
	@Override
	public void onBackPressed() {

		if(mIsBottomExpanded) {
			mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
		} else {
			if(mMode == MODE_CUSTOM) {
                if(mHasChanges) {
                    AlertDialog.Builder alertBuild = new AlertDialog.Builder(RemoteActivity.this);
                    alertBuild.setTitle("Edit Remote");
                    alertBuild.setMessage("Discard Changes?");
                    alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface p1, int p2) {
                                finish();
                            }
                        });
                    alertBuild.setNegativeButton("No", null);

                    AlertDialog alert = alertBuild.create();
					alert.show();
                } else {
                    super.onBackPressed();
                    return;
                }
            } else {
                super.onBackPressed();
                return;
            }
		}
	}

    @Override
    protected void onResume() {
        super.onResume();
        
    }
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
		switch (requestCode) {
			case PERMISSION_REQUEST_CODE:
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					if(mFlag) {
						mFlag = false;
						SaveRemoteToFile();
					}
				} else {
					AlertDialog.Builder alertBuild = new AlertDialog.Builder(RemoteActivity.this);
					alertBuild.setTitle("Storage Permission");
					alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Save Your Remote Configurations And Custom Layouts.");
					alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface p1, int p2) {
								final Intent intent = new Intent();
								intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
								intent.addCategory(Intent.CATEGORY_DEFAULT);
								intent.setData(Uri.parse("package:" + getPackageName()));
								intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
								intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								startActivity(intent);
							}
						});
					alertBuild.setNegativeButton("Cancel", null);

					AlertDialog alert = alertBuild.create();
					alert.show();
				}
				break;
		}
	}
	
	/*  */
	
	private void Initialize() {
        AppCompatDelegate.setDefaultNightMode(DayNightModeHelper.createInstance().getDayNightSavedState(RemoteActivity.this));
    }
	
	private void InitData() {
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			mMode = extras.getInt("mode");

			String mData = extras.getString("data", null);
			if(mData !=null) {
				mRemoteInfo = new LinkedHashMap();
                mRemoteAllButtonViews = new LinkedHashMap();
				try {
					JSONObject jsonObj = new JSONObject(mData);
					Iterator iterator = jsonObj.keys();
					while(iterator.hasNext()) {
						String key = iterator.next().toString();
						mRemoteInfo.put(key, jsonObj.get(key).toString());
					}

					mConfigsCount = Integer.parseInt(mRemoteInfo.getOrDefault("configs", 1).toString());
                    mConfigsSelected = Integer.parseInt(mRemoteInfo.getOrDefault("save_config", 1).toString());
				} catch (JSONException e) {}
			}
		}
	}
	
	private void InitToolbar() {
		mToolbar = findViewById(R.id.toolbar_remote);
		mToolbarButton1 = mToolbar.findViewById(R.id.toolbar_button_1);
		mToolbarButton2 = mToolbar.findViewById(R.id.toolbar_button_2);
		mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

		mToolbarButton1.setOnClickListener(this);
		mToolbarButton2.setOnClickListener(this);
		
        setSupportActionBar(mToolbar);
		
		/*  */
		
		if(mMode == MODE_SETUP) {
			mToolbarTitle.setText("Add "+mRemoteInfo.get("category")+" Remote");
			mToolbarButton2.setVisibility(View.GONE);
		} else if(mMode == MODE_REMOTE) {
			mToolbarTitle.setText(mRemoteInfo.get("save_name").toString());
			mToolbarButton2.setVisibility(View.GONE);
		} else if(mMode == MODE_CUSTOM) {
			mToolbarTitle.setText("Edit Remote");
			mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_dot));
		}
	}
	
	private void InitRemote() {
		if(mMode == MODE_SETUP) {
			View mContentSetup = findViewById(R.id.content_remote_setup);
			NestedScrollView mContentScroll = findViewById(R.id.content_remote_scroll);
			mContentScroll.setVisibility(View.GONE);
            
			final TextInputEditText mNameEditText = mContentSetup.findViewById(R.id.remote_setup_name_edittext);
			final TextInputEditText mCategoryEditText = mContentSetup.findViewById(R.id.remote_setup_category_edittext);
			final ImageView mConfigLeft = mContentSetup.findViewById(R.id.remote_setup_button_left);
			final ImageView mConfigRight = mContentSetup.findViewById(R.id.remote_setup_button_right);
			final ImageView mConfigButton = mContentSetup.findViewById(R.id.remote_setup_button_1);
			final TextView mConfigTextIndicator = mContentSetup.findViewById(R.id.remote_setup_config_text_1);
			final TextView mConfigTextMain = mContentSetup.findViewById(R.id.remote_setup_config_text_2);
            final MaterialButton mFinishSetupButton = mContentSetup.findViewById(R.id.remote_setup_button_main);
            
            mNameEditText.setText(mRemoteInfo.getOrDefault("name", "Empty").toString());
			mCategoryEditText.setText("My Room");
            
            mConfigTextIndicator.setText(mConfigsSelected+"/"+mConfigsCount);
            mConfigTextMain.setText("Select Remote Configurations");
            
            try {
                mRemoteCodes = GetRemoteButtonCodes();
				
				LinkedHashMap mCustom = GetRemoteButtonCodesCustom();
				if(mCustom != null) {
					for(LinkedHashMap.Entry entry: mCustom.entrySet()) {
						mRemoteCodes.put(entry.getKey(), entry.getValue());
					}
				}
            } catch (XmlPullParserException e) {} catch (IOException e) {}


            if(mConfigsSelected == 1) {
                setEnabled(mConfigLeft, false);
            }
            if(mConfigsCount == 1) {
                setEnabled(mConfigRight, false);
            }

            if(mRemoteCodes == null) {
                setEnabled(mConfigButton, false);
            }
            
			mConfigLeft.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        mConfigsSelected--;
                        mConfigTextIndicator.setText(mConfigsSelected+"/"+mConfigsCount);
                        mConfigTextMain.setText("Select Remote Configurations");

                        if(mConfigsSelected == 1) {
                            setEnabled(mConfigLeft, false);
                            setEnabled(mConfigRight, true);
                        } else {
                            setEnabled(mConfigLeft, true);
							setEnabled(mConfigRight, true);
                        }
                    }
                });
                
			mConfigRight.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        mConfigsSelected++;
                        mConfigTextIndicator.setText(mConfigsSelected+"/"+mConfigsCount);
                        mConfigTextMain.setText("Select Remote Configurations");

                        if(mConfigsSelected == mConfigsCount) {
                            setEnabled(mConfigRight, false);
                            setEnabled(mConfigLeft, true);
                        } else {
                            setEnabled(mConfigRight, true);
							setEnabled(mConfigLeft, true);
                        }
                    }
                });
                
			mConfigButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        if(mRemoteCodes.size() != 0) {
                            if(mRemoteCodes.containsKey(mConfigsSelected+"@"+(Constant.REMOTE_KEY_POWER).toLowerCase())) {
                                Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
								mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
								
								TransmitRemoteSignal(mConfigsSelected, (Constant.REMOTE_KEY_POWER).toLowerCase());
                            }
                        }
                    }
                });

			mFinishSetupButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        SaveRemoteToPreference(mNameEditText.getText().toString(), mCategoryEditText.getText().toString());
                    }
                });

			TextChangeListener(mNameEditText, mCategoryEditText, mFinishSetupButton);
            
		} else if(mMode == MODE_REMOTE) {
			View mContentSetup = findViewById(R.id.content_remote_setup);
			mContentSetup.setVisibility(View.GONE);

			try {
                mRemoteCodes = GetRemoteButtonCodes();
                mRemoteLayout = GetRemoteButtonLayout();
				
				LinkedHashMap mCustom = GetRemoteButtonCodesCustom();
				if(mCustom != null) {
					for(LinkedHashMap.Entry entry: mCustom.entrySet()) {
						mRemoteCodes.put(entry.getKey(), entry.getValue());
					}
				}
            } catch (XmlPullParserException e) {} catch (IOException e) {} catch (Exception e) {}

            if(mRemoteCodes != null && mRemoteLayout != null) {
                if(mRemoteLayout.size() == 0){
                    SetupRemoteButtonDefaultAll(""+mConfigsSelected);
                } else {
                    SetupRemoteButtonView(mMainLayout, mRemoteLayout, mMode, true);
                }
            } else if(mRemoteCodes != null && mRemoteLayout == null) {
                SetupRemoteButtonDefaultAll(""+mConfigsSelected);
            }
					
		} else if(mMode == MODE_CUSTOM) {
			View mContentSetup = findViewById(R.id.content_remote_setup);
			mContentSetup.setVisibility(View.GONE);

            try {
                mRemoteCodes = GetRemoteButtonCodes();
                mRemoteLayout = GetRemoteButtonLayout();
				
				LinkedHashMap mCustom = GetRemoteButtonCodesCustom();
				if(mCustom != null) {
					for(LinkedHashMap.Entry entry: mCustom.entrySet()) {
						mRemoteCodes.put(entry.getKey(), entry.getValue());
					}
				}
            } catch (XmlPullParserException e) {} catch (IOException e) {} catch (Exception e) {}
 
            if(mRemoteCodes != null && mRemoteLayout != null) {
                if(mRemoteLayout.size() == 0){
                    SetupRemoteButtonDefaultAll(""+mConfigsSelected);
                } else {
                    SetupRemoteButtonView(mMainLayout, mRemoteLayout, mMode, true);
                }
            } else if(mRemoteCodes != null && mRemoteLayout == null) {
                SetupRemoteButtonDefaultAll(""+mConfigsSelected);
            }  
		}
	}
	
	private void InitBottomSheet() {
		View mBottomSheet = findViewById(R.id.remote_bottom_sheet);
		mBottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet);
		mBottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
				@Override
				public void onStateChanged(@NonNull View bottomSheet, int newState) {
					if(newState == BottomSheetBehavior.STATE_EXPANDED) {
						mIsBottomExpanded = true;

					} else {
						mIsBottomExpanded = false;
					}
				}

				@Override
				public void onSlide(@NonNull View bottomSheet, float slideOffset) {
					// ToDo
				}
			});
	}
    
    private ArrayList GetAllRemoteFromPreference() {
        ArrayList mList = null;

        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(RemoteActivity.this);

        Set<String> mSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));
        if(mSets != null) {
            if(mSets.size()>0) {
                mList = new ArrayList();

                for(String set: mSets) {
                    try {
                        JSONObject jsonObj = new JSONObject(set);
                        Iterator<String> keysItr = jsonObj.keys();
                        LinkedHashMap item = new LinkedHashMap();

                        while(keysItr.hasNext()) {
                            String key = keysItr.next().toString();
                            String value = jsonObj.get(key).toString();

                            item.put(key, value);
                        }

                        mList.add(item);
                    } catch (JSONException e) {
                        mList = new ArrayList();
                    }
                }
            }
        }

        if(mList != null) {
            if(mList.size() > 0) {
                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_name").toString().toLowerCase().compareTo(p2.get("save_name").toString().toLowerCase());
                        }
                    });

                Collections.sort(mList, new Comparator<LinkedHashMap>() {
                        @Override
                        public int compare(LinkedHashMap p1, LinkedHashMap p2) {
                            return p1.get("save_category2").toString().toLowerCase().compareTo(p2.get("save_category2").toString().toLowerCase());
                        }
                    });
            }
        }

        return mList;
	}
    
    private LinkedHashMap GetRemoteButtonCodes() throws XmlPullParserException, IOException {
        /* button_config @ button_name, ir_codes */
        
        LinkedHashMap mMapCodes = null;
        
        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        
        if(mRemoteInfo.getOrDefault("save_codes", "default").toString().equalsIgnoreCase("default")) {
            SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(RemoteActivity.this);
            File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote/oneremote_codes.dio");
            if(mPrefs.getBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false) && file.exists()) {
                BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
                mParser.setInput(buffReader);
            } else {
                String file_path = Constant.ASSET_FILE_CODES;
                InputStream inputStream = getAssets().open(file_path);
                mParser.setInput(inputStream, null);
            }
        } else {
            File file = new File(mRemoteInfo.get("save_codes").toString());
            if(file.exists()) {
                BufferedReader buffReader = new BufferedReader(new FileReader(mRemoteInfo.get("save_codes").toString()));
                mParser.setInput(buffReader);
            } else {
                String file_path = Constant.ASSET_FILE_CODES;
                InputStream inputStream = getAssets().open(file_path);
                mParser.setInput(inputStream, null);
            }
        }

        int eventType = mParser.getEventType();
        boolean found = false;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "remote";
            String subTag = "button";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        mMapCodes = new LinkedHashMap();

                        String mName = mRemoteInfo.get("name").toString();
                        String mCategory = mRemoteInfo.get("category").toString();

                        if(mName.equalsIgnoreCase(mParser.getAttributeValue(null, "name").toString()) && mCategory.equalsIgnoreCase(mParser.getAttributeValue(null, "category").toString())) {
                            found = true;
                        } 
                    } else if(element.equals(subTag)) {
                        if(found) {
                            mMapCodes.put(mParser.getAttributeValue(null, "config").toString()+"@"+mParser.getAttributeValue(null, "name").toString(), mParser.nextText().toString());    
                        }
                    }
                    break;
                case XmlPullParser.END_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        if(found) {
                            return mMapCodes;
                        } 
                    }
                    break;
            }

            eventType = mParser.next();
        }
        
        return mMapCodes;
    }
	
	private LinkedHashMap GetRemoteButtonCodesCustom() throws XmlPullParserException, IOException {
        /* button_config @ button_name, ir_codes */

        LinkedHashMap mMapCodes = null;

        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
		if(file.exists()) {
			BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
			mParser.setInput(buffReader);
		} else {
			return mMapCodes;
		}

        int eventType = mParser.getEventType();
        boolean found = false;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "remote";
            String subTag = "button";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        mMapCodes = new LinkedHashMap();

                        String mName = mRemoteInfo.get("name").toString();
                        String mCategory = mRemoteInfo.get("category").toString();

                        if(mName.equalsIgnoreCase(mParser.getAttributeValue(null, "name").toString()) && mCategory.equalsIgnoreCase(mParser.getAttributeValue(null, "category").toString())) {
                            found = true;
                        } 
                    } else if(element.equals(subTag)) {
                        if(found) {
                            mMapCodes.put(mParser.getAttributeValue(null, "config").toString()+"@"+mParser.getAttributeValue(null, "name").toString(), mParser.nextText().toString());    
                        }
                    }
                    break;
                case XmlPullParser.END_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        if(found) {
                            return mMapCodes;
                        } 
                    }
                    break;
            }

            eventType = mParser.next();
        }

        return mMapCodes;
    }
	
	private LinkedHashMap GetRemoteButtonLayout() throws XmlPullParserException, IOException {
		/* hashmap_row_info, hashmap_buttons */
        /* button_id, hashmap_button_info */ 
        
		/* id, button_id */
        /* name, button_name */
        /* config, button_config */
        /* style, button_style */
        
        LinkedHashMap mMapRow = null;
        LinkedHashMap mMapRowInfo = null;
        LinkedHashMap mMapButton = null;
        LinkedHashMap mMapButtonInfo = null;
        
        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        if(mRemoteInfo.getOrDefault("save_buttons", "default").toString().equalsIgnoreCase("default")) {
            SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(RemoteActivity.this);
            File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote/oneremote_layout.dio");
            if(mPrefs.getBoolean(Constant.PREF_REMOTE_RESOURCES_ONLINE, false) && file.exists()) {
                BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
                mParser.setInput(buffReader);
            } else {
                String file_path = Constant.ASSET_FILE_LAYOUT;
                InputStream inputStream = getAssets().open(file_path);
                mParser.setInput(inputStream, null);
            }
        } else {
            File file = new File(mRemoteInfo.get("save_buttons").toString());
            if(file.exists()) {
                BufferedReader buffReader = new BufferedReader(new FileReader(mRemoteInfo.get("save_buttons").toString()));
                mParser.setInput(buffReader);
            } else {
                String file_path = Constant.ASSET_FILE_LAYOUT;
                InputStream inputStream = getAssets().open(file_path);
                mParser.setInput(inputStream, null);
            }
        }

        int eventType = mParser.getEventType();
        boolean found = false;
        
        String rowID = "";

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "layout";
            String subTag = "row";
            String subsubTag = "button";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        mMapRow = new LinkedHashMap();
                        mMapButton = new LinkedHashMap(); 

                        if(mRemoteInfo.get("category").toString().equalsIgnoreCase(mParser.getAttributeValue(null, "category"))) {
                            found = true;
                        }

                    } else if(element.equals(subTag)) {
                        if(found) { 
                            mMapRowInfo = new LinkedHashMap();
                            
                            rowID = mParser.getAttributeValue(null, "id").toString();
                            
                            mMapRowInfo.put("id", mParser.getAttributeValue(null, "id").toString());
                            mMapRowInfo.put("style", mParser.getAttributeValue(null, "style").toString());
                            mMapRowInfo.put("height", mParser.getAttributeValue(null, "height").toString());
                            mMapRowInfo.put("margin", mParser.getAttributeValue(null, "margin").toString());
                        }
                    } else if(element.equals(subsubTag)) {
                        if(found) {
                            mMapButtonInfo = new LinkedHashMap();
                            
                            mMapButtonInfo.put("id", mParser.getAttributeValue(null, "id").toString());
                            
                            if(mRemoteInfo.getOrDefault("save_buttons", "default").toString().equalsIgnoreCase("default")) {
                                mMapButtonInfo.put("config", mConfigsSelected);
                            } else {
                                mMapButtonInfo.put("config", mParser.getAttributeValue(null, "config").toString());
                            }
                            
                            mMapButtonInfo.put("style", mParser.getAttributeValue(null, "style").toString());
                            mMapButtonInfo.put("name", mParser.nextText().toString());
                            
                            mMapButton.put(mMapButtonInfo.get("id").toString(), mMapButtonInfo);
                        }
                    }
                    break;
                case XmlPullParser.END_TAG:
                    element = mParser.getName();

                    if(element.equals(tag)) {
                        if(found) {
                            return mMapRow;
                        } 
                    } else if(element.equals(subTag)) {
                        if(found) {
                            mMapRow.put(mMapRowInfo, mMapButton);
                            mMapButton = new LinkedHashMap();
                        }
                    }
                    break;
            }

            eventType = mParser.next();
        }

		return mMapRow;
    }
    
    private LinkedHashMap GetRemoteButtonLayoutFromAllButtonViews() {
        /* remote_id @ button_id, RemoteButton */
        
        LinkedHashMap mMapLayout = new LinkedHashMap();
        LinkedHashMap mRowInfo = new LinkedHashMap();
        LinkedHashMap mButtons = new LinkedHashMap();
        LinkedHashMap mButtonInfo = new LinkedHashMap();
        
        String row = "0";
        for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
            RemoteButton mRemoteButton = (RemoteButton) entry.getValue();
            Object obj1 = mRemoteButton.getTag(R.id.remote_row);
            Object obj2 = mRemoteButton.getTag(R.id.remote_style);
            Object obj3 = mRemoteButton.getTag(R.id.remote_margin);
            Object obj4 = mRemoteButton.getTag(R.id.remote_height);
            
            if(obj1 != null && obj2 != null && obj3 != null && obj4 != null) {
                if(!row.equalsIgnoreCase(obj1.toString())) {
                    mMapLayout.put(mRowInfo, mButtons);
                    
                    mRowInfo = new LinkedHashMap();
                    mButtons = new LinkedHashMap();
                    row = obj1.toString();
                } else {
                    mRowInfo.put("id", obj1.toString());
                    mRowInfo.put("style", obj2.toString());
                    mRowInfo.put("height", obj4.toString());
                    mRowInfo.put("margin", obj3.toString());
                }
                
                if(obj2.toString().equalsIgnoreCase("4") || obj2.toString().equalsIgnoreCase("5")) {
                    mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_id).toString());
                    mButtonInfo.put("config", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config).toString());
                    mButtonInfo.put("style", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style).toString());
                    mButtonInfo.put("name", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name).toString());

                    mButtons.put(mButtonInfo.get("id").toString(), mButtonInfo);

                    mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_id).toString());
                    mButtonInfo.put("config", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config).toString());
                    mButtonInfo.put("style", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_style).toString());
                    mButtonInfo.put("name", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_name).toString());

                    mButtons.put(mButtonInfo.get("id").toString(), mButtonInfo);

                    mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_id).toString());
                    mButtonInfo.put("config", mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_config).toString());
                    mButtonInfo.put("style", mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_style).toString());
                    mButtonInfo.put("name", mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_name).toString());

                    mButtons.put(mButtonInfo.get("id").toString(), mButtonInfo);
                } else {
                    mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_id).toString());
                    mButtonInfo.put("config", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config).toString());
                    mButtonInfo.put("style", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style).toString());
                    mButtonInfo.put("name", mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name).toString());

                    mButtons.put(mButtonInfo.get("id").toString(), mButtonInfo);
                }
            }
        }
        
        mMapLayout.put(mRowInfo, mButtons);
        
        return mMapLayout;
    }
    
    private String GenerateRemoteButtonLayoutFile() {
        String mPath = null;

        try {
            File mRoot = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/.remote");
            if (!mRoot.exists()) {
                mRoot.mkdirs();
            }

            File mFile = new File(mRoot, mRemoteInfo.get("save_id").toString()+".dio");
            FileWriter mWriter = new FileWriter(mFile);

            String mContent = "";
            mContent = "<oneremote>\n\n";
            mContent = mContent + "\t<layout category=\""+mRemoteInfo.get("category").toString().toLowerCase()+"\">\n";

            String row = "0";
            for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                RemoteButton mRemoteButton = (RemoteButton) entry.getValue();
                Object obj1 = mRemoteButton.getTag(R.id.remote_row);
                Object obj2 = mRemoteButton.getTag(R.id.remote_style);
                Object obj3 = mRemoteButton.getTag(R.id.remote_margin);
                Object obj4 = mRemoteButton.getTag(R.id.remote_height);

                if(obj1 != null && obj2 != null && obj3 != null && obj4 != null) {
                    if(!row.equalsIgnoreCase(obj1.toString())) {
                        if(!row.equalsIgnoreCase("0")) {
                            mContent = mContent + "\t\t</row>\n";
                        }
                        mContent = mContent + "\t\t<row id=\""+obj1.toString()+"\" style=\""+obj2.toString()+"\" height=\""+obj4.toString()+"\" margin=\""+obj3.toString()+"\">\n";
                        
                        row = obj1.toString();
                    }

                    switch(obj2.toString()) {
                        case "4":
                            if(!mRemoteButton.getRemoteButton1().equalsIgnoreCase("empty")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            if(!mRemoteButton.getRemoteButton2().equalsIgnoreCase("empty")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            if(!mRemoteButton.getRemoteMiddleText().equalsIgnoreCase("empty") && !mRemoteButton.getRemoteMiddleText().equalsIgnoreCase("add")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            break;
                        case "5":
                            if(!mRemoteButton.getRemoteButton1().equalsIgnoreCase("empty")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            if(!mRemoteButton.getRemoteButton2().equalsIgnoreCase("empty")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            if(!mRemoteButton.getRemoteMiddleText().equalsIgnoreCase("empty") && !mRemoteButton.getRemoteMiddleText().equalsIgnoreCase("add")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonMiddleTextView().getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            break;
                        default:
                            if(!mRemoteButton.getRemoteButton1().equalsIgnoreCase("empty")) {
                                mContent = mContent + "\t\t\t<button id=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_id).toString()+"\" config=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config).toString()+"\" style=\""+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style).toString()+"\">"+mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name).toString()+"</button>\n";                                    
                            }
                            break;
                    }
                }  
            }

            mContent = mContent + "\t\t</row>\n";
            mContent = mContent + "\t</layout>\n\n";
            mContent = mContent + "</oneremote>\n";

            mWriter.append(mContent);
            mWriter.flush();
            mWriter.close();

            mPath = mFile.getAbsolutePath();

        } catch (IOException e) {} catch (Exception e) {
            mPath = null;
            Toast.makeText(this,e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return mPath;
	}
	
	private void OnRemoteButtonClicked(final View view, final String button) {
		Object mObj1 = view.getTag(R.id.button_id);
        Object mObj2 = view.getTag(R.id.button_name);
        Object mObj3 = view.getTag(R.id.button_config);
        Object mObj4 = view.getTag(R.id.button_style);
        Object mObj5 = view.getTag(R.id.button_row);
        Object mObj6 = view.getTag(R.id.button_height);
        
        if(mObj1 != null && mObj2 != null && mObj3 != null && mObj4 != null && mObj5 != null && mObj6 != null) {
            if(mMode == MODE_REMOTE) {
                if(Boolean.parseBoolean(mRemoteInfo.getOrDefault("save_vibrate", true).toString())) {
                    Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
                }
                
                if(Boolean.parseBoolean(mRemoteInfo.getOrDefault("save_sound", true).toString())) {   
                    //view.playSoundEffect(SoundEffectConstants.CLICK);
                    AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    audioManager.playSoundEffect(SoundEffectConstants.CLICK);
                }
                
                switch(mObj2.toString()) {
                    case "123":
                        SetupRemoteButtonNumpad(mObj3.toString());
                        break;
                    case "numpad":
                        SetupRemoteButtonNumpad(mObj3.toString());
                        break;
                    case "more":
                        SetupRemoteButtonMore(mObj3.toString());
                        break;
                    default:
                        TransmitRemoteSignal(Integer.parseInt(mObj3.toString()), button);
                        break;
                }
            } else if(mMode == MODE_CUSTOM) {
                if(mIsRowEditorVisible) {
                    ShowRemoteButtonAlertDialog(view, button);
                } else {
                    ShowRemoteRowAlertDialog(view, button);
                }
            }
        } 
        
        //ZShowAlertDialogRemoteButtonInfo(view);
	}
	
	private void OnRemoteButtonLongClicked(final View view, final String button) {
		Object mObj1 = view.getTag(R.id.button_id);
        Object mObj2 = view.getTag(R.id.button_name);
        Object mObj3 = view.getTag(R.id.button_config);
        Object mObj4 = view.getTag(R.id.button_style);
        Object mObj5 = view.getTag(R.id.button_row);

        if(mObj1 != null && mObj2 != null && mObj3 != null && mObj4 != null && mObj5 != null) {
            if(mMode == MODE_REMOTE) {
                if(Boolean.parseBoolean(mRemoteInfo.getOrDefault("save_vibrate", false).toString())) {
                    Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
                }

                
            } else if(mMode == MODE_CUSTOM) {
                ShowRemoteButtonAlertDialog(view, button);
            }
        } 

        //ZShowAlertDialogRemoteButtonInfo(view);
	}
	
	private void SaveRemoteToPreference(String name, String category) {
		final ProgressDialog mProgressDialog = new ProgressDialog(this);
		mProgressDialog.setCancelable(false);
		mProgressDialog.setMessage("Finishing Setup...");
		
		int[] attrs = {android.R.attr.windowBackground};
		TypedArray typedValue = getTheme().obtainStyledAttributes(R.attr.alertDialogTheme, attrs); 
		int color = typedValue.getColor(0, Color.WHITE);
		mProgressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(color));
        
		mProgressDialog.show();
		
		mRemoteInfo.put("save_id", getDateTime());
		mRemoteInfo.put("save_name", name);
		mRemoteInfo.put("save_category1", mRemoteInfo.get("category"));
		mRemoteInfo.put("save_category2", category.trim());
		mRemoteInfo.put("save_config", mConfigsSelected);
		mRemoteInfo.put("save_logo", mRemoteInfo.get("category"));
		mRemoteInfo.put("save_vibrate", true);
        mRemoteInfo.put("save_sound", true);
		mRemoteInfo.put("save_buttons", "default");
        mRemoteInfo.put("save_codes", "default");

		JSONObject jsonObj = new JSONObject(mRemoteInfo);

		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(RemoteActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();

		Set<String> mNewSets = new HashSet<String>(mPrefs.getStringSet(Constant.PREF_REMOTE_LIST, new HashSet<String>()));

		if(mNewSets == null) {
			mNewSets = new HashSet<>();
		}

		mNewSets.add(jsonObj.toString());

		editor.putStringSet(Constant.PREF_REMOTE_LIST, mNewSets);
		editor.apply();
		
		new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					mProgressDialog.dismiss();

					JSONObject jsonObj = new JSONObject(mRemoteInfo);
					Intent intent = new Intent(RemoteActivity.this, RemoteActivity.class);
					intent.putExtra("data", jsonObj.toString());
					intent.putExtra("mode", RemoteActivity.MODE_REMOTE);
					startActivity(intent);
					finish();

				}
			}, 1000);		
	}
	
	private void SaveRemoteToFile() {
		if(mMode == MODE_CUSTOM) {
			if(checkPermission()) {
				AlertDialog.Builder alertBuild = new AlertDialog.Builder(RemoteActivity.this); 
				alertBuild.setTitle("Save Remote");
				alertBuild.setMessage("Save Remote Layout Changes?");
				alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
                            mHasChanges = false;
                            
							String mPath = GenerateRemoteButtonLayoutFile();
							if(mPath != null) {
								Snackbar mSnackbar = Snackbar.make(mParentLayout, Snackbar.LENGTH_LONG);
								mSnackbar.setText("Remote Layout Successfully Saved.", getResources().getColor(R.color.white));
								mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_circle_check), getResources().getColor(R.color.white));
								mSnackbar.setSnackColor(getResources().getColor(R.color.green_500));
								mSnackbar.show();
								
								UpdateRemoteFromPreference("save_buttons", mPath);
							} else {
								Snackbar mSnackbar = Snackbar.make(mParentLayout, Snackbar.LENGTH_LONG);
								mSnackbar.setText("An Error Occured While Saving Remote Layout.", getResources().getColor(R.color.white));
								mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_cross), getResources().getColor(R.color.white));
								mSnackbar.setSnackColor(getResources().getColor(R.color.red_500));
								mSnackbar.show();
							}
						}
					});
				alertBuild.setNegativeButton("Cancel", null);

				AlertDialog alert = alertBuild.create();
				alert.show();
			} else {
				requestPermission();
				mFlag = true;
			}
		}
	}
    
    private ViewGroup SetupRemoteButtonView(ViewGroup parent, LinkedHashMap layout, int mode, boolean save) {
        /* hashmap_row_info, hashmap_buttons */
        /* button_id, hashmap_button_info */ 

        /* id, button_id */
        /* name, button_name */
        /* config, button_config */
        /* style, button_style */
        
        /* row style 1 = 3 buttons */
        /* row style 2 = 4 buttons */
        /* row style 3 = 3x3 buttons  */
        /* row style 4 = 3 volume */
        /* row style 5 = 4 volume */
        
        //View mView = null;
        
        if(layout != null) {
            //mView = new LinearLayout(this);
            
            //((LinearLayout)mView).setOrientation(LinearLayout.VERTICAL);
            //((LinearLayout)mView).setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            
            for(LinkedHashMap.Entry entry: layout.entrySet()) {
                View mRemoteRow = new LinearLayout(this);
                ((LinearLayout)mRemoteRow).setOrientation(LinearLayout.HORIZONTAL);
                ((LinearLayout)mRemoteRow).setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

                LinkedHashMap mRowInfo = (LinkedHashMap) entry.getKey();
                String mID = mRowInfo.get("id").toString();
                String mStyle = mRowInfo.get("style").toString();
                String mHeight = mRowInfo.get("height").toString();
                String mMargin = mRowInfo.get("margin").toString();
                
                int marginLeft = 0;
                int marginTop = 0;
                int marginRight = 0;
                int marginBottom = 0;
                
                LinkedHashMap mButtons = (LinkedHashMap) entry.getValue();
                String[] mDefaultButtonIDs = null;
                
                if(mHeight.contains("*")) {
                    mHeight = RemoteButton.DEFAULT_BUTTON_HEIGHT+"";
                }
                
                if(mMargin.contains(",")) {
                    String[] margins = mMargin.split(",");
                    if(margins.length == 4) {
                        marginLeft = margins[0]!=null && margins[0].matches("[0-9]+") ? Integer.parseInt(margins[0]) : 0;
                        marginTop = margins[1]!=null && margins[1].matches("[0-9]+") ? Integer.parseInt(margins[1]) : 0;
                        marginRight = margins[2]!=null && margins[2].matches("[0-9]+") ? Integer.parseInt(margins[2]) : 0;
                        marginBottom = margins[3]!=null && margins[3].matches("[0-9]+") ? Integer.parseInt(margins[3]) : 0;
                    }
                }
                
                MarginLayoutParams mMarginLayout = null;
                LinearLayout.LayoutParams mChildParam = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT);
                 
                switch(mStyle) {
                    case "1":
                        ((LinearLayout)mRemoteRow).setWeightSum(0.9f);
                        
                        mMarginLayout = (MarginLayoutParams) mRemoteRow.getLayoutParams();
                        mMarginLayout.leftMargin = (int) ViewUtils.dpToPx(this, marginLeft);
                        mMarginLayout.topMargin = (int) ViewUtils.dpToPx(this, marginTop);
                        mMarginLayout.rightMargin = (int) ViewUtils.dpToPx(this, marginRight);
                        mMarginLayout.bottomMargin = (int) ViewUtils.dpToPx(this, marginBottom);
                        
                        mChildParam.weight = 0.3f;
                        
                        mDefaultButtonIDs = new String[]{"a", "b", "c"};
                        
                        for(String defaultID: mDefaultButtonIDs) {
                            RemoteButton button = new RemoteButton(this);
                            button.setRemoteButtonType(RemoteButton.TYPE_SINGLE);
                            button.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            if(mode == MODE_REMOTE) {
                                button.setVisibility(View.INVISIBLE);
                            }
                            
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, defaultID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                            
                            if(mButtons.containsKey(defaultID)) {
                                LinkedHashMap mButtonInfo = (LinkedHashMap) mButtons.get(defaultID);
                                int style = mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton1(mButtonInfo.getOrDefault("name", "EMPTY").toString(), style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, mButtonInfo.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mButtonInfo.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                                button.setVisibility(View.VISIBLE);
                            }
                            
                            button.setTag(R.id.remote_id, defaultID);
                            button.setTag(R.id.remote_row, mID);
                            button.setTag(R.id.remote_style, mStyle);
                            button.setTag(R.id.remote_margin, mMargin);
                            button.setTag(R.id.remote_height, mHeight);
                            
                            button.UpdateRemote();
                            button.setLayoutParams(mChildParam);
                            
                            button.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                                    @Override
                                    public void onClick(View view, String button) {
                                        OnRemoteButtonClicked(view, button);
                                    }
                                });
                                
                            button.setOnRemoteLongClickListener(new RemoteButton.OnRemoteLongClickListener() {
                                    @Override
                                    public void onLongClick(View view, String button) {
                                        OnRemoteButtonLongClicked(view, button);
                                    }
                                });
                                
                            ((LinearLayout)mRemoteRow).addView(button);
                            
                            if(save) {
                                mRemoteAllButtonViews.put(mID+"@"+defaultID, button);
                            } else {
                                mRemotePartialButtonViews.put(mID+"@"+defaultID, button);
                                button.setOnRemoteLongClickListener(null);
                            }
                        }
                        break;
                    case "2":
                        ((LinearLayout)mRemoteRow).setWeightSum(1f);
                        
                        mMarginLayout = (MarginLayoutParams) mRemoteRow.getLayoutParams();
                        mMarginLayout.leftMargin = (int) ViewUtils.dpToPx(this, marginLeft);
                        mMarginLayout.topMargin = (int) ViewUtils.dpToPx(this, marginTop);
                        mMarginLayout.rightMargin = (int) ViewUtils.dpToPx(this, marginRight);
                        mMarginLayout.bottomMargin = (int) ViewUtils.dpToPx(this, marginBottom);
                        
                        mChildParam.weight = 0.25f;

                        mDefaultButtonIDs = new String[]{"a", "b", "c", "d"};

                        for(String defaultID: mDefaultButtonIDs) {
                            RemoteButton button = new RemoteButton(this);
                            button.setRemoteButtonType(RemoteButton.TYPE_SINGLE);
                            button.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            if(mode == MODE_REMOTE) {
                                button.setVisibility(View.INVISIBLE);
                            }
                            
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, defaultID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);

                            if(mButtons.containsKey(defaultID)) {
                                LinkedHashMap mButtonInfo = (LinkedHashMap) mButtons.get(defaultID);
                                int style = mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton1(mButtonInfo.getOrDefault("name", "EMPTY").toString(), style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, mButtonInfo.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mButtonInfo.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                                button.setVisibility(View.VISIBLE);
                            }
                            
                            button.setTag(R.id.remote_id, defaultID);
                            button.setTag(R.id.remote_row, mID);
                            button.setTag(R.id.remote_style, mStyle);
                            button.setTag(R.id.remote_margin, mMargin);
                            button.setTag(R.id.remote_height, mHeight);

                            button.UpdateRemote();
                            button.setLayoutParams(mChildParam);
                            
                            button.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                                    @Override
                                    public void onClick(View view, String button) {
                                        OnRemoteButtonClicked(view, button);
                                    }
                                });

                            button.setOnRemoteLongClickListener(new RemoteButton.OnRemoteLongClickListener() {
                                    @Override
                                    public void onLongClick(View view, String button) {
                                        OnRemoteButtonLongClicked(view, button);
                                    }
                                });
                                
                            ((LinearLayout)mRemoteRow).addView(button);
                            
                            if(save) {
                                mRemoteAllButtonViews.put(mID+"@"+defaultID, button);
                            } else {
                                mRemotePartialButtonViews.put(mID+"@"+defaultID, button);
                                button.setOnRemoteLongClickListener(null);
                            }
                        }
                        break;
                    case "3":
                        ((LinearLayout)mRemoteRow).setWeightSum(1f);
                        
                        View mSubRemoteRow1 = new LinearLayout(this);
                        ((LinearLayout)mSubRemoteRow1).setOrientation(LinearLayout.VERTICAL);
                        ((LinearLayout)mSubRemoteRow1).setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
                        
                        View mSubRemoteRow2 = new LinearLayout(this);
                        ((LinearLayout)mSubRemoteRow2).setOrientation(LinearLayout.HORIZONTAL);
                        ((LinearLayout)mSubRemoteRow2).setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
                        ((LinearLayout)mSubRemoteRow2).setWeightSum(0.9f);

                        mMarginLayout = (MarginLayoutParams) mRemoteRow.getLayoutParams();
                        mMarginLayout.leftMargin = (int) ViewUtils.dpToPx(this, marginLeft);
                        mMarginLayout.topMargin = (int) ViewUtils.dpToPx(this, marginTop);
                        mMarginLayout.rightMargin = (int) ViewUtils.dpToPx(this, marginRight);
                        mMarginLayout.bottomMargin = (int) ViewUtils.dpToPx(this, marginBottom);

                        mChildParam.weight = 0.3f;

                        mDefaultButtonIDs = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i"};

                        for(String defaultID: mDefaultButtonIDs) {
                            RemoteButton button = new RemoteButton(this);
                            button.setRemoteButtonType(RemoteButton.TYPE_SINGLE);
                            button.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            if(mode == MODE_REMOTE) {
                                button.setVisibility(View.INVISIBLE);
                            }
                            
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, defaultID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);

                            if(mButtons.containsKey(defaultID)) {
                                LinkedHashMap mButtonInfo = (LinkedHashMap) mButtons.get(defaultID);
                                int style = mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton1(mButtonInfo.getOrDefault("name", "EMPTY").toString(), style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, mButtonInfo.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mButtonInfo.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                                button.setVisibility(View.VISIBLE);
                            }
                            
                            button.setTag(R.id.remote_id, defaultID);
                            button.setTag(R.id.remote_row, mID);
                            button.setTag(R.id.remote_style, mStyle);
                            button.setTag(R.id.remote_margin, mMargin);
                            button.setTag(R.id.remote_height, mHeight);

                            button.UpdateRemote();
                            button.setLayoutParams(mChildParam);
                            
                            button.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                                    @Override
                                    public void onClick(View view, String button) {
                                        OnRemoteButtonClicked(view, button);
                                    }
                                });

                            button.setOnRemoteLongClickListener(new RemoteButton.OnRemoteLongClickListener() {
                                    @Override
                                    public void onLongClick(View view, String button) {
                                        OnRemoteButtonLongClicked(view, button);
                                    }
                                });
                                
                            ((LinearLayout)mSubRemoteRow2).addView(button);
                            
                            if(save) {
                                mRemoteAllButtonViews.put(mID+"@"+defaultID, button);
                            } else {
                                mRemotePartialButtonViews.put(mID+"@"+defaultID, button);
                                button.setOnRemoteLongClickListener(null);
                            }
                            
                            if(defaultID.equalsIgnoreCase("c") || defaultID.equalsIgnoreCase("f") || defaultID.equalsIgnoreCase("i")) {
                                ((LinearLayout)mSubRemoteRow1).addView(mSubRemoteRow2);
                                
                                mSubRemoteRow2 = new LinearLayout(this);
                                ((LinearLayout)mSubRemoteRow2).setOrientation(LinearLayout.HORIZONTAL);
                                ((LinearLayout)mSubRemoteRow2).setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
                                ((LinearLayout)mSubRemoteRow2).setWeightSum(0.9f);
                            }
                        }
                        
                        ((LinearLayout)mRemoteRow).addView(mSubRemoteRow1);
                        break;
                    case "4":
                        ((LinearLayout)mRemoteRow).setWeightSum(0.9f);

                        mMarginLayout = (MarginLayoutParams) mRemoteRow.getLayoutParams();
                        mMarginLayout.leftMargin = (int) ViewUtils.dpToPx(this, marginLeft);
                        mMarginLayout.topMargin = (int) ViewUtils.dpToPx(this, marginTop);
                        mMarginLayout.rightMargin = (int) ViewUtils.dpToPx(this, marginRight);
                        mMarginLayout.bottomMargin = (int) ViewUtils.dpToPx(this, marginBottom);

                        mChildParam.weight = 0.3f;

                        mDefaultButtonIDs = new String[]{"a,b", "c,d", "e,f"};

                        for(String defaultID: mDefaultButtonIDs) {
                            RemoteButton button = new RemoteButton(this);
                            button.setRemoteButtonType(RemoteButton.TYPE_DUAL);
                            button.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            button.setRemoteButton2("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            button.setRemoteMiddleText("ADD");
                            
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, defaultID.split(",")[0]);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_id, defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_name, "ADD");
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_row, mID);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_style, RemoteButton.STYLE_TEXT);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_config, mConfigsSelected); 
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_height, RemoteButton.DEFAULT_TEXT_MIDDLE_HEIGHT);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_id, defaultID.split(",")[1]);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mHeight);
                            
                            if(mode == MODE_REMOTE) {
                                button.UpdateRemote();
                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }
                            
                            if(mButtons.containsKey(defaultID.split(",")[0])) {
                                LinkedHashMap mButtonInfo1 = (LinkedHashMap) mButtons.get(defaultID.split(",")[0]);
                                int style = mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton1(mButtonInfo1.getOrDefault("name", "EMPTY").toString(), style); 
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, mButtonInfo1.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mButtonInfo1.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.VISIBLE);
                                
                                button.UpdateRemote();
                                
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }
                            
                            if(mButtons.containsKey(defaultID.split(",")[1])) {
                                LinkedHashMap mButtonInfo2 = (LinkedHashMap) mButtons.get(defaultID.split(",")[1]);
                                int style = mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton2(mButtonInfo2.getOrDefault("name", "EMPTY").toString(), style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_id, mButtonInfo2.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mButtonInfo2.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mHeight);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.VISIBLE);
                                
                                int visibility = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                
                                button.UpdateRemote();
                                
                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }
                            
                            if(mButtons.containsKey(defaultID.split(",")[0]+defaultID.split(",")[1]+"_text")) {
                                LinkedHashMap mButtonInfo3 = (LinkedHashMap) mButtons.get(defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");
                                
                                button.setRemoteMiddleText(mButtonInfo3.getOrDefault("name", "EMPTY").toString());
                                button.getRemoteButtonMiddleTextView().setVisibility(View.VISIBLE);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_id, defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_name, mButtonInfo3.getOrDefault("name", "EMPTY").toString());
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_row, mID);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_style, RemoteButton.STYLE_TEXT);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_config, mButtonInfo3.getOrDefault("config", mConfigsSelected).toString()); 
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_height, RemoteButton.DEFAULT_TEXT_MIDDLE_HEIGHT);
                                
                                int visibility1 = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                int visibility2 = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                
                                button.UpdateRemote();

                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                            }
                            
                            if(mode == MODE_CUSTOM) {
                                button.UpdateRemote();
                            }

                            button.setLayoutParams(mChildParam);
                            
                            button.setTag(R.id.remote_id, defaultID);
                            button.setTag(R.id.remote_row, mID);
                            button.setTag(R.id.remote_style, mStyle);
                            button.setTag(R.id.remote_margin, mMargin);
                            button.setTag(R.id.remote_height, mHeight);
                            
                            button.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                                    @Override
                                    public void onClick(View view, String button) {
                                        OnRemoteButtonClicked(view, button);
                                    }
                                });

                            button.setOnRemoteLongClickListener(new RemoteButton.OnRemoteLongClickListener() {
                                    @Override
                                    public void onLongClick(View view, String button) {
                                        OnRemoteButtonLongClicked(view, button);
                                    }
                                });
                                
                            ((LinearLayout)mRemoteRow).addView(button);
                            
                            if(save) {
                                mRemoteAllButtonViews.put(mID+"@"+defaultID, button);
                            } else {
                                mRemotePartialButtonViews.put(mID+"@"+defaultID, button);
                                button.setOnRemoteLongClickListener(null);
                            }
                        }
                        break;
                    case "5":
                        ((LinearLayout)mRemoteRow).setWeightSum(1f);

                        mMarginLayout = (MarginLayoutParams) mRemoteRow.getLayoutParams();
                        mMarginLayout.leftMargin = (int) ViewUtils.dpToPx(this, marginLeft);
                        mMarginLayout.topMargin = (int) ViewUtils.dpToPx(this, marginTop);
                        mMarginLayout.rightMargin = (int) ViewUtils.dpToPx(this, marginRight);
                        mMarginLayout.bottomMargin = (int) ViewUtils.dpToPx(this, marginBottom);

                        mChildParam.weight = 0.25f;

                        mDefaultButtonIDs = new String[]{"a,b", "c,d", "e,f", "g,h"};

                        for(String defaultID: mDefaultButtonIDs) {
                            RemoteButton button = new RemoteButton(this);
                            button.setRemoteButtonType(RemoteButton.TYPE_DUAL);
                            button.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            button.setRemoteButton2("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE, Integer.parseInt(mHeight));
                            button.setRemoteMiddleText("ADD");

                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, defaultID.split(",")[0]);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_id, defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_name, "ADD");
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_row, mID);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_style, RemoteButton.STYLE_TEXT);
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_config, mConfigsSelected); 
                            button.getRemoteButtonMiddleTextView().setTag(R.id.button_height, RemoteButton.DEFAULT_TEXT_MIDDLE_HEIGHT);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_id, defaultID.split(",")[1]);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mConfigsSelected);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_row, mID);
                            button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mHeight);
                            
                            if(mode == MODE_REMOTE) {
                                button.UpdateRemote();
                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }

                            if(mButtons.containsKey(defaultID.split(",")[0])) {
                                LinkedHashMap mButtonInfo1 = (LinkedHashMap) mButtons.get(defaultID.split(",")[0]);
                                int style = mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo1.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton1(mButtonInfo1.getOrDefault("name", "EMPTY").toString(), style); 
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_id, mButtonInfo1.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mButtonInfo1.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mHeight);
                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.VISIBLE);

                                button.UpdateRemote();
                                
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.INVISIBLE);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }

                            if(mButtons.containsKey(defaultID.split(",")[1])) {
                                LinkedHashMap mButtonInfo2 = (LinkedHashMap) mButtons.get(defaultID.split(",")[1]);
                                int style = mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE)!=null && mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString().matches("[0-9]+") ? Integer.parseInt(mButtonInfo2.getOrDefault("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE).toString()) : RemoteButton.STYLE_IMAGE_IF_AVAILABLE;
                                
                                button.setRemoteButton2(mButtonInfo2.getOrDefault("name", "EMPTY").toString(), style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_id, mButtonInfo2.getOrDefault("id", 0));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mButtonInfo2.getOrDefault("config", mConfigsSelected));
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, style);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_row, mID);
                                button.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mHeight);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.VISIBLE);

                                int visibility = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();

                                button.UpdateRemote();

                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility);
                                button.getRemoteButtonMiddleTextView().setVisibility(View.INVISIBLE);
                            }

                            if(mButtons.containsKey(defaultID.split(",")[0]+defaultID.split(",")[1]+"_text")) {
                                LinkedHashMap mButtonInfo3 = (LinkedHashMap) mButtons.get(defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");

                                button.setRemoteMiddleText(mButtonInfo3.getOrDefault("name", "EMPTY").toString());
                                button.getRemoteButtonMiddleTextView().setVisibility(View.VISIBLE);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_id, defaultID.split(",")[0]+defaultID.split(",")[1]+"_text");
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_name, mButtonInfo3.getOrDefault("name", "EMPTY").toString());
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_row, mID);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_style, RemoteButton.STYLE_TEXT);
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_config, mButtonInfo3.getOrDefault("config", mConfigsSelected).toString());
                                button.getRemoteButtonMiddleTextView().setTag(R.id.button_height, RemoteButton.DEFAULT_TEXT_MIDDLE_HEIGHT);
                                
                                int visibility1 = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                int visibility2 = button.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();

                                button.UpdateRemote();

                                button.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                                button.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                            }
                            
                            if(mode == MODE_CUSTOM) {
                                button.UpdateRemote();
                            }

                            button.setLayoutParams(mChildParam);
                            
                            button.setTag(R.id.remote_id, defaultID);
                            button.setTag(R.id.remote_row, mID);
                            button.setTag(R.id.remote_style, mStyle);
                            button.setTag(R.id.remote_margin, mMargin);
                            button.setTag(R.id.remote_height, mHeight);
                            
                            button.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                                    @Override
                                    public void onClick(View view, String button) {
                                        OnRemoteButtonClicked(view, button);
                                    }
                                });

                            button.setOnRemoteLongClickListener(new RemoteButton.OnRemoteLongClickListener() {
                                    @Override
                                    public void onLongClick(View view, String button) {
                                        OnRemoteButtonLongClicked(view, button);
                                    }
                                });
                                
                            ((LinearLayout)mRemoteRow).addView(button);
                            
                            if(save) {
                                mRemoteAllButtonViews.put(mID+"@"+defaultID, button);
                            } else {
                                mRemotePartialButtonViews.put(mID+"@"+defaultID, button);
                                button.setOnRemoteLongClickListener(null);
                            }
                        }
                        break;   
                }
                
                mRemoteRow.setTag(R.id.row_id, mID);
                mRemoteRow.setTag(R.id.row_margin, mMargin);
                //((LinearLayout)mView).addView(mRemoteRow);
                parent.addView(mRemoteRow);
            }
        }
        
        return parent;
    }
    
    private void SetupRemoteButtonDefaultAll(String config) {
        LinkedHashMap mRowLayout = new LinkedHashMap();
        LinkedHashMap mRemoteCodesTemp = new LinkedHashMap(mRemoteCodes);

        int rows = (int) Math.ceil(mRemoteCodesTemp.size()/3);
        int cols = 3;
        String[] buttonIDs = {"a", "b", "c"};
        LinkedHashMap temp = new LinkedHashMap();

        for(int i=0; i<rows; i++) {
            LinkedHashMap mRowInfo = new LinkedHashMap();
            mRowInfo.put("id", (i+1));
            mRowInfo.put("style", "1");
            mRowInfo.put("height", "*");
            mRowInfo.put("margin", "0,0,0,10");
            
            int j=0;
            LinkedHashMap mButton = new LinkedHashMap();
            for(LinkedHashMap.Entry entry: mRemoteCodesTemp.entrySet()) {
                if(!temp.containsKey(entry.getKey())) {
                    LinkedHashMap mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", buttonIDs[j]);
                    mButtonInfo.put("config", config);   
                    mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                    mButtonInfo.put("name", entry.getKey().toString().split("@")[1]);

                    mButton.put(buttonIDs[j], mButtonInfo);
                    temp.put(entry.getKey(), entry.getValue());
                    j++;

                    if(j == cols) {
                        break;
                    }
                }
            }

            mRowLayout.put(mRowInfo, mButton);
        }

        
        SetupRemoteButtonView(mMainLayout, mRowLayout, mMode, true);
	}
	
	private void SetupRemoteButtonNumpad(String config) {
        LinearLayout mBottomSheetContent = findViewById(R.id.content_bottom_sheet_layout);
		mBottomSheetContent.removeAllViews();
        
        LinkedHashMap mRowLayout = new LinkedHashMap();
        
        int rows = 4;
        int cols = 3;
        String[] buttonIDs = {"a", "b", "c", "a", "b", "c", "a", "b", "c", "a", "b", "c"};
        String[] buttonNames = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "source", "switch"};
        
        for(int i=0; i<rows; i++) {
            LinkedHashMap mRowInfo = new LinkedHashMap();
            mRowInfo.put("id", (i+1));
            mRowInfo.put("style", "1");
            mRowInfo.put("height", "*");
            if(i == rows-1) {
                mRowInfo.put("margin", "0,0,0,10");
            } else {
                mRowInfo.put("margin", "0,0,0,0");
            }
            
            LinkedHashMap mButton = new LinkedHashMap();
            for(int j=i*cols; j<(cols+(i*cols)); j++) {
                LinkedHashMap mButtonInfo = new LinkedHashMap();
                mButtonInfo.put("id", buttonIDs[j]);
                mButtonInfo.put("config", config);
                if(buttonNames[j].equalsIgnoreCase("switch")) {
                    mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                } else {
                    mButtonInfo.put("style", RemoteButton.STYLE_TEXT);
                }
                mButtonInfo.put("name", buttonNames[j]);
                mButton.put(buttonIDs[j], mButtonInfo);
            }
            
            mRowLayout.put(mRowInfo, mButton);
        }
        
		//View mNumPad = SetupRemoteButtonView(mRowLayout, mMode);
		//mBottomSheetContent.addView(mNumPad);
        SetupRemoteButtonView(mBottomSheetContent, mRowLayout, mMode, true);
        
		mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
	}
	
	private void SetupRemoteButtonMore(String config) {
		LinearLayout mBottomSheetContent = findViewById(R.id.content_bottom_sheet_layout);
		mBottomSheetContent.removeAllViews();
        
        LinkedHashMap mRowLayout = new LinkedHashMap();
        LinkedHashMap mRemoteCodesTemp = new LinkedHashMap(mRemoteCodes);

        String[] buttonNumpadNames = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "source", "switch"};
        
        if(mRemoteLayout != null && mRemoteCodes != null) {
            for(LinkedHashMap.Entry entry1: mRemoteCodes.entrySet()) {
                for(LinkedHashMap.Entry entry2: mRemoteLayout.entrySet()) {
                    LinkedHashMap mButtons = (LinkedHashMap) entry2.getValue();
                    for(LinkedHashMap.Entry entry3: mButtons.entrySet()) {
                        LinkedHashMap mButtonInfo = (LinkedHashMap) entry3.getValue();
                        
                        if(mButtonInfo.getOrDefault("name", "EMPTY").toString().equalsIgnoreCase(entry1.getKey().toString().split("@")[1])) {
                            mRemoteCodesTemp.remove(entry1.getKey());
                        }
                    }
                }
                
                for(String numpad: buttonNumpadNames) {
                    if(numpad.equalsIgnoreCase(entry1.getKey().toString().split("@")[1])) {
                        mRemoteCodesTemp.remove(entry1.getKey());
                    }
                }
            }
        }
        
        int rows = (int) Math.ceil(mRemoteCodesTemp.size()/4);
        int cols = 4;
        String[] buttonIDs = {"a", "b", "c", "d"};
        LinkedHashMap temp = new LinkedHashMap();
        
        for(int i=0; i<rows; i++) {
            LinkedHashMap mRowInfo = new LinkedHashMap();
            mRowInfo.put("id", (i+1));
            mRowInfo.put("style", "2");
            mRowInfo.put("height", "*");
            if(i == rows-1) {
                mRowInfo.put("margin", "0,0,0,10");
            } else {
                mRowInfo.put("margin", "0,0,0,0");
            }

            int j=0;
            LinkedHashMap mButton = new LinkedHashMap();
            for(LinkedHashMap.Entry entry: mRemoteCodesTemp.entrySet()) {
                if(!temp.containsKey(entry.getKey())) {
                    LinkedHashMap mButtonInfo = new LinkedHashMap();
                    mButtonInfo.put("id", buttonIDs[j]);
                    mButtonInfo.put("config", config);   
                    mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                    mButtonInfo.put("name", entry.getKey().toString().split("@")[1]);

                    mButton.put(buttonIDs[j], mButtonInfo);
                    temp.put(entry.getKey(), entry.getValue());
                    j++;
                    
                    if(j == cols) {
                        break;
                    }
                }
            }
            
            mRowLayout.put(mRowInfo, mButton);
        }
        
		//View mMore = SetupRemoteButtonView(mRowLayout, mMode);
        //mBottomSheetContent.addView(mMore);
        SetupRemoteButtonView(mBottomSheetContent, mRowLayout, mMode, true);
        
		mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
	}
	
	private void ShowRemoteButtonAlertDialog(final View view, final String button) {
		AlertDialog.Builder mAlertBuilder = new AlertDialog.Builder(RemoteActivity.this);
		mAlertBuilder.setTitle("Edit Button");
		
		View mDialogLayout = LayoutInflater.from(RemoteActivity.this).inflate(R.layout.dialog_content_4, null);
		final RemoteButton mRemoteButton = mDialogLayout.findViewById(R.id.dialog_remote_button);
        final ViewPager mViewPager = mDialogLayout.findViewById(R.id.dialog_remote_viewpager);
		final ImageView mLeft = mDialogLayout.findViewById(R.id.dialog_button_left);
		final ImageView mRight = mDialogLayout.findViewById(R.id.dialog_button_right);
		final TextView mConfig1 = mDialogLayout.findViewById(R.id.dialog_text_1);
		final TextView mConfig2 = mDialogLayout.findViewById(R.id.dialog_text_2);
		final TextInputLayout mEditLayout1= mDialogLayout.findViewById(R.id.dialog_edittext_layout_1);
        final TextInputLayout mEditLayout2= mDialogLayout.findViewById(R.id.dialog_edittext_layout_2);
        final TextInputEditText mEditText1 = mDialogLayout.findViewById(R.id.dialog_button_edittext_1);
		final TextInputEditText mEditText2 = mDialogLayout.findViewById(R.id.dialog_button_edittext_2);
        final FrameLayout mFrameCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox_layout);
		final TextView mTextCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox_text);
		final CheckBox mCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox);
		
        final String id = view.getTag(R.id.button_id).toString();
        final String config = view.getTag(R.id.button_config).toString();
        final String style = view.getTag(R.id.button_style).toString();
        final String row = view.getTag(R.id.button_row).toString();
        final String height = view.getTag(R.id.button_height).toString();
        final String key = row+"@"+id;
        
        mRemoteButton.getLayoutParams().width = view.getMeasuredWidth();
        //mRemoteButton.getLayoutParams().height = view.getMeasuredHeight();
        
        mViewPager.setVisibility(View.GONE);
        mEditLayout1.setHint("Button");
        mEditLayout2.setHint("Style");
        
        mDialogConfigsSelected = Integer.parseInt(config);
		mDialogConfigsCount = 0;
        for(LinkedHashMap.Entry entry: mRemoteCodes.entrySet()) {
            if(entry.getKey().toString().contains(button.toLowerCase())) {
                mDialogConfigsCount++;
            }
        }
        
        if(mIsRowEditorVisible) {
            if(mRemotePartialButtonViews.containsKey(key)) {
                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(key);
                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                mRemoteButton.setRemoteButton1(mOrigRemoteButton.getRemoteButton1(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_1));
                
                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config));
                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mOrigRemoteButton.getRemoteButton1());
                
                mRemoteButton.UpdateRemote();  
            } else {
                for(LinkedHashMap.Entry entry: mRemotePartialButtonViews.entrySet()) {
                    if(view instanceof FrameLayout) {
                        if(entry.getKey().toString().contains(",")) {
                            String[] split = entry.getKey().toString().split("@");
                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                String newkey = entry.getKey().toString();

                                String[] ids = split[1].split(",");
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                if(id.equalsIgnoreCase(ids[0])) {
                                    mRemoteButton.setRemoteButton1(mOrigRemoteButton.getRemoteButton1(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_1));
                                    mRemoteButton.UpdateRemote();
                                    mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.GONE);
                                    mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.GONE);
                                }
                                if(id.equalsIgnoreCase(ids[1])) {
                                    mRemoteButton.setRemoteButton2(mOrigRemoteButton.getRemoteButton2(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_2));
                                    mRemoteButton.UpdateRemote();
                                    mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.GONE);
                                    mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.GONE);
                                }
                                
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config));
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mOrigRemoteButton.getRemoteButton1());
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config));
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mOrigRemoteButton.getRemoteButton2());
                                break;
                            }
                        }
                    } else if(view instanceof TextView) {
                        if(entry.getKey().toString().contains(",")) {
                            String[] split = entry.getKey().toString().split("@");
                            String[] ids = split[1].split(",");
                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                String newkey = entry.getKey().toString();

                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                mRemoteButton.setRemoteMiddleText(mOrigRemoteButton.getRemoteMiddleText());
                                mRemoteButton.UpdateRemote();
                                mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.VISIBLE);
                                mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.GONE);
                                mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.GONE);
                                break;
                            }
                        }
                    }
                }
            }
        } else {
            /* Long Pressed */
            
            if(mRemoteAllButtonViews.containsKey(key)) {
                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(key);
                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                mRemoteButton.setRemoteButton1(mOrigRemoteButton.getRemoteButton1(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_1));
                
                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config));
                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mOrigRemoteButton.getRemoteButton1());
                
                mRemoteButton.UpdateRemote();
            } else {
                for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                    if(view instanceof FrameLayout) {
                        if(entry.getKey().toString().contains(",")) {
                            String[] split = entry.getKey().toString().split("@");
                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                String newkey = entry.getKey().toString();

                                String[] ids = split[1].split(",");
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                if(id.equalsIgnoreCase(ids[0])) {
                                    mRemoteButton.setRemoteButton1(mOrigRemoteButton.getRemoteButton1(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_1));
                                    mRemoteButton.UpdateRemote();
                                    mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.GONE);
                                    mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.GONE);
                                }
                                if(id.equalsIgnoreCase(ids[1])) {
                                    mRemoteButton.setRemoteButton2(mOrigRemoteButton.getRemoteButton2(), mOrigRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2), mOrigRemoteButton.getRemoteButtonHeight(RemoteButton.BUTTON_2));
                                    mRemoteButton.UpdateRemote();
                                    mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.GONE);
                                    mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.GONE);
                                }
                                
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config));
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mOrigRemoteButton.getRemoteButton1());
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mOrigRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config));
                                mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mOrigRemoteButton.getRemoteButton2());
                                break;
                            }
                        }
                    } else if(view instanceof TextView) {
                        if(entry.getKey().toString().contains(",")) {
                            String[] split = entry.getKey().toString().split("@");
                            String[] ids = split[1].split(",");
                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                String newkey = entry.getKey().toString();

                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                mRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                mRemoteButton.setRemoteMiddleText(mOrigRemoteButton.getRemoteMiddleText());
                                mRemoteButton.UpdateRemote();
                                mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(View.VISIBLE);
                                mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(View.GONE);
                                mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(View.GONE);
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        mRemoteButton.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
                @Override
                public void onClick(View view, String button) {
                    Object obj1 = view.getTag(R.id.button_config);
                    Object obj2 = view.getTag(R.id.button_name);

                    if(obj1 != null && obj2 != null) {
                        Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
                        
                        TransmitRemoteSignal(Integer.parseInt(obj1.toString()), obj2.toString());
                    }
                }
            });
        
        if(mDialogConfigsSelected == 1) {
            setEnabled(mLeft, false);
        }
        if(mDialogConfigsCount <= 1) {
            setEnabled(mRight, false);
        }

        mConfig1.setText(mDialogConfigsSelected+"/"+mDialogConfigsCount);
        mConfig2.setText("Select Remote Configurations");

        mLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    mDialogConfigsSelected--;
                    mConfig1.setText(mDialogConfigsSelected+"/"+mDialogConfigsCount);
                    mConfig2.setText("Select Remote Configurations");

                    if(mDialogConfigsSelected == 1) {
                        setEnabled(mLeft, false);
                        setEnabled(mRight, true);
                    } else {
                        setEnabled(mLeft, true);
                    }

                    if(mRemoteCodes.containsKey(mDialogConfigsSelected+"@"+mEditText1.getText().toString())) {
                        mEditText1.setText(mEditText1.getText().toString());
                    } else {
                        mEditText1.setText("empty");
                    }
                }
            });

        mRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    mDialogConfigsSelected++;
                    mConfig1.setText(mDialogConfigsSelected+"/"+mDialogConfigsCount);
                    mConfig2.setText("Select Remote Configurations");

                    if(mDialogConfigsSelected == mDialogConfigsCount) {
                        setEnabled(mRight, false);
                        setEnabled(mLeft, true);
                    } else {
                        setEnabled(mRight, true);
                    }

                    if(mRemoteCodes.containsKey(mDialogConfigsSelected+"@"+mEditText1.getText().toString())) {
                        mEditText1.setText(mEditText1.getText().toString());
                    } else {
                        mEditText1.setText("empty");
                    }
                }
            });
       
        String mStyle = "";
        switch(style) {
            case "1":
                mStyle = "Text Only";
                break;
            case "2":
                mStyle = "Image Only";
                break;
            case "3":
                mStyle = "Image/Text";
                mCheckBox.setChecked(true);
                mEditText2.setEnabled(false);
                mEditLayout2.setHint(mEditText2.getHint()+" (Disabled)");
                break;
        }
        
        if(view instanceof TextView) {
            setEnabled(mLeft, false);
            setEnabled(mRight, false);
            mEditText2.setEnabled(false);
            mEditLayout2.setHint(mEditText2.getHint()+" (Disabled)");
            mFrameCheckBox.setEnabled(false);
            mTextCheckBox.setTextColor(getResources().getColor(R.color.grey_500));
            mCheckBox.setEnabled(false);                                                                        
			mCheckBox.setButtonTintList(getColorStateList(R.color.grey_500)); 
        }

        mEditText1.requestFocus();
        mEditText1.setText(button.toLowerCase());
		mEditText1.setKeyListener(null);
        mEditText2.setText(mStyle);
		mEditText2.setKeyListener(null);
        
        mEditText1.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View p1, MotionEvent p2) {
                    if(p2.getAction() == MotionEvent.ACTION_UP) {
                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RemoteActivity.this);
                        alertBuilder.setTitle("Select Button");

                        if(view instanceof FrameLayout) {
                            final String[] buttonlist = new String[mRemoteCodes.size()];
                            int i=0;
                            for(LinkedHashMap.Entry entry: mRemoteCodes.entrySet()) {
                                String item = entry.getKey().toString().replace("@","-");
                                buttonlist[i]=item;
                                i++;
                            }
                            
                            alertBuilder.setItems(buttonlist, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        mEditText1.setText(buttonlist[p2].toLowerCase());
                                    }
                                });
                        } else if(view instanceof TextView) {
                            final String[] list = {"ch", "vol"};
                            
                            alertBuilder.setItems(list, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        mEditText1.setText(list[p2]);
                                    }
                                });
                        }

                        alertBuilder.create();
                        AlertDialog alertDialog = alertBuilder.create();
                        alertDialog.show();

                    }
                    return false;
                }
			});
            
        mEditText2.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View p1, MotionEvent p2) {
                    if(p2.getAction() == MotionEvent.ACTION_UP) {
                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RemoteActivity.this);
                        alertBuilder.setTitle("Select Style");

                        if(view instanceof FrameLayout) {
                            final String[] list = {"Text Only", "Image Only"};

                            alertBuilder.setItems(list, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface p1, int p2) {
                                        mEditText2.setText(list[p2]);
                                    }
                                });
                               
                            alertBuilder.create();
                            AlertDialog alertDialog = alertBuilder.create();
                            alertDialog.show();
                        } else if(view instanceof TextView) {
                            // To Do
                        }  
                    }
                    return false;
                }
			});
            
        mEditText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
                    if(view instanceof FrameLayout) {
                        if(mEditText1.getText().toString().contains("-")) {
                            String[] text = mEditText1.getText().toString().split("-");
                            mDialogConfigsSelected = Integer.parseInt(text[0]);
                            
                            mEditText1.setText(text[1].toLowerCase());
                        } else {
                            mDialogConfigsCount = 0;
                            for(LinkedHashMap.Entry entry: mRemoteCodes.entrySet()) {
                                if(entry.getKey().toString().contains(mEditText1.getText().toString().toLowerCase())) {
                                    mDialogConfigsCount++;
                                }
                            }
                        }
                        
                        mConfig1.setText(mDialogConfigsSelected+"/"+mDialogConfigsCount);
                        
                        int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                        int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                        int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();
                        
                        if(visibility1 == View.VISIBLE) {
                            mRemoteButton.setRemoteButton1(mEditText1.getText().toString());
                            mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mDialogConfigsSelected);
                        }
                        if(visibility2 == View.VISIBLE) {
                            mRemoteButton.setRemoteButton2(mEditText1.getText().toString());
                            mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mDialogConfigsSelected);
                        }
                        
                        mRemoteButton.UpdateRemote();
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                        mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(visibility3);
                    } else if(view instanceof TextView) {
                        int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                        int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                        int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                        mRemoteButton.setRemoteMiddleText(mEditText1.getText().toString());
                       
                        mRemoteButton.UpdateRemote();
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                        mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(visibility3);
                    }
                }
            });
            
        mEditText2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
                    if(view instanceof FrameLayout) {
                        int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                        int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                        int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();
                        
                        switch(mEditText2.getText().toString()) {
                            case "Text Only":
                                if(visibility1 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton1(mEditText1.getText().toString(), RemoteButton.STYLE_TEXT);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_TEXT);
                                }
                                if(visibility2 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton2(mEditText1.getText().toString(), RemoteButton.STYLE_TEXT);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, RemoteButton.STYLE_TEXT);
                                }
                                break;
                            case "Image Only":
                                if(visibility1 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton1(mEditText1.getText().toString(), RemoteButton.STYLE_IMAGE);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE);
                                }
                                if(visibility2 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton2(mEditText1.getText().toString(), RemoteButton.STYLE_IMAGE);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, RemoteButton.STYLE_IMAGE);
                                }
                                break;
                            case "Image/Text":
                                if(visibility1 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton1(mEditText1.getText().toString(), RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                }
                                if(visibility2 == View.VISIBLE) {
                                    mRemoteButton.setRemoteButton2(mEditText1.getText().toString(), RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                    mRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                }
                                break;
                        }
  
                        mRemoteButton.UpdateRemote();
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                        mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(visibility3);
                    } else if(view instanceof TextView) {
                        int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                        int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                        int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                        mRemoteButton.setRemoteMiddleText(mEditText1.getText().toString());

                        mRemoteButton.UpdateRemote();
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).setVisibility(visibility1);
                        mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).setVisibility(visibility2);
                        mRemoteButton.getRemoteButtonMiddleTextView().setVisibility(visibility3);
                    }
                }
            });
        
        mFrameCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    mCheckBox.setChecked(!mCheckBox.isChecked());
                    mEditText2.setEnabled(!mCheckBox.isChecked());
                    
                    if(mCheckBox.isChecked()) {
                        mEditText2.setText("Image/Text");
                        mEditLayout2.setHint(mEditText2.getHint()+" (Disabled)");
                    } else {
                        mEditText2.setText("Image Only");
                        mEditLayout2.setHint(mEditText2.getHint().toString().replace(" (Disabled)", ""));
                    }
                }
			});
        
		mAlertBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface p1, int p2) {
					try{
                        mHasChanges = true;
                        
					    if(mIsRowEditorVisible) {
                            if(mRemotePartialButtonViews.containsKey(key)) {
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(key);
                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                mOrigRemoteButton.setRemoteButton1(mRemoteButton.getRemoteButton1(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                mOrigRemoteButton.UpdateRemote();
                            } else {
                                for(LinkedHashMap.Entry entry: mRemotePartialButtonViews.entrySet()) {
                                    if(view instanceof FrameLayout) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                                String newkey = entry.getKey().toString();

                                                int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                                int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                                                int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                                if(visibility1 ==  View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton1(mRemoteButton.getRemoteButton1(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mRemoteButton.getRemoteButton1());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                if(visibility2 == View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton2(mRemoteButton.getRemoteButton2(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mRemoteButton.getRemoteButton2());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                break;
                                            }
                                        }
                                    } else if(view instanceof TextView) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            String[] ids = split[1].split(",");
                                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                                String newkey = entry.getKey().toString();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                                mOrigRemoteButton.setRemoteMiddleText(mRemoteButton.getRemoteMiddleText());
                                                mOrigRemoteButton.getRemoteButtonMiddleTextView().setTag(R.id.button_name, mRemoteButton.getRemoteMiddleText());
                                                mOrigRemoteButton.UpdateRemote();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            /* Long Pressed */
                            
                            if(mRemoteAllButtonViews.containsKey(key)) {
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(key);
                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                mOrigRemoteButton.setRemoteButton1(mRemoteButton.getRemoteButton1(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                mOrigRemoteButton.UpdateRemote();
                            } else {
                                for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                                    if(view instanceof FrameLayout) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                                String newkey = entry.getKey().toString();

                                                int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                                int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                                                int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                                if(visibility1 ==  View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton1(mRemoteButton.getRemoteButton1(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mRemoteButton.getRemoteButton1());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                if(visibility2 == View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton2(mRemoteButton.getRemoteButton2(), mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mRemoteButton.getRemoteButton2());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                break;
                                            }
                                        }
                                    } else if(view instanceof TextView) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            String[] ids = split[1].split(",");
                                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                                String newkey = entry.getKey().toString();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                                mOrigRemoteButton.setRemoteMiddleText(mRemoteButton.getRemoteMiddleText());
                                                mOrigRemoteButton.getRemoteButtonMiddleTextView().setTag(R.id.button_name, mRemoteButton.getRemoteMiddleText());
                                                mOrigRemoteButton.UpdateRemote();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
					} catch (Exception e) {
						Toast.makeText(RemoteActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
					}
				}
			});

		mAlertBuilder.setNegativeButton("Cancel", null);
		
		mAlertBuilder.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface p1, int p2) {
					try{
                        mHasChanges = true;
                        
						if(mIsRowEditorVisible) {
                            if(mRemotePartialButtonViews.containsKey(key)) {
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(key);
                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                mOrigRemoteButton.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                mOrigRemoteButton.UpdateRemote();
                            } else {
                                for(LinkedHashMap.Entry entry: mRemotePartialButtonViews.entrySet()) {
                                    if(view instanceof FrameLayout) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                                String newkey = entry.getKey().toString();

                                                int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                                int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                                                int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                                if(visibility1 ==  View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mRemoteButton.getRemoteButton1());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                if(visibility2 == View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton2("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mRemoteButton.getRemoteButton2());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                break;
                                            }
                                        }
                                    } else if(view instanceof TextView) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            String[] ids = split[1].split(",");
                                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                                String newkey = entry.getKey().toString();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemotePartialButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                                mOrigRemoteButton.setRemoteMiddleText("ADD");
                                                mOrigRemoteButton.getRemoteButtonMiddleTextView().setTag(R.id.button_name, "ADD");
                                                mOrigRemoteButton.UpdateRemote();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            /* Long Pressed */  
                            
                            if(mRemoteAllButtonViews.containsKey(key)) {
                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(key);
                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                mOrigRemoteButton.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                mOrigRemoteButton.UpdateRemote();
                            } else {
                                for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                                    if(view instanceof FrameLayout) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            if(split[0].equalsIgnoreCase(row) && split[1].contains(id)) {
                                                String newkey = entry.getKey().toString();

                                                int visibility1 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_1).getVisibility();
                                                int visibility2 = mRemoteButton.getRemoteButtonView(RemoteButton.BUTTON_2).getVisibility();
                                                int visibility3 = mRemoteButton.getRemoteButtonMiddleTextView().getVisibility();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mOrigRemoteButton.getRemoteButtonType());
                                                if(visibility1 ==  View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton1("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_1));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mRemoteButton.getRemoteButton1());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                                if(visibility2 == View.VISIBLE) {
                                                    mOrigRemoteButton.setRemoteButton2("EMPTY", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mDialogConfigsSelected);
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, mRemoteButton.getRemoteButtonStyle(RemoteButton.BUTTON_2));
                                                    mOrigRemoteButton.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mRemoteButton.getRemoteButton2());
                                                    mOrigRemoteButton.UpdateRemote();
                                                }
                                            }
                                        }
                                    } else if(view instanceof TextView) {
                                        if(entry.getKey().toString().contains(",")) {
                                            String[] split = entry.getKey().toString().split("@");
                                            String[] ids = split[1].split(",");
                                            if(row.equalsIgnoreCase(split[0]) && id.equalsIgnoreCase(ids[0]+ids[1]+"_text")) {
                                                String newkey = entry.getKey().toString();

                                                RemoteButton mOrigRemoteButton = (RemoteButton) mRemoteAllButtonViews.get(newkey);
                                                mOrigRemoteButton.setRemoteButtonType(mRemoteButton.getRemoteButtonType());
                                                mOrigRemoteButton.setRemoteMiddleText("ADD");
                                                mOrigRemoteButton.getRemoteButtonMiddleTextView().setTag(R.id.button_name, "ADD");
                                                mOrigRemoteButton.UpdateRemote();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
					} catch (Exception e) {
						Toast.makeText(RemoteActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
					}
				}
			});

		mAlertBuilder.setView(mDialogLayout);
		final AlertDialog mAlert1 = mAlertBuilder.create();
		mAlert1.show();
	}
    
    private void ShowRemoteRowAlertDialog(final View view, final String button) {
        mIsRowEditorVisible = true;
        
        AlertDialog.Builder mAlertBuilder = new AlertDialog.Builder(RemoteActivity.this);
        
        if(view == null && button == null) {
            mAlertBuilder.setTitle("Add Row");
        } else {
            mAlertBuilder.setTitle("Edit Row");
        }

        View mDialogLayout = LayoutInflater.from(RemoteActivity.this).inflate(R.layout.dialog_content_4, null);
        final LinearLayout mLayoutContent = mDialogLayout.findViewById(R.id.dialog_content_layout);
        final RemoteButton mRemoteButton = mDialogLayout.findViewById(R.id.dialog_remote_button);
        final ViewPager mViewPager = mDialogLayout.findViewById(R.id.dialog_remote_viewpager);
        final FrameLayout mFrameContent = mDialogLayout.findViewById(R.id.dialog_frame_1);
        final ImageView mLeft = mDialogLayout.findViewById(R.id.dialog_button_left);
        final ImageView mRight = mDialogLayout.findViewById(R.id.dialog_button_right);
        final TextView mText1 = mDialogLayout.findViewById(R.id.dialog_text_1);
        final TextView mText2 = mDialogLayout.findViewById(R.id.dialog_text_2);
        final TextInputLayout mEditLayout1= mDialogLayout.findViewById(R.id.dialog_edittext_layout_1);
        final TextInputLayout mEditLayout2= mDialogLayout.findViewById(R.id.dialog_edittext_layout_2);
        final TextInputEditText mEditText1 = mDialogLayout.findViewById(R.id.dialog_button_edittext_1);
        final TextInputEditText mEditText2 = mDialogLayout.findViewById(R.id.dialog_button_edittext_2);
        final FrameLayout mFrameCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox_layout);
        final TextView mTextCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox_text);
        final CheckBox mCheckBox = mDialogLayout.findViewById(R.id.dialog_checkbox);
		
        mRemoteButton.setVisibility(View.GONE);
        mFrameCheckBox.setVisibility(View.GONE);
        mEditLayout1.setHint("Height");
        mEditLayout2.setHint("Margins");
        
        mEditText1.requestFocus();
        mEditText1.setKeyListener(null);
		mEditText2.setKeyListener(null);
        
        final String[] mTexts = {"3 Single Button Style", "4 Single Button Style", "3 × 3 Single Button Style", "3 Double Button Style", "4 Double Button Style"};
        final ArrayList mList = new ArrayList();
        mList.add(R.id.dialog_remote_row_1);
        mList.add(R.id.dialog_remote_row_2);
        mList.add(R.id.dialog_remote_row_3);
        mList.add(R.id.dialog_remote_row_4);
        mList.add(R.id.dialog_remote_row_5);
        
        mDialogConfigsSelected = 0;
		mDialogConfigsCount = mList.size();
        
        RowRemotePagerAdapter mRowAdapter = new RowRemotePagerAdapter(RemoteActivity.this, mList);
        mViewPager.setAdapter(mRowAdapter);
        mViewPager.setOffscreenPageLimit(mList.size()-1);
        
        mText1.setText((mDialogConfigsSelected+1)+"/"+mDialogConfigsCount);
        mText2.setText(mTexts[mDialogConfigsSelected]);
        
        if(mDialogConfigsSelected == 0) {
            setEnabled(mLeft, false);
        }
        if(mDialogConfigsCount == mDialogConfigsCount-1) {
            setEnabled(mRight, false);
        }
        
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int p1, float p2, int p3) {}

                @Override
                public void onPageSelected(int p1) {
                    mDialogConfigsSelected = p1;
                    mText1.setText((mDialogConfigsSelected+1)+"/"+mDialogConfigsCount);
                    mText2.setText(mTexts[p1]);
                    
                    if(mDialogConfigsSelected == 0) {
                        setEnabled(mLeft, false);
                        setEnabled(mRight, true);
                    } else if(mDialogConfigsSelected == mDialogConfigsCount-1) {
                        setEnabled(mRight, false);
                        setEnabled(mLeft, true);
                    } else {
                        setEnabled(mLeft, true);
                        setEnabled(mRight, true);
                    }
                }

                @Override
                public void onPageScrollStateChanged(int p1) {}
            });
            
        mLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    mViewPager.setCurrentItem(mDialogConfigsSelected-1, false);
                }
            });

        mRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    mViewPager.setCurrentItem(mDialogConfigsSelected+1, false);
                }
            });
            
        if(view != null && button != null) {
            mViewPager.setVisibility(View.GONE);
            mFrameContent.setVisibility(View.GONE);
            
            ((MarginLayoutParams) mEditLayout1.getLayoutParams()).topMargin = (int)ViewUtils.dpToPx(this, 15);
            
            String row = view.getTag(R.id.button_row).toString();
            String height = "";
            String style = "";
            String margin = "";
            for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                if(entry.getKey().toString().split("@")[0].equalsIgnoreCase(row)) {
                    height = ((RemoteButton)entry.getValue()).getTag(R.id.remote_height).toString();
                    style = ((RemoteButton)entry.getValue()).getTag(R.id.remote_style).toString();
                    margin = ((RemoteButton)entry.getValue()).getTag(R.id.remote_margin).toString();
                    break;
                }
            }
            
            LinkedHashMap mViewLayout = new LinkedHashMap();
            for(LinkedHashMap.Entry entry: GetRemoteButtonLayoutFromAllButtonViews().entrySet()) {
                LinkedHashMap rowInfo = (LinkedHashMap) entry.getKey();
                
                if(row.equalsIgnoreCase(rowInfo.getOrDefault("id", "none").toString())) {
                    mViewLayout.put(entry.getKey(), entry.getValue());
                }
            }
            
            if(margin.contains("*")) {
                margin = RemoteButton.DEFAULT_BUTTON_MARGIN;
            }
            
            mRemotePartialButtonViews = new LinkedHashMap();
            SetupRemoteButtonView(mLayoutContent, mViewLayout, mMode, false);
            
            mEditText1.setText(height);
            mEditText2.setText(margin);
        } else {
            mEditText1.setText(""+RemoteButton.DEFAULT_BUTTON_HEIGHT);
            mEditText2.setText(RemoteButton.DEFAULT_BUTTON_MARGIN);
        }
        
        mEditText1.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View p1, MotionEvent p2) {
                    if(p2.getAction() == MotionEvent.ACTION_UP) {
                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RemoteActivity.this);
                        alertBuilder.setTitle("Row Height");

                        View dialogLayout = LayoutInflater.from(RemoteActivity.this).inflate(R.layout.dialog_content_5, null);
                        final SeekBarWithEditText mSeekBarEditText = dialogLayout.findViewById(R.id.dialog_seekbar_edittext);
                        mSeekBarEditText.setValue(Integer.parseInt(mEditText1.getText().toString()));

                        alertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface p1, int p2) {
                                    mEditText1.setText(""+mSeekBarEditText.getValue());
                                } 
                            });

                        alertBuilder.setNegativeButton("Cancel", null);

                        alertBuilder.setView(dialogLayout);
                        alertBuilder.create().show();
                    }
                    return false;
                }
			});
            
        mEditText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
                    if(mRemotePartialButtonViews != null) {
                        String row = view.getTag(R.id.button_row).toString();
                        for(LinkedHashMap.Entry entry: mRemotePartialButtonViews.entrySet()) {
                            if(entry.getKey().toString().split("@")[0].equalsIgnoreCase(row)) {
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_margin, mEditText2.getText().toString());

                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mEditText1.getText().toString());
                                
                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight1(Integer.parseInt(mEditText1.getText().toString()));
                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight2(Integer.parseInt(mEditText1.getText().toString()));
                                
                                ((RemoteButton)entry.getValue()).UpdateRemote();
                                
                                mLayoutContent.requestLayout();
                            }
                        }
                    }
                }
            });
            
        mEditText2.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View p1, MotionEvent p2) {
                    if(p2.getAction() == MotionEvent.ACTION_UP) {
                        
                        final String[] marginsValue = mEditText2.getText().toString().split(",");
                        final String[] margins = {"Left Margin - "+marginsValue[0], "Top Margin - "+marginsValue[1], "Right Margin - "+marginsValue[2], "Bottom Margin - "+marginsValue[3]};
                        
                        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RemoteActivity.this);
                        alertBuilder.setTitle("Select Margin");
                        alertBuilder.setItems(margins, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface p1, final int pos) {
                                    p1.dismiss();
                                    
                                    AlertDialog.Builder alertBuilder = new AlertDialog.Builder(RemoteActivity.this);
                                    alertBuilder.setTitle(margins[pos].split("-")[0]);

                                    View dialogLayout = LayoutInflater.from(RemoteActivity.this).inflate(R.layout.dialog_content_5, null);
                                    final SeekBarWithEditText mSeekBarEditText = dialogLayout.findViewById(R.id.dialog_seekbar_edittext);
                                    mSeekBarEditText.setValue(Integer.parseInt(marginsValue[pos]));

                                    alertBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface p1, int p2) {
                                                String result = ""+mSeekBarEditText.getValue();
                                                String margin = "";
                                                for(int i=0; i<margins.length; i++) {
                                                    if(i==pos) {
                                                        margin = margin + result+",";
                                                    } else {
                                                        margin = margin + marginsValue[i]+",";
                                                    }
                                                }
                                                mEditText2.setText(margin.substring(0,margin.length()-1));
                                            } 
                                        });

                                    alertBuilder.setNegativeButton("Cancel", null);

                                    alertBuilder.setView(dialogLayout);
                                    alertBuilder.create().show();
                                }
                            });
                            
                        alertBuilder.create().show();
                    }
                    return false;
                }
			});
            
        mEditText2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
                    if(mRemotePartialButtonViews != null) {
                        String row = view.getTag(R.id.button_row).toString();
                        for(LinkedHashMap.Entry entry: mRemotePartialButtonViews.entrySet()) {
                            if(entry.getKey().toString().split("@")[0].equalsIgnoreCase(row)) {
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_margin, mEditText2.getText().toString());

                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mEditText1.getText().toString());

                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight1(Integer.parseInt(mEditText1.getText().toString()));
                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight2(Integer.parseInt(mEditText1.getText().toString()));

                                ((RemoteButton)entry.getValue()).UpdateRemote();

                                mLayoutContent.requestLayout();
                            }
                            
                            MarginLayoutParams mMargin = (MarginLayoutParams) mLayoutContent.getLayoutParams();
                            
                            int marginLeft = 0;
                            int marginTop = 0;
                            int marginRight = 0;
                            int marginBottom = 0;

                            if(mEditText2.getText().toString().contains(",")) {
                                String[] margins = mEditText2.getText().toString().split(",");
                                if(margins.length == 4) {
                                    marginLeft = margins[0]!=null && margins[0].matches("[0-9]+") ? Integer.parseInt(margins[0]) : 0;
                                    marginTop = margins[1]!=null && margins[1].matches("[0-9]+") ? Integer.parseInt(margins[1]) : 0;
                                    marginRight = margins[2]!=null && margins[2].matches("[0-9]+") ? Integer.parseInt(margins[2]) : 0;
                                    marginBottom = margins[3]!=null && margins[3].matches("[0-9]+") ? Integer.parseInt(margins[3]) : 0;
                                }
                            }

                            mMargin.leftMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginLeft);
                            mMargin.topMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginTop);
                            mMargin.rightMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginRight);
                            mMargin.bottomMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginBottom);
                            
                            mLayoutContent.requestLayout();
                        }
                    }
                }
            });
            
        mAlertBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {
                    mHasChanges = true;
                    
                    if(view != null && button != null) {
                        String row = view.getTag(R.id.button_row).toString();
                        String id = view.getTag(R.id.button_id).toString();
                        String key = row+"@"+id;
                        
                        for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                            if(entry.getKey().toString().split("@")[0].equalsIgnoreCase(row)) {
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setTag(R.id.remote_margin, mEditText2.getText().toString());
                                
                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_height, mEditText1.getText().toString());
                                ((RemoteButton)entry.getValue()).setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_height, mEditText1.getText().toString());
                                
                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight1(Integer.parseInt(mEditText1.getText().toString()));
                                ((RemoteButton)entry.getValue()).setRemoteButtonHeight2(Integer.parseInt(mEditText1.getText().toString()));
                                
                                ((RemoteButton)entry.getValue()).UpdateRemote();
                            }
                        }
                        
                        for(int i=0; i<mMainLayout.getChildCount(); i++) {
                            Object obj1 = mMainLayout.getChildAt(i).getTag(R.id.row_id);
                            Object obj2 = mMainLayout.getChildAt(i).getTag(R.id.row_id);
                            
                            if(obj1 != null && obj2 != null) {
                                if(row.equalsIgnoreCase(obj1.toString())) {
                                    mMainLayout.getChildAt(i).setTag(R.id.row_margin, mEditText2.getText().toString());
                                    
                                    MarginLayoutParams mMargin = (MarginLayoutParams) mMainLayout.getChildAt(i).getLayoutParams();

                                    int marginLeft = 0;
                                    int marginTop = 0;
                                    int marginRight = 0;
                                    int marginBottom = 0;

                                    if(mEditText2.getText().toString().contains(",")) {
                                        String[] margins = mEditText2.getText().toString().split(",");
                                        if(margins.length == 4) {
                                            marginLeft = margins[0]!=null && margins[0].matches("[0-9]+") ? Integer.parseInt(margins[0]) : 0;
                                            marginTop = margins[1]!=null && margins[1].matches("[0-9]+") ? Integer.parseInt(margins[1]) : 0;
                                            marginRight = margins[2]!=null && margins[2].matches("[0-9]+") ? Integer.parseInt(margins[2]) : 0;
                                            marginBottom = margins[3]!=null && margins[3].matches("[0-9]+") ? Integer.parseInt(margins[3]) : 0;
                                        }
                                    }

                                    mMargin.leftMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginLeft);
                                    mMargin.topMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginTop);
                                    mMargin.rightMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginRight);
                                    mMargin.bottomMargin = (int) ViewUtils.dpToPx(RemoteActivity.this, marginBottom);
                                }
                            }
                        }
                        
                        if(mRemotePartialButtonViews != null) {
                            for(LinkedHashMap.Entry entry1: mRemotePartialButtonViews.entrySet()) {
                                for(LinkedHashMap.Entry entry2: mRemoteAllButtonViews.entrySet()) {
                                    if(entry1.getKey().toString().equalsIgnoreCase(entry2.getKey().toString())) {
                                        RemoteButton mRemoteButtonA = (RemoteButton) entry1.getValue();
                                        RemoteButton mRemoteButtonB = (RemoteButton) entry2.getValue();
                                        
                                        mRemoteButtonB.setRemoteButton1(mRemoteButtonA.getRemoteButton1(), mRemoteButtonA.getRemoteButtonStyle(RemoteButton.BUTTON_1), mRemoteButtonA.getRemoteButtonHeight(RemoteButton.BUTTON_1));
                                        mRemoteButtonB.setRemoteButton2(mRemoteButtonA.getRemoteButton2(), mRemoteButtonA.getRemoteButtonStyle(RemoteButton.BUTTON_2), mRemoteButtonA.getRemoteButtonHeight(RemoteButton.BUTTON_2));
                                        mRemoteButtonB.setRemoteMiddleText(mRemoteButtonA.getRemoteMiddleText());
                                        
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_config, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_config));
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_style, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_style));
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_1, R.id.button_name, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_1).getTag(R.id.button_name));
                                        
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_config, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_config));
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_style, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_style));
                                        mRemoteButtonB.setRemoteButtonTag(RemoteButton.BUTTON_2, R.id.button_name, mRemoteButtonA.getRemoteButtonView(RemoteButton.BUTTON_2).getTag(R.id.button_name));
                                        
                                        mRemoteButtonB.getRemoteButtonMiddleTextView().setTag(R.id.button_name, mRemoteButtonA.getRemoteMiddleText());
                                        mRemoteButtonB.UpdateRemote();
                                    }
                                }
                            }
                        }
                    } else {
                        LinkedHashMap mRowLayout = new LinkedHashMap();

                        LinkedHashMap mRowInfo = new LinkedHashMap();
                        mRowInfo.put("id", (getRemoteLastIndex()+1));
                        mRowInfo.put("style", (mDialogConfigsSelected+1));
                        mRowInfo.put("height", mEditText1.getText().toString());
                        mRowInfo.put("margin", mEditText2.getText().toString());
                        
                        String[] buttonIDs = new String[]{};
                        switch(mDialogConfigsSelected) {
                            case 0:
                                buttonIDs = new String[]{"a", "b", "c"};
                                break;
                            case 1:
                                buttonIDs = new String[]{"a", "b", "c", "d"};
                                break;
                            case 2:
                                buttonIDs = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i"};
                                break;
                            case 3:
                                buttonIDs = new String[]{"a,b", "c,d", "e,f"};
                                break;
                            case 4:
                                buttonIDs = new String[]{"a,b", "c,d", "e,f", "g,h"};
                                break;  
                        }
                            
                        LinkedHashMap mButton = new LinkedHashMap();
                        for(int j=0; j<buttonIDs.length; j++) {
                            if(mDialogConfigsSelected == 3 || mDialogConfigsSelected == 4) {
                                LinkedHashMap mButtonInfo = new LinkedHashMap();
                                mButtonInfo.put("id", buttonIDs[j].split(",")[0]);
                                mButtonInfo.put("config", "1");
                                mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                mButtonInfo.put("name", "EMPTY");
                                mButton.put(buttonIDs[j].split(",")[0], mButtonInfo);
                                
                                mButtonInfo = new LinkedHashMap();
                                mButtonInfo.put("id", buttonIDs[j].split(",")[1]);
                                mButtonInfo.put("config", "1");
                                mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                mButtonInfo.put("name", "EMPTY");
                                mButton.put(buttonIDs[j].split(",")[1], mButtonInfo);
                                
                                mButtonInfo = new LinkedHashMap();
                                mButtonInfo.put("id", (buttonIDs[j].replace("," ,"")+"_text"));
                                mButtonInfo.put("config", "1");
                                mButtonInfo.put("style", RemoteButton.STYLE_TEXT);
                                mButtonInfo.put("name", "ADD");
                                mButton.put((buttonIDs[j].replace("," ,"")+"_text"), mButtonInfo);
                            } else {
                                LinkedHashMap mButtonInfo = new LinkedHashMap();
                                mButtonInfo.put("id", buttonIDs[j]);
                                mButtonInfo.put("config", "1");
                                mButtonInfo.put("style", RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
                                mButtonInfo.put("name", "EMPTY");
                                mButton.put(buttonIDs[j], mButtonInfo);
                            } 
                        }
                        
                        mRowLayout.put(mRowInfo, mButton);
                        
                        //View mView = SetupRemoteButtonView(mRowLayout, mMode);
                        //mMainLayout.addView(mView);
                        SetupRemoteButtonView(mMainLayout, mRowLayout, mMode, true);
                    }
                    
                    mMainLayout.requestLayout();
                }
            });
            
        mAlertBuilder.setNegativeButton("Cancel", null);  
        
        if(view != null && button != null) {
            mAlertBuilder.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        mHasChanges = true;
                        
                        String row = view.getTag(R.id.button_row).toString();
                        LinkedHashMap mNewRemoteAllButtonViews = new LinkedHashMap(mRemoteAllButtonViews);
                        for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
                            if(row.equalsIgnoreCase(entry.getKey().toString().split("@")[0])) {
                                mNewRemoteAllButtonViews.remove(entry.getKey());
                            }
                        }
                        
                        mRemoteAllButtonViews = new LinkedHashMap(mNewRemoteAllButtonViews);
                        
                        for(int i=0; i<mMainLayout.getChildCount(); i++) {
                            Object obj = mMainLayout.getChildAt(i).getTag(R.id.row_id);
                            
                            if(obj != null) {
                                if(row.equalsIgnoreCase(obj.toString())) {
                                    mMainLayout.removeViewAt(i);
                                }
                            }
                        }
                    }
                });
        }
        
        mAlertBuilder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface p1) {
                    mIsRowEditorVisible = false;
                }
            });
        
        mAlertBuilder.setView(mDialogLayout);
        final AlertDialog mAlert1 = mAlertBuilder.create();
		mAlert1.show();
    }
	
	private void TextChangeListener(final TextInputEditText editText1, final TextInputEditText editText2, final MaterialButton button) {
		editText1.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
					button.setEnabled((!editText1.getText().toString().isEmpty()) && (!editText2.getText().toString().isEmpty()));
				}

				@Override
				public void afterTextChanged(Editable p1) {
				}
			});
			
		editText2.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {
				}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
					button.setEnabled((!editText1.getText().toString().isEmpty()) && (!editText2.getText().toString().isEmpty()));
				}

				@Override
				public void afterTextChanged(Editable p1) {
				}
			});
	}
    
    private void TransmitRemoteSignal(int config, String button) {
		try {
			if(mRemoteCodes.containsKey(config+"@"+button)) {
				String IR_CODE = mRemoteCodes.get(config+"@"+button).toString();

				mIRManager = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
				if (mIRManager.hasIrEmitter()) {                                                
					int frequency = Constant.DEFAULT_IR_FREQUENCY;
					int[] pattern = parsePattern(IR_CODE);

					if(!IR_CODE.isEmpty() && pattern != null) {
						mIRManager.transmit(frequency, pattern);
					}
				}
			} else {
				Toast.makeText(RemoteActivity.this, "Remote \""+ button +"\" Key IR Code Not Found.", Toast.LENGTH_SHORT).show();
			}
		} catch(Exception e) {
			Toast.makeText(RemoteActivity.this, "Error Transmitting IR Signal. ("+ e.getMessage() +")", Toast.LENGTH_SHORT).show();
		}
	}
   
	private void UpdateRemoteFromPreference(String key, String value) {
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(RemoteActivity.this);
		SharedPreferences.Editor editor = mPrefs.edit();

		mRemoteInfo.put(key, value);
		String mRemoteID = mRemoteInfo.get("save_id").toString();

		int index = 0;
		ArrayList mRemoteSavedList = GetAllRemoteFromPreference();
		for(int i=0; i<mRemoteSavedList.size(); i++) {
			if(((LinkedHashMap)mRemoteSavedList.get(i)).getOrDefault("save_id", "").equals(mRemoteID)) {
				index = i;
				break;
			}
		}

		mRemoteSavedList.set(index, mRemoteInfo);

		Set<String> mNewSets = new HashSet<String>();

		for(LinkedHashMap item: mRemoteSavedList) {
			JSONObject jsonObj = new JSONObject(item);
			mNewSets.add(jsonObj.toString());
		}

		editor.putStringSet(Constant.PREF_REMOTE_LIST, mNewSets);
		editor.putBoolean(Constant.PREF_REMOTE_HAS_CHANGES, true);
		editor.apply();
	}
 
    private void ZShowAlertDialogRemoteButtonInfo(View view) {
        Object mObj1 = view.getTag(R.id.button_id);
        Object mObj2 = view.getTag(R.id.button_name);
        Object mObj3 = view.getTag(R.id.button_config);
        Object mObj4 = view.getTag(R.id.button_style);
        Object mObj5 = view.getTag(R.id.button_row);
        
        String mStr1 = "null";
        String mStr2 = "null";
        String mStr3 = "null";
        String mStr4 = "null";
        String mStr5 = "null";
        
        if(mObj1 != null) {
           mStr1 = mObj1.toString(); 
        } 
        
        if(mObj2 != null) {
            mStr2 = mObj2.toString(); 
        }
        
        if(mObj3 != null) {
            mStr3 = mObj3.toString(); 
        }
        
        if(mObj4 != null) {
            mStr4 = mObj4.toString(); 
        }
        
        if(mObj5 != null) {
            mStr5 = mObj5.toString(); 
        }
        
        AlertDialog.Builder mAlertBuilder = new AlertDialog.Builder(this);
        mAlertBuilder.setTitle(mStr2);
        mAlertBuilder.setMessage("ID:\t\t"+mStr1+"\nNAME:\t\t"+mStr2+"\nCONFIG:\t\t"+mStr3+"\nSTYLE:\t\t"+mStr4+"\nROW:\t\t"+mStr5);
        mAlertBuilder.setPositiveButton("OK", null);
        mAlertBuilder.create().show();
    }
	
	private boolean checkPermission() {
		int result = ContextCompat.checkSelfPermission(RemoteActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
		if (result == PackageManager.PERMISSION_GRANTED) {
			return true;
		} else {
			return false;
		}
	}
	
	private String getDateTime() { 
		DateFormat mDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date mDate = new Date(); 
		return mDateFormat.format(mDate); 
	}
    
    private int getRemoteLastIndex() {
      
        String index = "0";
        for(LinkedHashMap.Entry entry: mRemoteAllButtonViews.entrySet()) {
            index = entry.getKey().toString().split("@")[0];
        }
        
        return Integer.parseInt(index);
    }
	
	private boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    private boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }
	
	private int[] parsePattern(String key) {
        if(!key.isEmpty()) {

            if(key.contains(",")) {
                String[] splitPattern = key.split(",");
                int[] pattern = new int[splitPattern.length];

                for(int i=0; i<splitPattern.length; i++) {
                    pattern[i] = Integer.parseInt(splitPattern[i]);
                }

                return pattern;
            } else {
                return null;
            }
        }

        return null;
    }
	
	private void requestPermission() {
		if (ActivityCompat.shouldShowRequestPermissionRationale(RemoteActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
			AlertDialog.Builder alertBuild = new AlertDialog.Builder(RemoteActivity.this);
			alertBuild.setTitle("Storage Permission");
			alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Save Your Remote Configurations And Custom Layouts.");
			alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2) {
						final Intent intent = new Intent();
						intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
						intent.addCategory(Intent.CATEGORY_DEFAULT);
						intent.setData(Uri.parse("package:" + getPackageName()));
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
						intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
						startActivity(intent);
					}
				});
			alertBuild.setNegativeButton("Cancel", null);

			AlertDialog alert = alertBuild.create();
			alert.show();
		} else {
			ActivityCompat.requestPermissions(RemoteActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
		}
	}
	
	private void setEnabled(ImageView button, boolean state) {
		if(state) {
			button.setEnabled(state);
			button.clearColorFilter();
		} else {
			button.setEnabled(state);
			button.setColorFilter(ContextCompat.getColor(this, R.color.grey_500));
		}
	}
}
