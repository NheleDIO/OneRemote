package com.nheledio.app.oneremote.UI;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.ViewUtils;

public class RemoteButton extends FrameLayout {

    private Context mContext;
    
    private LinearLayout mParentLayout;
    
    private FrameLayout mFrame1;
    private TextView mTextView1;
    private ImageView mImageView1;
    private TextView mTextViewMiddle;
    private FrameLayout mFrame2;
    private TextView mTextView2;
    private ImageView mImageView2;
    
    public static final int STYLE_TEXT = 1;
    public static final int STYLE_IMAGE = 2;
    public static final int STYLE_IMAGE_IF_AVAILABLE = 3;
    public static final int TYPE_SINGLE = 1;
    public static final int TYPE_DUAL = 2;
    public static final int BUTTON_1 = 1;
    public static final int BUTTON_2 = 2;
    public static final int DEFAULT_BUTTON_HEIGHT = 55;
    public static final int DEFAULT_TEXT_MIDDLE_HEIGHT = 30;
    public static final String DEFAULT_BUTTON_MARGIN = "0,0,0,0";
    
    private String BUTTON_NAME_1;
    private String BUTTON_NAME_2;
    private String TEXT_MIDDLE;
    private int BUTTON_HEIGHT_1;
    private int BUTTON_HEIGHT_2;
    private int TEXT_MIDDLE_HEIGHT;
    
    private int remoteButtonStyle1 = STYLE_IMAGE;
    private int remoteButtonStyle2 = STYLE_IMAGE;
    private int remoteButtonType = TYPE_SINGLE;
    private boolean remoteShowAsEmpty = false;
    private boolean remoteTapSounds = false;
    
    private OnRemoteClickListener mClickListener;
    private OnRemoteLongClickListener mLongClickListener;
    
    public RemoteButton(Context context) {
        super(context);
        this.mContext = context;
        
        ObtainStyledAttributes(context, null, 0);
        Init();
    }
    
    public RemoteButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        
        ObtainStyledAttributes(context, attrs, 0);
        Init();
    }

    public RemoteButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mContext = context;
        
        ObtainStyledAttributes(context, attrs, defStyle);
        Init();
    }
    
    
    private void ObtainStyledAttributes(Context context, AttributeSet attrs, int defStyleAttr) {
        
        BUTTON_NAME_1 = "EMPTY";
        BUTTON_NAME_2 = "EMPTY";
        TEXT_MIDDLE = "ADD";
        
        BUTTON_HEIGHT_1 = DEFAULT_BUTTON_HEIGHT;
        BUTTON_HEIGHT_2 = DEFAULT_BUTTON_HEIGHT;
        TEXT_MIDDLE_HEIGHT = DEFAULT_TEXT_MIDDLE_HEIGHT;

        remoteButtonStyle1 = STYLE_IMAGE;
        remoteButtonStyle2 = STYLE_IMAGE;
        remoteButtonType = TYPE_SINGLE;
        remoteShowAsEmpty = false;
        
        if (attrs != null) {
            TypedArray mTypedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.RemoteButton, defStyleAttr, 0);
            BUTTON_NAME_1 = mTypedArray.getString(R.styleable.RemoteButton_remoteButton1);
            BUTTON_NAME_2 = mTypedArray.getString(R.styleable.RemoteButton_remoteButton2);
            TEXT_MIDDLE = mTypedArray.getString(R.styleable.RemoteButton_remoteMiddleText);

            if(BUTTON_NAME_1 == null) {
                BUTTON_NAME_1 = "EMPTY";
            }
            if(BUTTON_NAME_2 == null) {
                BUTTON_NAME_2 = "EMPTY";
            }
            if(TEXT_MIDDLE == null) {
                TEXT_MIDDLE = "ADD";
            }
            
            remoteButtonStyle1 = mTypedArray.getInt(R.styleable.RemoteButton_remoteButtonStyle1, STYLE_IMAGE);
            remoteButtonStyle2 = mTypedArray.getInt(R.styleable.RemoteButton_remoteButtonStyle2, STYLE_IMAGE);

            remoteButtonType = mTypedArray.getInt(R.styleable.RemoteButton_remoteButtonType, TYPE_SINGLE);

            BUTTON_HEIGHT_1 = (int) mTypedArray.getDimension(R.styleable.RemoteButton_remoteButtonHeight1, (float) DEFAULT_BUTTON_HEIGHT);
            BUTTON_HEIGHT_2 = (int) mTypedArray.getDimension(R.styleable.RemoteButton_remoteButtonHeight2, (float) DEFAULT_BUTTON_HEIGHT);
            TEXT_MIDDLE_HEIGHT = (int) mTypedArray.getDimension(R.styleable.RemoteButton_remoteMiddleTextHeight, (float) DEFAULT_TEXT_MIDDLE_HEIGHT);

            remoteShowAsEmpty = mTypedArray.getBoolean(R.styleable.RemoteButton_remoteShowAsEmpty, false);
            
            mTypedArray.recycle();
        } 
    }
    
    private void Init() {
        inflate(getContext(), R.layout.remote_button, this);
        
        mParentLayout = findViewById(R.id.remote_button_main);
        
        mFrame1 = findViewById(R.id.remote_button_frame_1);
        mTextView1 = findViewById(R.id.button_text_1);
        mImageView1 = findViewById(R.id.button_image_1);
        
        mTextViewMiddle = findViewById(R.id.button_text_middle);
        
        mFrame2 = findViewById(R.id.remote_button_frame_2);
        mTextView2 = findViewById(R.id.button_text_2);
        mImageView2 = findViewById(R.id.button_image_2);
        
        mFrame1.setSoundEffectsEnabled(remoteTapSounds);
        mTextView1.setSoundEffectsEnabled(remoteTapSounds);
        mImageView1.setSoundEffectsEnabled(remoteTapSounds);
        mTextViewMiddle.setSoundEffectsEnabled(remoteTapSounds);
        mFrame2.setSoundEffectsEnabled(remoteTapSounds);
        mTextView2.setSoundEffectsEnabled(remoteTapSounds);
        mImageView2.setSoundEffectsEnabled(remoteTapSounds);
        
        UpdateRemote();
        
        if(remoteShowAsEmpty) {
            EmptyRemote();
        }
    }
    
    public void EmptyRemote() {
        BUTTON_NAME_1 = "EMPTY";
        BUTTON_NAME_2 = "EMPTY";
        TEXT_MIDDLE = "ADD";

        BUTTON_HEIGHT_1 = DEFAULT_BUTTON_HEIGHT;
        BUTTON_HEIGHT_2 = DEFAULT_BUTTON_HEIGHT;
        TEXT_MIDDLE_HEIGHT = DEFAULT_TEXT_MIDDLE_HEIGHT;

        remoteButtonStyle1 = STYLE_IMAGE;
        remoteButtonStyle2 = STYLE_IMAGE;

        mFrame1.setVisibility(View.VISIBLE);
        mTextView1.setVisibility(View.INVISIBLE);
        mImageView1.setVisibility(View.VISIBLE);

        mFrame2.setVisibility(View.GONE);

        mFrame1.setBackgroundDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonBackgroundID(BUTTON_NAME_1)));
        mTextView1.setText(BUTTON_NAME_1.toUpperCase());
        mImageView1.setImageDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonResourceID(BUTTON_NAME_1)));

        if(remoteButtonType == TYPE_DUAL) {
            mFrame2.setVisibility(View.VISIBLE);
            mTextView2.setVisibility(View.INVISIBLE);
            mImageView2.setVisibility(View.VISIBLE);

            mTextViewMiddle.setText(TEXT_MIDDLE.toUpperCase());
            mTextViewMiddle.setVisibility(View.VISIBLE);

            mFrame2.setBackgroundDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonBackgroundID(BUTTON_NAME_2)));
            mTextView2.setText(BUTTON_NAME_2.toUpperCase());
            mImageView2.setImageDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonResourceID(BUTTON_NAME_2)));
        }
    }
    
    public void UpdateRemote() {
        mFrame1.setVisibility(View.VISIBLE);
        mTextView1.setVisibility(View.INVISIBLE);
        mImageView1.setVisibility(View.VISIBLE);

        mFrame2.setVisibility(View.GONE);

        if(TEXT_MIDDLE.equalsIgnoreCase("add") || TEXT_MIDDLE.equalsIgnoreCase("empty")) {
            mTextViewMiddle.setVisibility(View.GONE);
        } else {
            mTextViewMiddle.setText(TEXT_MIDDLE.toUpperCase());
            mTextViewMiddle.setVisibility(View.VISIBLE);
            mTextViewMiddle.getLayoutParams().height = (int) ViewUtils.dpToPx(getContext(), TEXT_MIDDLE_HEIGHT);
        }

        mFrame1.setBackgroundDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonBackgroundID(BUTTON_NAME_1)));
        mFrame1.getLayoutParams().height = (int) ViewUtils.dpToPx(getContext(), BUTTON_HEIGHT_1);
        mTextView1.setText(BUTTON_NAME_1.toUpperCase());
        mImageView1.setImageDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonResourceID(BUTTON_NAME_1)));

        if(remoteButtonStyle1 == STYLE_TEXT) {
            mTextView1.setVisibility(View.VISIBLE);
            mImageView1.setVisibility(View.INVISIBLE);
        } else if(remoteButtonStyle1 == STYLE_IMAGE_IF_AVAILABLE) {
            if(getRemoteButtonResourceID(BUTTON_NAME_1) != R.drawable.rem_default) {
                mTextView1.setVisibility(View.INVISIBLE);
                mImageView1.setVisibility(View.VISIBLE);
            } else {
                mTextView1.setVisibility(View.VISIBLE);
                mImageView1.setVisibility(View.INVISIBLE);
            }
        }
        
        mTextViewMiddle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if(mClickListener != null) {
                        mClickListener.onClick(p1, TEXT_MIDDLE);
                    }
                }
            });
        
        mFrame1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if(mClickListener != null) {
                        mClickListener.onClick(p1, BUTTON_NAME_1);
                    }
                }
            });

        mFrame1.setOnLongClickListener(new View.OnLongClickListener() {

                @Override
                public boolean onLongClick(View p1) {
                    if(mLongClickListener != null) {
                        mLongClickListener.onLongClick(p1, BUTTON_NAME_1);
                    }

                    return false;
                }
        });
        
        mFrame1.setTag(R.id.button_name, BUTTON_NAME_1);
        mFrame1.setTag(R.id.button_style, remoteButtonStyle1);
        mFrame1.setTag(R.id.button_type, remoteButtonType);
        mFrame1.setTag(R.id.button_height, BUTTON_HEIGHT_1);
        
        mFrame1.requestLayout();
        /*  */
        
        if(remoteButtonType == TYPE_DUAL) {
            mFrame2.setVisibility(View.VISIBLE);
            mTextView2.setVisibility(View.INVISIBLE);
            mImageView2.setVisibility(View.VISIBLE);

            mTextViewMiddle.setText(TEXT_MIDDLE.toUpperCase());
            mTextViewMiddle.setVisibility(View.VISIBLE);
            mTextViewMiddle.getLayoutParams().height = (int) ViewUtils.dpToPx(getContext(), TEXT_MIDDLE_HEIGHT);
            
            mFrame2.setBackgroundDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonBackgroundID(BUTTON_NAME_2)));
            mFrame2.getLayoutParams().height = (int) ViewUtils.dpToPx(getContext(), BUTTON_HEIGHT_2);
            mTextView2.setText(BUTTON_NAME_2.toUpperCase());
            mImageView2.setImageDrawable(ContextCompat.getDrawable(getContext(), getRemoteButtonResourceID(BUTTON_NAME_2)));

            if(remoteButtonStyle2 == STYLE_TEXT) {
                mTextView2.setVisibility(View.VISIBLE);
                mImageView2.setVisibility(View.INVISIBLE);
            } else if(remoteButtonStyle2 == STYLE_IMAGE_IF_AVAILABLE) {
                if(getRemoteButtonResourceID(BUTTON_NAME_2) != R.drawable.rem_default) {
                    mTextView2.setVisibility(View.INVISIBLE);
                    mImageView2.setVisibility(View.VISIBLE);
                } else {
                    mTextView2.setVisibility(View.VISIBLE);
                    mImageView2.setVisibility(View.INVISIBLE);
                }
            }
            
            mTextViewMiddle.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        if(mClickListener != null) {
                            mClickListener.onClick(p1, TEXT_MIDDLE);
                        }
                    }
                });

            mFrame2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View p1) {
                        if(mClickListener != null) {
                            mClickListener.onClick(p1, BUTTON_NAME_2);
                        }
                    }
                });

            mFrame2.setOnLongClickListener(new View.OnLongClickListener() {

                    @Override
                    public boolean onLongClick(View p1) {
                        if(mLongClickListener != null) {
                            mLongClickListener.onLongClick(p1, BUTTON_NAME_2);
                        }

                        return false;
                    }
                });
                
            mFrame2.setTag(R.id.button_name, BUTTON_NAME_2);
            mFrame2.setTag(R.id.button_style, remoteButtonStyle2);
            mFrame2.setTag(R.id.button_type, remoteButtonType);
            mFrame2.setTag(R.id.button_height, BUTTON_HEIGHT_2);
               
            mFrame2.requestLayout();
            
            /*  */
            
            if(!BUTTON_NAME_1.equalsIgnoreCase("empty") && !BUTTON_NAME_2.equalsIgnoreCase("empty") && !TEXT_MIDDLE.equalsIgnoreCase("add") && !TEXT_MIDDLE.equalsIgnoreCase("empty")) {
                mFrame1.setBackgroundDrawable(null);
                mFrame2.setBackgroundDrawable(null);
                
                mParentLayout.setBackgroundDrawable(ContextCompat.getDrawable(getContext(), R.drawable.remote_button));
            } else {
                mParentLayout.setBackgroundDrawable(null);
            }
        }
    }
    
    public interface OnRemoteClickListener {
        public void onClick(View view, String button);
    }
    
    public interface OnRemoteLongClickListener {
        public void onLongClick(View view, String button);
    }
    
    public void setOnRemoteClickListener(OnRemoteClickListener listener) {
        this.mClickListener = listener;
    }
    
    public void setOnRemoteLongClickListener(OnRemoteLongClickListener listener) {
        this.mLongClickListener = listener;
    }
    
    public RemoteButton setRemoteButton1(String button) {
        BUTTON_NAME_1 = button;
        return this;
    }
    
    public RemoteButton setRemoteButton2(String button) {
        BUTTON_NAME_2 = button;
        return this;
    }
    
    public RemoteButton setRemoteButton1(String button, int style) {
        BUTTON_NAME_1 = button;
        remoteButtonStyle1 = style;
        return this;
    }

    public RemoteButton setRemoteButton2(String button, int style) {
        BUTTON_NAME_2 = button;
        remoteButtonStyle2 = style;
        return this;
    }
    
    public RemoteButton setRemoteButton1(String button, int style, int height) {
        BUTTON_NAME_1 = button;
        remoteButtonStyle1 = style;
        BUTTON_HEIGHT_1 = height;
        return this;
    }

    public RemoteButton setRemoteButton2(String button, int style, int height) {
        BUTTON_NAME_2 = button;
        remoteButtonStyle2 = style;
        BUTTON_HEIGHT_2 = height;
        return this;
    }
    
    public RemoteButton setRemoteMiddleText(String text) {
        TEXT_MIDDLE = text;
        return this;
    }
    
    public RemoteButton setRemoteMiddleText(String text, int height) {
        TEXT_MIDDLE = text;
        TEXT_MIDDLE_HEIGHT = height;
        return this;
    }
    
    public RemoteButton setRemoteButtonHeight1(int height) {
        BUTTON_HEIGHT_1 = height;
        return this;
    }

    public RemoteButton setRemoteButtonHeight2(int height) {
        BUTTON_HEIGHT_2 = height;
        return this;
    }
    
    public RemoteButton setRemoteButtonType(int type) {
        remoteButtonType = type;
        return this;
    }
   
    public RemoteButton setRemoteButtonTag(View view, int key, Object value) {
        view.setTag(key, value);
        return this;
    }
    
    public RemoteButton setRemoteButtonTag(int button, int key, Object value) {
        if(button == BUTTON_1) {
            mFrame1.setTag(key, value);
        } else if (button == BUTTON_2) {
            mFrame2.setTag(key, value);
        }
        return this;
    }
    
    public RemoteButton setRemoteSoundEffects(boolean state) {
        remoteTapSounds = state;
        return this;
    }
    
    //
    
    public View getRemoteParentButtonView() {
        return mParentLayout;
    }
    
    public View getRemoteButtonView(int button) {
        if(button == BUTTON_1) {
            return mFrame1;
        } else if (button == BUTTON_2) {
            return mFrame2;
        }
        
        return null;
    }
    
    public View getRemoteButtonMiddleTextView() {
        return mTextViewMiddle;
    }
    
    public String getRemoteButton1() {
        return BUTTON_NAME_1;
    }
    
    public String getRemoteButton2() {
        return BUTTON_NAME_2;
    }
    
    public String getRemoteMiddleText() {
        return TEXT_MIDDLE;
    }
    
    public int getRemoteButtonHeight(int button) {
        if(button == BUTTON_1) {
            return BUTTON_HEIGHT_1;
        } else if (button == BUTTON_2) {
            return BUTTON_HEIGHT_2;
        }

        return 0;
    }
    
    public int getRemoteButtonStyle(int button) {
        if(button == BUTTON_1) {
            return remoteButtonStyle1;
        } else if (button == BUTTON_2) {
            return remoteButtonStyle2;
        }
        
        return 0;
    }
    
    public int getRemoteButtonType() {
        return remoteButtonType;
    }
    
    /*  */
    
    private int getRemoteButtonResourceID(String button) {
        final String[] REMOTE_RESOURCES_NAME = Constant.REMOTE_RESOURCES_NAME;                                                                                                                               
        final int[] REMOTE_RESOURCES_ID = Constant.REMOTE_RESOURCES_ID;                                       
    
        int res_id = R.drawable.rem_default;
        for(int i=0; i<REMOTE_RESOURCES_NAME.length; i++) {
            if(button.equalsIgnoreCase(REMOTE_RESOURCES_NAME[i])) {
                res_id = REMOTE_RESOURCES_ID[i];
            }
        }
        
        return res_id;
    }
    
    private int getRemoteButtonBackgroundID(String button) {  
        if(button.equalsIgnoreCase("empty")) {
            return R.drawable.remote_button_dotted;
        } else {
            return R.drawable.remote_button;
        }
    }
}
