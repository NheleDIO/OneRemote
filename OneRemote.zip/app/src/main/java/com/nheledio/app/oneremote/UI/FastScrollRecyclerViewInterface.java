package com.nheledio.app.oneremote.UI;

import java.util.HashMap;

public interface FastScrollRecyclerViewInterface {
    public HashMap<String,Integer> getMapIndex();
}
