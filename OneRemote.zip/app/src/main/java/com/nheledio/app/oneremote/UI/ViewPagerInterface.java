package com.nheledio.app.oneremote.UI;

public interface ViewPagerInterface {
    Object getObjectAtPosition(int position);
}
