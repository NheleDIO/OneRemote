package com.nheledio.app.oneremote.Utils;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.AsyncTask;
import com.nheledio.app.oneremote.R;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.graphics.drawable.ColorDrawable;

public class DownloadUtils extends AsyncTask<String, Integer, String> {
    private Context mContext;
    private ProgressDialog mProgressDialog;
    private File mTargetFile;

    private int DOWNLOAD_RESULT = 0;
    public static int DOWNLOAD_CONNECTION_ERROR = 2;
    public static int DOWNLOAD_UNKNOWN_ERROR = 4;
    public static int DOWNLOAD_CANCELLED = 3;
    public static int DOWNLOAD_SUCCESS = 0;
    public static int DOWNLOAD_ERROR = 1;

    private OnDownloadCompleted mListener;

    public interface OnDownloadCompleted{
        void onDownloadCompleted(int result);
    }

    public void setOnDownloadComplete(OnDownloadCompleted listener) {
        this.mListener = listener;
    }
    
    public DownloadUtils(Context context, File targetFile) {
        this.mContext = context;
        this.mTargetFile = targetFile;
    }

    public DownloadUtils(Context context, File targetFile, String dialogMessage) {
        this.mContext = context;
        this.mTargetFile = targetFile;

        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setMessage(dialogMessage);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		
		int[] attrs = {android.R.attr.windowBackground};
		TypedArray typedValue = context.getTheme().obtainStyledAttributes(R.attr.alertDialogTheme, attrs); 
		int color = typedValue.getColor(0, Color.BLACK);
		mProgressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(color));
        
        mProgressDialog.setCancelable(false);

        final DownloadUtils mDownloadUtils = this;
        mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    mDownloadUtils.cancel(true);
                }
            });
    }

    @Override
    protected String doInBackground(String... sUrl) {
        InputStream input = null;
        OutputStream output = null;
        HttpURLConnection connection = null;

        try {
            URL url = new URL(sUrl[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                DOWNLOAD_RESULT = DOWNLOAD_CONNECTION_ERROR;
                return "CONNECTION_ERROR";
            }

            int mFileLength = connection.getContentLength();

            input = connection.getInputStream();
            output = new FileOutputStream(mTargetFile, false);

            byte data[] = new byte[4096];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {

                if (isCancelled()) {
                    input.close();
                    if(mListener != null) {
                        mListener.onDownloadCompleted(DOWNLOAD_RESULT);
                    }
                    DOWNLOAD_RESULT = DOWNLOAD_CANCELLED;
                    return "CANCELLED";
                }

                total += count;

                if (mFileLength > 0) {
                    publishProgress((int) ((total * 100) / mFileLength)); 
                }

                output.write(data, 0, count);
            }

        } catch (Exception e) {
            DOWNLOAD_RESULT = DOWNLOAD_ERROR;
            return "EXCEPTION_ERROR";
        } finally {
            try {
                if (output != null) {
                    output.close();
                }
                if (input != null) {
                    input.close();
                }
            } catch (IOException e) {
                DOWNLOAD_RESULT = DOWNLOAD_ERROR;
                return "IOEXCEPTION_ERROR";
            }

            if (connection != null)
                connection.disconnect();
        }

        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        if(mProgressDialog !=null) {
            mProgressDialog.show();
        }
    }

    @Override
    protected void onProgressUpdate(Integer... progress) {
        super.onProgressUpdate(progress);

        if(mProgressDialog !=null) {
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setMax(100);
            mProgressDialog.setProgress(progress[0]);
        }
    }

    @Override
    protected void onPostExecute(String result) {
        
        if(mProgressDialog != null) {
            mProgressDialog.dismiss();
        }

        if(mListener != null) {
            mListener.onDownloadCompleted(DOWNLOAD_RESULT);
        }
    }
}
