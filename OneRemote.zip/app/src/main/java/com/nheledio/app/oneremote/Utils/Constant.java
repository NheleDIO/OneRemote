package com.nheledio.app.oneremote.Utils;

import com.nheledio.app.oneremote.R;
import com.physicaloid.lib.Boards;

public class Constant {
    
	public static final String APP_NAME = "OneRemote";
	public static final String APP_DEVELOPER = "@jhonheledio";
    public static final String APP_DEVELOPER_CONTACT = "https://t.me/jhonheledio";
	public static final String APP_DEVELOPER_PAYPAL = "https://www.paypal.me/jhonniledio";
    public static final String APP_FOLDER_PATH = "OneRemote";
    public static final String URL_REMOTE_RESOURCES_CODES = "https://drive.google.com/uc?export=download&id=10ybe5H_F6undbuM01Z01dOw54KgZIwpI";
    public static final String URL_REMOTE_RESOURCES_LAYOUT = "https://drive.google.com/uc?export=download&id=10yzqaoWpefX7hwA--CXhIrOR1p3NCXiN";
    
    public static final String URL_PRIVACY_POLICY = "https://oneremote.flycricket.io/privacy.html";
    public static final String URL_USER_AGREEMENT = "https://oneremote.flycricket.io/terms.html";
    
    public static final int DEFAULT_IR_FREQUENCY = 33000;
    public static final String REMOTE_KEY_POWER = "POWER";
	public static final String PREF_REMOTE_LIST = "REMOTE_LIST";
	public static final String PREF_REMOTE_HAS_CHANGES = "REMOTE_HAS_CHANGES";
	public static final String PREF_REMOTE_RESOURCES_ONLINE = "REMOTE_RESOURCES_ONLINE";
    
	public static final String[] REMOTE_RESOURCES_NAME = {"bigsmall", "light", "timing", "empty", "backward", "down", "forward", "home", "left", "menu", "minus", "more", "mute", "next", "numpad", "pause", "play", "plus", "power", "previous", "record", "right", "stop", "up", "default", "exit", "vol_plus", "vol_minus", "ch_plus", "ch_minus", "play_pause", "switch", "setting"};																																
	public static final int[] REMOTE_RESOURCES_ID = {R.drawable.rem_wind, R.drawable.rem_light, R.drawable.rem_time,R.drawable.ic_add, R.drawable.rem_backward, R.drawable.rem_down, R.drawable.rem_forward, R.drawable.rem_home, R.drawable.rem_left, R.drawable.rem_menu, R.drawable.rem_minus, R.drawable.rem_more, R.drawable.rem_mute, R.drawable.rem_next, R.drawable.rem_numpad, R.drawable.rem_pause, R.drawable.rem_play, R.drawable.rem_plus, R.drawable.rem_power, R.drawable.rem_previous, R.drawable.rem_record, R.drawable.rem_right, R.drawable.rem_stop, R.drawable.rem_up, R.drawable.rem_default, R.drawable.rem_exit, R.drawable.rem_plus, R.drawable.rem_minus, R.drawable.rem_plus, R.drawable.rem_minus, R.drawable.rem_playpause, R.drawable.rem_switch, R.drawable.rem_settings};										
	
	public static final String[] REMOTE_CATEGORY_NAME = {"tv", "av receiver", "dvd", "fan", "projector", "camera", "diffuser", "ac", "default"};
	public static final int[] REMOTE_CATEGORY_ID = 	{R.drawable.ic_tv, R.drawable.ic_av_receiver, R.drawable.ic_disc, R.drawable.ic_fan, R.drawable.ic_projector, R.drawable.ic_camera, R.drawable.ic_diffuser, R.drawable.ic_air_conditioner, R.drawable.ic_default};

    public static final String ASSET_FILE_CODES = "oneremote/oneremote_codes.dio";
    public static final String ASSET_FILE_LAYOUT = "oneremote/oneremote_layout.dio";
	public static final String ASSET_FILE_CODES_SCHEMA = "oneremote/oneremote_codes_schema.xml";
    public static final String ASSET_FILE_LAYOUT_SCHEMA = "oneremote/oneremote_layout_schema.xml";
	
    public static final int REMOTE_VIBRATE_LENGTH = 50;
	
	public static final String PREF_ARDUINO_IS_UPLOAD = "ARDUINO_IS_UPLOAD";
	public static final String PREF_ARDUINO_BOARD = "ARDUINO_BOARD";
	public static final String PREF_ARDUINO_BAUD_RATE = "ARDUINO_BAUD_RATE";
	public static final String PREF_ARDUINO_MONITOR_TEXT_SIZE = "ARDUINO_MONITOR_TEXT_SIZE";
	
	public static final String[] ARDUINO_BOARD_NAME = {"Arduino Uno", "Arduino Duemilanove ATmega328", "Arduino Diecimila/Duemilanove ATmega168", "Arduino Nano ATmega328", "Arduino Nano ATmega168", "Arduino Mega 2560/ADK", "Arduino Mega (ATmega1280)", "Arduino Mini ATmega328", "Arduino Mini ATmega168", "Arduino Ethernet", "Arduino Fio", "Arduino BT ATmega328", "Arduino BT ATmega168", "LilyPad Arduino ATmega328", "LilyPad Arduino ATmega168", "Arduino Pro/Pro Mini (5V, 16MHz) ATmega328", "Arduino Pro/Pro Mini (5V, 16MHz) ATmega168", "Arduino Pro/Pro Mini (3.3V, 8MHz) ATmega328", "Arduino Pro/Pro Mini (3.3V, 8MHz) ATmega168", "Arduino NG/Older ATmega168", "Arduino NG/Older ATmega8", "Balanduino", "PocketDuino"};
	public static final Boards[] ARDUINO_BOARD_ID = {Boards.ARDUINO_UNO, Boards.ARDUINO_DUEMILANOVE_328, Boards.ARDUINO_DUEMILANOVE_168, Boards.ARDUINO_NANO_328, Boards.ARDUINO_NANO_168, Boards.ARDUINO_MEGA_2560_ADK, Boards.ARDUINO_MEGA_1280, Boards.ARDUINO_MINI_328, Boards.ARDUINO_MINI_168, Boards.ARDUINO_ETHERNET, Boards.ARDUINO_FIO, Boards.ARDUINO_BT_328, Boards.ARDUINO_BT_168, Boards.ARDUINO_LILYPAD_328, Boards.ARDUINO_LILYPAD_168, Boards.ARDUINO_PRO_5V_328, Boards.ARDUINO_PRO_5V_168, Boards.ARDUINO_PRO_33V_328, Boards.ARDUINO_PRO_33V_168, Boards.ARDUINO_NG_168, Boards.ARDUINO_NG_8, Boards.BALANDUINO, Boards.POCKETDUINO};
    public static final String[] ARDUINO_BAUD_RATE = {"9600"};
	
	public static final String CUSTOM_REMOTE_KEYS_GET_COMMAND = "/default";
	public static final String[] CUSTOM_REMOTE_KEYS_TV = {"power", "mute", "pmode", "smode", "sleep", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "setting", "switch", "source", "home", "up", "left" ,"right", "down", "enter", "menu", "exit", "vol_plus", "vol_minus", "ch_plus", "ch_minus", "display", "aspect", "tv", "usb", "mts", "mouse", "epg", "cc", "record", "play_pause", "previous", "next", "stop", "backward", "forward"};
}
