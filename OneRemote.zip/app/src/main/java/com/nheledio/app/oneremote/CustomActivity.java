package com.nheledio.app.oneremote;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.hardware.ConsumerIrManager;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.nheledio.app.oneremote.Adapter.CustomButtonAdapter;
import com.nheledio.app.oneremote.Adapter.CustomRemoteAdapter;
import com.nheledio.app.oneremote.Adapter.CustomRemotePagerAdapter;
import com.nheledio.app.oneremote.UI.RemoteButton;
import com.nheledio.app.oneremote.UI.Snackbar;
import com.nheledio.app.oneremote.UI.ViewPager;
import com.nheledio.app.oneremote.Utils.Constant;
import com.nheledio.app.oneremote.Utils.DayNightModeHelper;
import com.physicaloid.lib.Physicaloid;
import com.physicaloid.lib.Physicaloid.UploadCallBack;
import com.physicaloid.lib.programmer.avr.UploadErrors;
import com.physicaloid.lib.usb.driver.uart.ReadLisener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import com.physicaloid.lib.Boards;

public class CustomActivity extends AppCompatActivity implements View.OnClickListener {
    
    private Toolbar mToolbar;
    private ImageView mToolbarButton1;
    private ImageView mToolbarButton2;

	private CoordinatorLayout mMainLayout;
    
    private ViewPager mViewPager;
    private CustomRemotePagerAdapter mViewPagerAdapter;
	
	private ConsumerIrManager mIRManager;
	
	private String mName = "";
	private String mCategory = "";
	private LinkedHashMap mNewButtons;
	
	private ArrayList mRemoteList;
	
	private static final int PERMISSION_REQUEST_CODE = 1;
	
	private boolean mHasChanges = false;
	private boolean mIsSaved = false;
	private boolean mFlag = false;
	
	private boolean mIsMonitorRunning = false;
	private boolean mIsMonitorPaused = false;
	private boolean mIsUSBAttached = false;
	
	private Physicaloid mPhysicaloid;
	private Handler mHandler = new Handler();
	private String mSerialMessage = "";
	private TextView mTextMonitor;
	private NestedScrollView mScrollTextMonitor;
	private CustomButtonAdapter mCustomButtonAdapter2;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Initialize();
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_custom);
        
        mMainLayout = findViewById(R.id.activity_custom_coord_layout);

        InitToolbar();
        InitCustomRemote();
    }
    
    @Override
    public void onClick(View p1) {
        int id = p1.getId();

        switch(id) {
            case R.id.toolbar_button_1:
                onBackPressed();
                break;
			case R.id.toolbar_button_2:
				if(mViewPager.getCurrentItem() == 0) {
					PopupMenu menu = new PopupMenu(this, mToolbarButton2);
					menu.getMenu().add("Create Remote");
					menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							@Override
							public boolean onMenuItemClick(MenuItem p1) {
								switch(p1.getTitle().toString()) {
									case "Create Remote":
										mViewPager.setCurrentItem(mViewPager.getCurrentItem()+1, true);
										break;
								}
								return false;
							}
						});
					menu.show();
				} else if(mViewPager.getCurrentItem() == 1) {
					mViewPager.setCurrentItem(mViewPager.getCurrentItem()+1, true);
				} else if(mViewPager.getCurrentItem() == 2) {
					PopupMenu menu = new PopupMenu(this, mToolbarButton2);
					menu.getMenu().add("Arduino Decoder");
					menu.getMenu().add("Save");
					menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							@Override
							public boolean onMenuItemClick(MenuItem p1) {
								switch(p1.getTitle().toString()) {
									case "Arduino Decoder":
										mViewPager.setCurrentItem(mViewPager.getCurrentItem()+1, true);
										break;
									case "Save":
										SaveRemoteToFile();
										break;
								}
								return false;
							}
						});
					menu.show();
				} else if(mViewPager.getCurrentItem() == 3) {
					PopupMenu menu = new PopupMenu(this, mToolbarButton2);
					menu.getMenu().add("Arduino Settings");
					menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
							@Override
							public boolean onMenuItemClick(MenuItem p1) {
								switch(p1.getTitle().toString()) {
									case "Arduino Settings":
										Intent intent = new Intent(CustomActivity.this, SettingsActivity.class);
										intent.putExtra("mode", SettingsActivity.MODE_SETTINGS_ARDUINO);
										startActivity(intent);
										break;
								}
								return false;
							}
						});
					menu.show();
				}
                 
                break;
        }
	}
    
    @Override
    public void onBackPressed() {
		if(mViewPager.getCurrentItem() != 0) {
			mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_next));
			if(mViewPager.getCurrentItem() == 1 && mRemoteList.size() == 0) {
				if(mHasChanges) {
					AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
					alertBuild.setTitle("Edit Remote");
					alertBuild.setMessage("Discard Changes?");
					alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface p1, int p2) {
								finish();
							}
						});
					alertBuild.setNegativeButton("No", null);

					AlertDialog alert = alertBuild.create();
					alert.show();
				} else {
					super.onBackPressed();
					return;
				}
			} else {
				mViewPager.setCurrentItem(mViewPager.getCurrentItem()-1, true);
			}
		} else {
			if(mHasChanges) {
				AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
				alertBuild.setTitle("Edit Remote");
				alertBuild.setMessage("Discard Changes?");
				alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface p1, int p2) {
							finish();
						}
					});
				alertBuild.setNegativeButton("No", null);

				AlertDialog alert = alertBuild.create();
				alert.show();
			} else {
				super.onBackPressed();
				return;
			}
		}
    }
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
		switch (requestCode) {
			case PERMISSION_REQUEST_CODE:
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					if(mFlag) {
						mFlag = false;
						SaveRemoteToFile();
					}
				} else {
					AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
					alertBuild.setTitle("Storage Permission");
					alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Save Your Remote Configurations And Custom Layouts.");
					alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface p1, int p2) {
								final Intent intent = new Intent();
								intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
								intent.addCategory(Intent.CATEGORY_DEFAULT);
								intent.setData(Uri.parse("package:" + getPackageName()));
								intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
								intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
								startActivity(intent);
							}
						});
					alertBuild.setNegativeButton("Cancel", null);

					AlertDialog alert = alertBuild.create();
					alert.show();
				}
				break;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		
		IntentFilter filter = new IntentFilter();
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver(mUsbReceiver, filter);
		
		if(mTextMonitor != null) {
			SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(CustomActivity.this);
			mTextMonitor.setTextSize(TypedValue.COMPLEX_UNIT_SP, mPrefs.getInt(Constant.PREF_ARDUINO_MONITOR_TEXT_SIZE, 15));
		}
		
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(CustomActivity.this);
		if(mPrefs.getBoolean(Constant.PREF_ARDUINO_IS_UPLOAD, false)) {
			SharedPreferences.Editor mEditor = mPrefs.edit();
			mEditor.putBoolean(Constant.PREF_ARDUINO_IS_UPLOAD, false);
			mEditor.apply();
			
			ArduinoCommandMonitor(mTextMonitor,"/upload", "", mCustomButtonAdapter2, mNewButtons, 0);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		unregisterReceiver(mUsbReceiver);
	}


    /*  */

    private void Initialize() {
        AppCompatDelegate.setDefaultNightMode(DayNightModeHelper.createInstance().getDayNightSavedState(CustomActivity.this));
    }
    
    private void InitToolbar() {
        mToolbar = findViewById(R.id.toolbar_custom);
        mToolbarButton1 = mToolbar.findViewById(R.id.toolbar_button_1);
        mToolbarButton2 = mToolbar.findViewById(R.id.toolbar_button_2);
        
        mToolbarButton1.setOnClickListener(this);
        mToolbarButton2.setOnClickListener(this);
		
		mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_dot));
		setEnabled(mToolbarButton2, true);

        setSupportActionBar(mToolbar);
	}
    
    private void InitCustomRemote() {
        mViewPager = findViewById(R.id.custom_viewpager);

        ArrayList mList = new ArrayList();
		
		View mPage1 = LayoutInflater.from(this).inflate(R.layout.custom_remote_1, null, false);
		final ImageView mImageView = mPage1.findViewById(R.id.activity_custom);
		final RecyclerView mRecyclerView1 = mPage1.findViewById(R.id.custom_remote_recycler_view_1);
		
		mRecyclerView1.setItemAnimator(new DefaultItemAnimator());
		mRecyclerView1.setHasFixedSize(true);

		LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(CustomActivity.this);
		mRecyclerView1.setLayoutManager(linearLayoutManager1);
		
		try {
			if(checkPermission()) {
				mRemoteList = GetRemoteListCustom();
			}
		} catch (IOException e) {} catch (XmlPullParserException e) {} catch(Exception e) {} finally {
			if(mRemoteList != null) {
				Collections.sort(mRemoteList, new Comparator<LinkedHashMap>() {
						@Override
						public int compare(LinkedHashMap p1, LinkedHashMap p2) {
							return p1.get("name").toString().compareTo(p2.get("name").toString());
						}
					});

				Collections.sort(mRemoteList, new Comparator<LinkedHashMap>() {
						@Override
						public int compare(LinkedHashMap p1, LinkedHashMap p2) {
							return p1.get("category").toString().compareTo(p2.get("category").toString());
						}
					});

				if(mRemoteList.size() != 0) {
					mImageView.setVisibility(View.GONE);
				} else {
					mImageView.setVisibility(View.VISIBLE);

					mRemoteList = new ArrayList();
					File mFile = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
					if(mFile.exists()) {
						mFile.delete();
					}
				}
			} else {
				mRemoteList = new ArrayList();
				File mFile = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
				if(mFile.exists()) {
					mFile.delete();
				}
			}
		}
		
		
		final CustomRemoteAdapter mCustomRemoteAdapter = new CustomRemoteAdapter(CustomActivity.this, mRemoteList);
		mRecyclerView1.setAdapter(mCustomRemoteAdapter);
		
		mCustomRemoteAdapter.setOnItemClicked(new CustomRemoteAdapter.OnItemClicked() {
				@Override
				public void onClicked(final int position) {
					AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
					alertBuild.setTitle("Delete Remote");
					alertBuild.setMessage("Delete \"" + ((LinkedHashMap)mRemoteList.get(position)).get("name").toString() + " - " + ((LinkedHashMap)mRemoteList.get(position)).get("category").toString() + "\" And All Of Its Set Of Key Codes?");									
					alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface p1, int p2) {
								String name = ((LinkedHashMap)mRemoteList.get(position)).get("name").toString();
								String category = ((LinkedHashMap)mRemoteList.get(position)).get("category").toString();
								
								if(RemoveRemoteButtonCustom(name, category) != null) {
									mCustomRemoteAdapter.removeItemAt(position);
									//mRemoteList.remove(position);
									
									Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
									mSnackbar.setText(name+" Remote Deleted.", getResources().getColor(R.color.white));
									mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_delete), getResources().getColor(R.color.white));
									mSnackbar.setSnackColor(getResources().getColor(R.color.red_500));
									mSnackbar.show();
								}
								
								if(mCustomRemoteAdapter.getItemCount() > 0) {
									mImageView.setVisibility(View.GONE);
								} else {
									mImageView.setVisibility(View.VISIBLE);
									
									File mRoot = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom");
									File mFile = new File(mRoot, "oneremote_custom_codes.dio");
									if(mFile.exists()) {
										mFile.delete();
									}
								}
							}
						});
					alertBuild.setNegativeButton("No", null);

					AlertDialog alert = alertBuild.create();
					alert.show();
				}
			});
		
		mList.add(mPage1);
		
		/*  */
        
        View mPage2 = LayoutInflater.from(this).inflate(R.layout.custom_remote_2, null, false);
        final TextInputLayout mEditLayout1 = mPage2.findViewById(R.id.custom_remote_name_layout);
        final TextInputEditText mEditText1 = mPage2.findViewById(R.id.custom_remote_name_edittext);
        final TextInputLayout mEditLayout2 = mPage2.findViewById(R.id.custom_remote_category_layout);
        final TextInputEditText mEditText2 = mPage2.findViewById(R.id.custom_remote_category_edittext);
        final TextInputLayout mEditLayout3 = mPage2.findViewById(R.id.custom_remote_button_layout);
        final TextInputEditText mEditText3 = mPage2.findViewById(R.id.custom_remote_button_edittext);
        final TextView mTextView = mPage2.findViewById(R.id.custom_remote_text_view);
        final RecyclerView mRecyclerView2 = mPage2.findViewById(R.id.custom_remote_recycler_view);
        final LinearLayout mLayout3 = mPage2.findViewById(R.id.content_custom_layout_3);
        final MaterialButton mButton = mPage2.findViewById(R.id.custom_remote_button_main);
         
        mMainLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    Rect r = new Rect();
					mMainLayout.getWindowVisibleDisplayFrame(r);
					int screenHeight = mMainLayout.getRootView().getHeight();
					int keypadHeight = screenHeight - r.bottom;

					if(mEditText1.isFocused() || mEditText2.isFocused()) {
						if (keypadHeight > screenHeight * 0.15) { 
							mLayout3.setVisibility(View.GONE);
						} else {
							mLayout3.postDelayed(new Runnable() {
									public void run() {
										mLayout3.setVisibility(View.VISIBLE);
									}
								}, 200);
						}
					}
                }
            });
            
        mNewButtons = new LinkedHashMap();
        final CustomButtonAdapter mCustomButtonAdapter = new CustomButtonAdapter(this, mNewButtons, CustomButtonAdapter.MODE_ADD);
        
        mRecyclerView2.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView2.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(CustomActivity.this);
        mRecyclerView2.setLayoutManager(linearLayoutManager2);
        mRecyclerView2.setAdapter(mCustomButtonAdapter);
		
		mCustomButtonAdapter.setOnItemClicked(new CustomButtonAdapter.OnItemClicked() {
				@Override
				public void onClicked(String key, int position) {
					//Toast.makeText(CustomActivity.this, key, Toast.LENGTH_SHORT).show();
				}
			});
			
		mCustomButtonAdapter.setOnItemLongClicked(new CustomButtonAdapter.OnItemLongClicked() {
				@Override
				public void onLongClicked(String key, int position) {
					try {
						mCustomButtonAdapter.removeItemAt(key, position);
						if(mNewButtons.containsKey(key)) {
							mNewButtons.remove(key);
						}

						if(mCustomButtonAdapter.getItemCount() > 0) {
							mTextView.setVisibility(View.GONE);
						} else {
							mTextView.setVisibility(View.VISIBLE);
						}
						
						Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
						mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
					} catch(Exception e) {}
					
					setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0));
				}
			});
			
		mEditLayout1.setHelperText("");
		mEditLayout2.setHelperText("");
		mEditLayout3.setHelperText("");
        
        mEditText1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View p1, boolean p2) {
					mEditLayout1.setHelperTextEnabled(p2);
					mRecyclerView2.setScrollContainer(!p2);
					
					if(p2) {
						mEditLayout1.setHelperText("e.g. Samsung");
					} else {
						mEditLayout1.setHelperText("");
					}
                }
            });
            
        mEditText2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View p1, boolean p2) {
                    mEditLayout2.setHelperTextEnabled(p2);
					mRecyclerView2.setScrollContainer(!p2);
					
					if(p2) {
						mEditLayout2.setHelperText("e.g. TV");
					} else {
						mEditLayout2.setHelperText("");
					}
                }
            });
            
        mEditText3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View p1, boolean p2) {
                    mEditLayout3.setHelperTextEnabled(p2);

					if(p2) {
						mEditLayout3.setHelperText("e.g. power");
					} else {
						mEditLayout3.setHelperText("");
					}
                }
            });
            
        mButton.setEnabled(false);
		
		mEditText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
					mHasChanges = true;
					
					mName = mEditText1.getText().toString();
                    setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0)); 						
                }
            });
			
		mEditText2.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
					mHasChanges = true;
					
					mCategory = mEditText2.getText().toString();
                    setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0)); 						
                }
            });
        
        mEditText3.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {}

                @Override
                public void afterTextChanged(Editable p1) {
					mHasChanges = true;
					
                    mButton.setEnabled(!mEditText3.getText().toString().isEmpty());
                }
            });
            
        mButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
					mHasChanges = true;
					
					if(mEditText3.getText().toString().equalsIgnoreCase(Constant.CUSTOM_REMOTE_KEYS_GET_COMMAND)) {
						AlertDialog.Builder alertBuilder = new AlertDialog.Builder(CustomActivity.this);
						alertBuilder.setTitle("Remote Keys");
						alertBuilder.setItems(Constant.REMOTE_CATEGORY_NAME, new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface p1, int p2) {
									switch(Constant.REMOTE_CATEGORY_NAME[p2].toLowerCase()) {
										case "tv":
											for(int i=0; i<Constant.CUSTOM_REMOTE_KEYS_TV.length; i++) {
												mNewButtons.put(Constant.CUSTOM_REMOTE_KEYS_TV[i], "");
											}
											
											mCustomButtonAdapter.notifyDataSetChanged();
											break;
									}
									
									if(mCustomButtonAdapter.getItemCount() > 0) {
										mTextView.setVisibility(View.GONE);
									} else {
										mTextView.setVisibility(View.VISIBLE);
									}

									mEditText3.setText("");
									setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0));
								}
							});
						alertBuilder.create().show();
						
					} else {
						if(!mNewButtons.containsKey(mEditText3.getText().toString())) {
							mNewButtons.put(mEditText3.getText().toString().trim(), "");
							mCustomButtonAdapter.notifyDataSetChanged();
						} else {
							mEditLayout3.setError("Button Already Defined");
							mEditLayout3.postDelayed(new Runnable() {
									public void run() {
										mEditLayout3.setError("");
									}
								}, 2000); 
						}
					}
                    
					if(mCustomButtonAdapter.getItemCount() > 0) {
						mTextView.setVisibility(View.GONE);
					} else {
						mTextView.setVisibility(View.VISIBLE);
					}
					
					mEditText3.setText("");
					setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0));
                }
            });
        
        mList.add(mPage2);
		
		/*  */
		
		View mPage3 = LayoutInflater.from(this).inflate(R.layout.custom_remote_3, null, false);
		final RemoteButton mRemoteButton = mPage3.findViewById(R.id.custom_remote_button);
		final RecyclerView mRecyclerView3 = mPage3.findViewById(R.id.custom_remote_recycler_view);
		
		mCustomButtonAdapter2 = new CustomButtonAdapter(this, mNewButtons, CustomButtonAdapter.MODE_EDIT);

        mRecyclerView3.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView3.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(CustomActivity.this);
        mRecyclerView3.setLayoutManager(linearLayoutManager3);
        mRecyclerView3.setAdapter(mCustomButtonAdapter2);

		/*mCustomButtonAdapter2.setOnItemClicked(new CustomButtonAdapter.OnItemClicked() {
				@Override
				public void onClicked(String key, int position) {
					mRemoteButton.setRemoteButton1(key, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
					mRemoteButton.UpdateRemote();
				}
			});*/

		mCustomButtonAdapter2.setOnItemLongClicked(new CustomButtonAdapter.OnItemLongClicked() {
				@Override
				public void onLongClicked(String key, int position) {
					Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);

					ShowAlertButtonDialog(mCustomButtonAdapter2, mNewButtons, key, position);
				}
			});
			
		mRemoteButton.setOnRemoteClickListener(new RemoteButton.OnRemoteClickListener() {
				@Override
				public void onClick(View view, String button) {
					if(mNewButtons.containsKey(button) && mNewButtons.getOrDefault(button, null) != null) {
						if(!mNewButtons.get(button).toString().isEmpty()) {
							TransmitRemoteSignal(mNewButtons.get(button).toString());
						} 
					}
				}
			});
		
		mList.add(mPage3);
		
		/*  */
		
		View mPage4 = LayoutInflater.from(this).inflate(R.layout.custom_remote_4, null, false);
		mTextMonitor = mPage4.findViewById(R.id.custom_remote_text_view);
		mScrollTextMonitor = mPage4.findViewById(R.id.custom_remote_scroll_view);
		final RecyclerView mRecyclerView4 = mPage4.findViewById(R.id.custom_remote_recycler_view);
		final MaterialButton mButton1 = mPage4.findViewById(R.id.custom_remote_button_1);
		final MaterialButton mButton2 = mPage4.findViewById(R.id.custom_remote_button_2);
		
		mPhysicaloid = new Physicaloid(this);
		
		mRecyclerView4.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView4.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager4 = new LinearLayoutManager(CustomActivity.this);
        mRecyclerView4.setLayoutManager(linearLayoutManager4);
        mRecyclerView4.setAdapter(mCustomButtonAdapter2);
		
		SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(CustomActivity.this);
		mTextMonitor.setTextSize(TypedValue.COMPLEX_UNIT_SP, mPrefs.getInt(Constant.PREF_ARDUINO_MONITOR_TEXT_SIZE, 15));
		
		SharedPreferences.Editor mEditor = mPrefs.edit();
		mEditor.putBoolean(Constant.PREF_ARDUINO_IS_UPLOAD, false);
		mEditor.apply();
		
		ArduinoCommandMonitor(mTextMonitor,"/reset", "", mCustomButtonAdapter2, mNewButtons, 0);
		
		mCustomButtonAdapter2.setOnItemClicked(new CustomButtonAdapter.OnItemClicked() {
				@Override
				public void onClicked(String key, int position) {
					if(mViewPager.getCurrentItem() == 2) {
						mRemoteButton.setRemoteButton1(key, RemoteButton.STYLE_IMAGE_IF_AVAILABLE);
						mRemoteButton.UpdateRemote();
					} else {
						if(mPhysicaloid.isOpened()) {
							ArduinoCommandMonitor(mTextMonitor,"/selected", key, mCustomButtonAdapter2, mNewButtons, position);
						}
					}
				}
			});
			
		mButton1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View p1) {
					if(mIsMonitorRunning) {
						ArduinoCommandMonitor(mTextMonitor,"/stop", "", mCustomButtonAdapter2, mNewButtons, 0);
					} else {
						ArduinoCommandMonitor(mTextMonitor,"/start", "", mCustomButtonAdapter2, mNewButtons, 0);
					}
					
					if(mIsMonitorRunning) {
						mButton1.setText("Stop");
					} else {
						mButton1.setText("Start");
					}
				}
			});
			
		mButton2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View p1) {
					mButton1.setText("Start");
					ArduinoCommandMonitor(mTextMonitor,"/reset", "", mCustomButtonAdapter2, mNewButtons, 0);
				}
			});
		
		mList.add(mPage4);
		
		/*  */
        
        mViewPagerAdapter = new CustomRemotePagerAdapter(this, mList);
        mViewPager.setAdapter(mViewPagerAdapter);
		mViewPager.setOffscreenPageLimit(mViewPagerAdapter.getCount()-1);
		mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
				@Override
				public void onPageScrolled(int p1, float p2, int p3) {
				}

				@Override
				public void onPageSelected(int p1) {
					if(p1 == 0) {
						mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_dot));
						setEnabled(mToolbarButton2, true);
						
						try {
							if(checkPermission()) {
								mRemoteList = GetRemoteListCustom();
							}
						} catch (IOException e) {} catch (XmlPullParserException e) {} catch(Exception e) {} finally {
							if(mRemoteList != null) {
								Collections.sort(mRemoteList, new Comparator<LinkedHashMap>() {
										@Override
										public int compare(LinkedHashMap p1, LinkedHashMap p2) {
											return p1.get("name").toString().compareTo(p2.get("name").toString());
										}
									});

								Collections.sort(mRemoteList, new Comparator<LinkedHashMap>() {
										@Override
										public int compare(LinkedHashMap p1, LinkedHashMap p2) {
											return p1.get("category").toString().compareTo(p2.get("category").toString());
										}
									});

								if(mRemoteList.size() != 0) {
									mImageView.setVisibility(View.GONE);
								} else {
									mImageView.setVisibility(View.VISIBLE);

									mRemoteList = new ArrayList();
									File mFile = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
									if(mFile.exists()) {
										mFile.delete();
									}
								}
							} else {
								mRemoteList = new ArrayList();
								File mFile = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
								if(mFile.exists()) {
									mFile.delete();
								}
							}
						}
						
						mCustomRemoteAdapter.refreshItems(mRemoteList);
						
					} else if(p1 == 1) {
						mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_next));
						setEnabled(mToolbarButton2, (!mEditText1.getText().toString().isEmpty() && !mEditText2.getText().toString().isEmpty() && mCustomButtonAdapter.getItemCount() > 0));
						
						if(mIsSaved) {
							mEditText1.setText("");
							mEditText2.setText("");
							mNewButtons = new LinkedHashMap();
							
							mCustomButtonAdapter.refreshItems(mNewButtons);
							
							mIsSaved = false;
							mHasChanges = false;
						}
					} else if(p1 == 2) {
						mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_dot));
						
						mCustomButtonAdapter2.notifyDataSetChanged();
						mRemoteButton.setRemoteButton1("empty");
						mRemoteButton.UpdateRemote();
						
						if(mIsMonitorRunning) {
							ArduinoCommandMonitor(mTextMonitor,"/pause", "", mCustomButtonAdapter2, mNewButtons, 0);
						} 
					} else if(p1 == 3) {
						mToolbarButton2.setImageDrawable(getResources().getDrawable(R.drawable.ic_menu_dot));

						mCustomButtonAdapter2.notifyDataSetChanged();
						
						if(mIsMonitorPaused) {
							ArduinoCommandMonitor(mTextMonitor,"/resume", "", mCustomButtonAdapter2, mNewButtons, 0);
						}
					}
				}

				@Override
				public void onPageScrollStateChanged(int p1) {}
			});
    }
    
    
    /*  */
	
	private String GenerateRemoteButtonCodes() {
		String mPath = null;

        try {
            File mRoot = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom");
            if (!mRoot.exists()) {
                mRoot.mkdirs();
            }

			String mContent1 = "";
			
			int configs = 1;
			int config = 1;
			boolean flag = false;
			boolean added = false;
			
            File mFile = new File(mRoot, "oneremote_custom_codes.dio");
            if(mFile.exists()) {
				BufferedReader br = new BufferedReader(new FileReader(mFile.getAbsolutePath()));  
				String line;   
				while ((line = br.readLine()) != null) {
					if(line.contains(mName) && line.contains(mCategory)) {
						flag = true;
						
						String temp = line;
						temp = temp.trim();
						temp = temp.replaceAll("\"", "");
						temp = temp.replaceAll("<", "");
						temp = temp.replaceAll(">", "");
						String temps[] = temp.split(" ");
						for(String str: temps) {
							if(str.contains("configs")) {
								configs = str.replace("configs=", "").trim().matches("[0-9]+") ? Integer.parseInt(str.replace("configs=", "").trim()) : 1;
								config = configs+1;
							}
						}
						
						line = line.replace("configs=\""+configs, "configs=\""+(configs+1));
					}
					
                    if((flag && line.contains("</remote>"))) {
						for(LinkedHashMap.Entry entry: mNewButtons.entrySet()) {
							mContent1 = mContent1 + "\t\t<button name=\""+entry.getKey().toString()+"\" config=\""+config+"\">"+entry.getValue().toString()+"</button>\n";
						}
						
						flag = false;
						added = true;
					}
					
					if((!added && line.contains("</oneremote>"))) {
						mContent1 = mContent1 + "\t<remote name=\""+mName+"\" category=\""+mCategory.trim()+"\" configs=\""+configs+"\">\n";

						for(LinkedHashMap.Entry entry: mNewButtons.entrySet()) {
							mContent1 = mContent1 + "\t\t<button name=\""+entry.getKey().toString()+"\" config=\""+config+"\">"+entry.getValue().toString()+"</button>\n";
						}

						mContent1 = mContent1 + "\t</remote>\n\n";
					}
					
					mContent1 = mContent1 + line + "\n";
				}
			} else {
				mContent1 = "<oneremote>\n\n";
				mContent1 = mContent1 + "\t<remote name=\""+mName+"\" category=\""+mCategory.trim()+"\" configs=\""+configs+"\">\n";
				
				for(LinkedHashMap.Entry entry: mNewButtons.entrySet()) {
					mContent1 = mContent1 + "\t\t<button name=\""+entry.getKey().toString()+"\" config=\""+config+"\">"+entry.getValue().toString()+"</button>\n";
				}

				mContent1 = mContent1 + "\t</remote>\n\n";
				mContent1 = mContent1 + "</oneremote>\n";
			}
			
			FileWriter mWriter = new FileWriter(mFile);

            mWriter.append(mContent1);
            mWriter.flush();
            mWriter.close();

            mPath = mFile.getAbsolutePath();

        } catch (IOException e) {} catch (Exception e) {
            mPath = null;
            Toast.makeText(this,e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return mPath;
	}
	
	private ArrayList GetRemoteListCustom() throws XmlPullParserException, IOException {
        ArrayList mList = new ArrayList();
        LinkedHashMap mMapRemote = null;

        XmlPullParser mParser = XmlPullParserFactory.newInstance().newPullParser();
        mParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        File file = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom/oneremote_custom_codes.dio");
        if(file.exists()) {
            BufferedReader buffReader = new BufferedReader(new FileReader(file.getAbsolutePath()));
            mParser.setInput(buffReader);
        } else {
			return null;
		}

        int eventType = mParser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tag = "remote";
            String element = "";

            switch (eventType) {
                case XmlPullParser.START_DOCUMENT:
                    mList = new ArrayList();

                    break;
                case XmlPullParser.START_TAG:
                    element = mParser.getName();

                    if (element.equals(tag)) {
                        mMapRemote = new LinkedHashMap<>();

                        mMapRemote.put("name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("category", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("configs", mParser.getAttributeValue(null, "configs"));

                        mMapRemote.put("save_name", mParser.getAttributeValue(null, "name"));
                        mMapRemote.put("save_category1", mParser.getAttributeValue(null, "category"));
                        mMapRemote.put("save_config", 1);

                        //if(mCategory.equalsIgnoreCase(mParser.getAttributeValue(null, "category"))) {
                            mList.add(mMapRemote);
                        //}
                    } 
                    break;
                case XmlPullParser.END_TAG:

                    break;
            }

            eventType = mParser.next();
        }

        return mList;
    }
	
	private String RemoveRemoteButtonCustom(String name, String category) {
		String mPath = null;

        try {
            File mRoot = new File(Environment.getExternalStorageDirectory(), Constant.APP_FOLDER_PATH+"/custom");
            if (!mRoot.exists()) {
                mRoot.mkdirs();
            }

			String mContent1 = "";

			int configs = 1;
			int config = 1;
			boolean flag = false;

            File mFile = new File(mRoot, "oneremote_custom_codes.dio");
            if(mFile.exists()) {
				BufferedReader br = new BufferedReader(new FileReader(mFile.getAbsolutePath()));  
				String line;   
				while ((line = br.readLine()) != null) {
					if(line.contains("\""+name+"\"") && line.contains("\""+category+"\"")) {
						flag = true;

					}

					if(!flag) {
						mContent1 = mContent1 + line + "\n";
					}
					
					if(flag && (line.contains("</remote>") || line.contains("</oneremote>"))) {
						flag = false;
					}
					
					FileWriter mWriter = new FileWriter(mFile);

					mWriter.append(mContent1);
					mWriter.flush();
					mWriter.close();

					mPath = mFile.getAbsolutePath();
				}
			} else {
				return null;
			}

        } catch (IOException e) {} catch (Exception e) {
            mPath = null;
            Toast.makeText(this,e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return mPath;
	}
	
	private void ShowAlertButtonDialog(final CustomButtonAdapter adapter, final LinkedHashMap map, final String key, final int position) {
		AlertDialog.Builder mAlertBuilder = new AlertDialog.Builder(CustomActivity.this);
		mAlertBuilder.setTitle("Remote");
		
		final View mDialogLayout = LayoutInflater.from(CustomActivity.this).inflate(R.layout.dialog_content_1, null);
		final TextInputLayout mEditLayout = mDialogLayout.findViewById(R.id.dialog_edittext_layout);
		final TextInputEditText mEditText = mDialogLayout.findViewById(R.id.dialog_edittext);

		mEditLayout.setHint("Raw IR Codes");
		mEditLayout.setHelperText("e.g. 9000,4400,600,500,650,500...");
		mEditText.requestFocus();
		
		if(map.getOrDefault(key, null) != null) {
			mEditText.setText(map.get(key).toString());
		}
		
		mEditText.setKeyListener(DigitsKeyListener.getInstance("0123456789,"));
		
		mAlertBuilder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface p1, int p2) {
					if(map.containsKey(key)) {
						map.put(key, mEditText.getText().toString());
						
						adapter.notifyItemChanged(position);
					}
				}
			});

		mAlertBuilder.setNegativeButton("Cancel", null);
		
		mAlertBuilder.setNeutralButton("Clear", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface p1, int p2) {
					if(map.containsKey(key)) {
						map.put(key, "");

						adapter.notifyItemChanged(position);
					}
				}
			});

		mAlertBuilder.setView(mDialogLayout);
		final AlertDialog mAlert1 = mAlertBuilder.create();

		mEditText.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence p1, int p2, int p3, int p4) {}

				@Override
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4) {
					mAlert1.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!mEditText.getText().toString().isEmpty());
				}

				@Override
				public void afterTextChanged(Editable p1) {}
			});

		mAlert1.show();
		mAlert1.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
	}
	
	private void SaveRemoteToFile() {
		if(checkPermission()) {
			if(!mName.isEmpty() && !mCategory.isEmpty() && mNewButtons.size() != 0) {
				boolean flag = false;
				String button = "";

				for(LinkedHashMap.Entry entry: mNewButtons.entrySet()) {
					if(entry.getValue().toString().isEmpty()) {
						button = entry.getKey().toString();
						flag = true;
						break;
					}
				}

				if(flag) {
					AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
					alertBuild.setTitle("Edit Remote");
					alertBuild.setMessage("Remote \""+button+"\" Key Has No IR Codes Detected. Do You Still Want To Continue?");
					alertBuild.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface p1, int p2) {
								if(GenerateRemoteButtonCodes() != null) {
									mHasChanges = false;
									mIsSaved = true;
									
									Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
									mSnackbar.setText("Remote Codes Successfully Saved.", getResources().getColor(R.color.white));
									mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_circle_check), getResources().getColor(R.color.white));
									mSnackbar.setSnackColor(getResources().getColor(R.color.green_500));
									mSnackbar.show();
								} else {
									Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
									mSnackbar.setText("An Error Occured While Saving Remote Codes.", getResources().getColor(R.color.white));
									mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_cross), getResources().getColor(R.color.white));
									mSnackbar.setSnackColor(getResources().getColor(R.color.red_500));
									mSnackbar.show();
								}
							}
						});
					alertBuild.setNegativeButton("No", null);

					AlertDialog alert = alertBuild.create();
					alert.show();
				} else {
					if(GenerateRemoteButtonCodes() != null) {
						mHasChanges = false;
						mIsSaved = true;
						
						Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
						mSnackbar.setText("Remote Codes Successfully Saved.", getResources().getColor(R.color.white));
						mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_circle_check), getResources().getColor(R.color.white));
						mSnackbar.setSnackColor(getResources().getColor(R.color.green_500));
						mSnackbar.show();
					} else {
						Snackbar mSnackbar = Snackbar.make(mMainLayout, Snackbar.LENGTH_LONG);
						mSnackbar.setText("An Error Occured While Saving Remote Codes.", getResources().getColor(R.color.white));
						mSnackbar.setSnackImage(getResources().getDrawable(R.drawable.ic_cross), getResources().getColor(R.color.white));
						mSnackbar.setSnackColor(getResources().getColor(R.color.red_500));
						mSnackbar.show();
					}
				}
			}
		} else {
			requestPermission();
			mFlag = true;
		}
	}
	
	private void TransmitRemoteSignal(String code) {
		try {
			mIRManager = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
			if (mIRManager.hasIrEmitter()) {                                                
				int frequency = Constant.DEFAULT_IR_FREQUENCY;
				int[] pattern = parsePattern(code);

				if(!code.isEmpty() && pattern != null) {
					mIRManager.transmit(frequency, pattern);

					Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
					mVibe.vibrate(Constant.REMOTE_VIBRATE_LENGTH);
				}
			}
		} catch(Exception e) {
			Toast.makeText(CustomActivity.this, "Error Transmitting IR Signal. ("+ e.getMessage() +")", Toast.LENGTH_SHORT).show();
		}
	}
	
	/*  */
	
	private void ArduinoCommandMonitor(final TextView monitor, final String command, final String button, final CustomButtonAdapter adapter, final LinkedHashMap map, final int position) {
		String intro = "<b>"+getDateTimeLog()+"</b>Arduino IR Decoder<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>@dididiomi<br/><br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>Instructions:<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>1 - Arduino + OTG Is Required.<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>2 - Follow Arduino Board Setup. Check Settings For More Info.<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>3 - Upload Arduino IRDecoder.cpp.hex From The Settings > Upload System.<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>4 - Once Completed, Click Start Button.<br/>";
		intro = intro + "<b>"+getDateTimeLog()+"</b>5 - Select Your Defined Remote Buttons Then Send The IR Signal To Your Arduino IR Receiver.";
		
		if(command.equalsIgnoreCase("/reset")) {
			mPhysicaloid.clearReadListener();
			mPhysicaloid.close();
			mIsMonitorRunning = false;
			mIsMonitorPaused = false;
			
			if(mIsUSBAttached) {
				intro = intro + "<br/><br/><b>"+getDateTimeLog()+"</b>Device: Connected.";
			} else {
				intro = intro + "<br/><br/><b>"+getDateTimeLog()+"</b>Device: Disconnected.";
			}

			monitor.setText(Html.fromHtml(intro));
		} else if(command.equalsIgnoreCase("/start")) {
			String message = "";
			if(!mPhysicaloid.isOpened()) {
				if(mPhysicaloid.open()) {
					mIsMonitorRunning = true;
					mIsMonitorPaused = false;
					
					message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Started.";
				} else {
					if(!mIsUSBAttached) {
						message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Please Connect Your Device.";
					} else {
						message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Unable To Start.";
					}
				}	
			} else {
				message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Started.";
			}

			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/resume")) {
			String message = "";
			if(!mPhysicaloid.isOpened()) {
				if(mPhysicaloid.open()) {
					mIsMonitorRunning = true;
					mIsMonitorPaused = false;
					
					message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Resumed.";
				} else {
					message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Unable To Resume.";
				}	
			} else {
				message = message + "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Resumed.";
			}
			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/stop")) {
			mPhysicaloid.clearReadListener();
			mPhysicaloid.close();
			mIsMonitorRunning = false;
			mIsMonitorPaused = false;
			
			String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Stopped.";
			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/pause")) {
			mPhysicaloid.clearReadListener();
			mPhysicaloid.close();
			mIsMonitorRunning = false;
			mIsMonitorPaused = true;
			
			String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Status: Paused.";
			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/selected")) {
			if(mPhysicaloid.isOpened()) {
				String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Selected: ("+button+") Key<br/>";
				message = message+"<b>"+getDateTimeLog()+"</b>Waiting To Receive IR Signals...";

				monitor.append(Html.fromHtml(message));
				
				mPhysicaloid.clearReadListener();
				mPhysicaloid.addReadListener(new ReadLisener() {
						@Override
						public void onRead(int size) {
							byte[] buf = new byte[size];
							
							mPhysicaloid.read(buf, size);
							try {
								mSerialMessage += new String(buf, "UTF-8");
							} catch (UnsupportedEncodingException e) {}
							
							mHandler.postDelayed(new Runnable() {
									@Override
									public void run() {
										ArduinoCommandMonitor(monitor, "/received", button, adapter, map, 0);
									}
								}, 1500);
						}
					});
			}
		} else if(command.equalsIgnoreCase("/received")) {
			mPhysicaloid.clearReadListener();
			
			mSerialMessage = mSerialMessage.trim();
			mSerialMessage = mSerialMessage.replaceAll("\n", "");
			
			if(!mSerialMessage.isEmpty() && mSerialMessage.length() > 6) {
				if(parsePattern(parseIRCode(mSerialMessage)) != null && mSerialMessage.substring(0,1).equals("*") && mSerialMessage.substring(mSerialMessage.length()-6).equals(",1000*")) {
					mSerialMessage = parseIRCode(mSerialMessage);
					if(map.containsKey(button)) {
						monitor.append(Html.fromHtml("<br/><b>"+getDateTimeLog()+"</b>Signal Successfully Received."));

						map.put(button, mSerialMessage);
						adapter.notifyItemRangeChanged(position, adapter.getItemCount());
					}
				} 
			} 
			
			mSerialMessage = "";
		} else if(command.equalsIgnoreCase("/upload")) {
			SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(CustomActivity.this);
			if(mIsUSBAttached) {
				try {
					String name = mPrefs.getString(Constant.PREF_ARDUINO_BOARD, Constant.ARDUINO_BOARD_NAME[0]);
					Boards board = Boards.ARDUINO_UNO;
					for(int i=0; i<Constant.ARDUINO_BOARD_NAME.length; i++) {
						if(name.equalsIgnoreCase(Constant.ARDUINO_BOARD_NAME[i])) {
							board = Constant.ARDUINO_BOARD_ID[i];
						}
					}

					mPhysicaloid.upload(board, getResources().getAssets().open("oneremote/IRDecoder.cpp.hex"), mArduinoUploadCallback);
				} catch (RuntimeException e) {
				
				} catch (IOException e) {
					
				}
			} else {
				String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Device: Disconnected";
				monitor.append(Html.fromHtml(message));
			}
		} else if(command.equalsIgnoreCase("/message")) {
			String message = "<br/><br/><b>"+getDateTimeLog()+"</b>"+button+"";
			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/attached")) {
			String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Device: Connected.";
			monitor.append(Html.fromHtml(message));
		} else if(command.equalsIgnoreCase("/detached")) {
			String message = "<br/><br/><b>"+getDateTimeLog()+"</b>Device: Disconnected.";
			monitor.append(Html.fromHtml(message));
			
			ArduinoCommandMonitor(monitor, "/stop", button, adapter, map, 0);
		}
		
		
		/*  */
		
		if(mScrollTextMonitor != null) {
			mScrollTextMonitor.post(new Runnable() {
					@Override
					public void run() {
						mScrollTextMonitor.fullScroll(NestedScrollView.FOCUS_DOWN);
					}
				});
		}
	}
	
	private UploadCallBack mArduinoUploadCallback = new UploadCallBack() {
        @Override
        public void onPreUpload() {
            if(mTextMonitor != null) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						String message = "<b>"+getDateTimeLog()+"</b>System Upload<br/>";
						message = message + "<b>"+getDateTimeLog()+"</b>IRDecoder.cpp.hex<br/>";
						message = message + "<b>"+getDateTimeLog()+"</b>@dididiomi<br/><br/>";

						message = message + "<b>"+getDateTimeLog()+"</b>Connecting...<br/>";
						
						mTextMonitor.setText(Html.fromHtml(message));
					}
				});
			}
        }

        @Override
        public void onUploading(final int value) {
            if(mTextMonitor != null) {
				runOnUiThread(new Runnable() {
						@Override
						public void run() {
							String message = "<b>"+getDateTimeLog()+"</b>System Upload<br/>";
							message = message + "<b>"+getDateTimeLog()+"</b>IRDecoder.cpp.hex<br/>";
							message = message + "<b>"+getDateTimeLog()+"</b>@dididiomi<br/><br/>";

							message = message + "<b>"+getDateTimeLog()+"</b>Uploading: ["+value+"%]<br/>";

							mTextMonitor.setText(Html.fromHtml(message));
						}
					});
			}
        }

        @Override
        public void onPostUpload(boolean success) {
            if(success) {
				if(mTextMonitor != null) {
					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								String message = "<b>"+getDateTimeLog()+"</b>System Upload<br/>";
								message = message + "<b>"+getDateTimeLog()+"</b>IRDecoder.cpp.hex<br/>";
								message = message + "<b>"+getDateTimeLog()+"</b>@dididiomi<br/><br/>";

								message = message + "<b>"+getDateTimeLog()+"</b>Uploading: SUCCESS<br/>";

								mTextMonitor.setText(Html.fromHtml(message));
							}
						});
				}
            } else {
                if(mTextMonitor != null) {
					runOnUiThread(new Runnable() {
							@Override
							public void run() {
								String message = "<b>"+getDateTimeLog()+"</b>System Upload<br/>";
								message = message + "<b>"+getDateTimeLog()+"</b>IRDecoder.cpp.hex<br/>";
								message = message + "<b>"+getDateTimeLog()+"</b>@dididiomi<br/><br/>";

								message = message + "<b>"+getDateTimeLog()+"</b>Uploading: FAILED<br/>";

								mTextMonitor.setText(Html.fromHtml(message));
							}
						});
				}
            }
        }

        @Override
        public void onCancel() {
            if(mTextMonitor != null) {
				runOnUiThread(new Runnable() {
						@Override
						public void run() {
							String message = "<b>"+getDateTimeLog()+"</b>Upload Cancelled.<br/>";
							mTextMonitor.append(Html.fromHtml(message));
						}
					});
			}
        }

        @Override
        public void onError(final UploadErrors err) {
            if(mTextMonitor != null) {
				runOnUiThread(new Runnable() {
						@Override
						public void run() {
							String message = "<b>"+getDateTimeLog()+"</b>Upload Error: "+err.toString()+"<br/>";
							mTextMonitor.append(Html.fromHtml(message));
						}
					});
			}
        }
    };
	
	protected void onNewIntent(Intent intent) {
        String action = intent.getAction();

        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
			if(mTextMonitor != null && mCustomButtonAdapter2 != null) {
            	ArduinoCommandMonitor(mTextMonitor,"/attached", "", mCustomButtonAdapter2, mNewButtons, 0);
			}
			
			mIsUSBAttached = true;
        }
    }; 

    private BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
				if(mTextMonitor != null && mCustomButtonAdapter2 != null) {
					ArduinoCommandMonitor(mTextMonitor,"/detached", "", mCustomButtonAdapter2, mNewButtons, 0);
				}
				
				mIsUSBAttached = false;
            }
        }
    };
	
	private boolean checkPermission() {
		int result = ContextCompat.checkSelfPermission(CustomActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
		if (result == PackageManager.PERMISSION_GRANTED) {
			return true;
		} else {
			return false;
		}
	}
	
	private String getDateTimeLog() { 
		DateFormat mDateFormat = new SimpleDateFormat("HH:mm:ss > ");
		Date mDate = new Date(); 
		return mDateFormat.format(mDate); 
	}
	
	private String parseIRCode(String code) {
		char[] chars = code.toCharArray();
		String newCode = "";
		String content = "0123456789,";
		
		for(int i=0; i<chars.length; i++) {
			if(content.contains(chars[i]+"")) {
				newCode += (chars[i]+"");
			}
		}
		
		return newCode;
	}
	
	private int[] parsePattern(String key) {
        try{
			if(!key.isEmpty()) {
				if(key.contains(",")) {
					String[] splitPattern = key.split(",");
					int[] pattern = new int[splitPattern.length];

					for(int i=0; i<splitPattern.length; i++) {
						if(!splitPattern[i].isEmpty()) {
							pattern[i] = Integer.parseInt(splitPattern[i]);
						} else {
							return null;
						}
					}

					return pattern;
				} else {
					return null;
				}
			}
		} catch(Exception e) {
			if(mTextMonitor != null && mCustomButtonAdapter2 != null) {
				ArduinoCommandMonitor(mTextMonitor,"/message", "Error: "+e.getMessage(), mCustomButtonAdapter2, mNewButtons, 0);
				ArduinoCommandMonitor(mTextMonitor,"/message", "Error: "+key, mCustomButtonAdapter2, mNewButtons, 0);
			}
		}

        return null;
    }
	
	private void requestPermission() {
		if (ActivityCompat.shouldShowRequestPermissionRationale(CustomActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
			AlertDialog.Builder alertBuild = new AlertDialog.Builder(CustomActivity.this);
			alertBuild.setTitle("Storage Permission");
			alertBuild.setMessage("Please Allow Write Storage Permission On App Settings To Allow Us Save Your Remote Configurations And Custom Layouts.");
			alertBuild.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2) {
						final Intent intent = new Intent();
						intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
						intent.addCategory(Intent.CATEGORY_DEFAULT);
						intent.setData(Uri.parse("package:" + getPackageName()));
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
						intent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
						startActivity(intent);
					}
				});
			alertBuild.setNegativeButton("Cancel", null);

			AlertDialog alert = alertBuild.create();
			alert.show();
		} else {
			ActivityCompat.requestPermissions(CustomActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
		}
	}
    
    private void setEnabled(ImageView button, boolean state) {
        if(state) {
            button.setEnabled(state);
            button.clearColorFilter();
        } else {
            button.setEnabled(state);
            button.setColorFilter(ContextCompat.getColor(this, R.color.grey_500));
        }
	}
}
