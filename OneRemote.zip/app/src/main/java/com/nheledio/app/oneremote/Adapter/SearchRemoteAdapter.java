package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.nheledio.app.oneremote.Adapter.SearchRemoteAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.RemoteActivity;
import com.nheledio.app.oneremote.UI.FastScrollRecyclerViewInterface;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class SearchRemoteAdapter extends RecyclerView.Adapter<SearchRemoteAdapter.SearchRemoteViewHolder> implements FastScrollRecyclerViewInterface, Filterable {

    private Context mContext;
    private ArrayList mBrands;
	private LinkedHashMap mMapIndex;
	
	private ArrayList mBrandsCopy;

    public SearchRemoteAdapter(Context context, ArrayList brands, LinkedHashMap mapIndex) {

		this.mContext = context;
        this.mBrands = brands;
		this.mMapIndex = mapIndex;
		
		this.mBrandsCopy = brands;
    }

    @Override
    public SearchRemoteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

		View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.remote_select_3, parent, false);
		SearchRemoteViewHolder viewHolder = new SearchRemoteViewHolder(mView);
		
		return viewHolder;
    }

    @Override
    public void onBindViewHolder(SearchRemoteViewHolder holder, final int position) {
        
		if(position == 0) {
			holder.mListTitle.setVisibility(View.VISIBLE);
			holder.mListTitle.setText(((LinkedHashMap)mBrands.get(position)).get("name").toString().substring(0,1).toUpperCase());
		} else {
			if(!((LinkedHashMap)mBrands.get(position)).get("name").toString().substring(0,1).equalsIgnoreCase(((LinkedHashMap)mBrands.get(position-1)).get("name").toString().substring(0,1))) {
				holder.mListTitle.setVisibility(View.VISIBLE);
				holder.mListTitle.setText(((LinkedHashMap)mBrands.get(position)).get("name").toString().substring(0,1).toUpperCase());
			} else {
				holder.mListTitle.setVisibility(View.GONE);
			}										
		}
		
		holder.mListText.setText(((LinkedHashMap)mBrands.get(position)).get("name").toString());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					JSONObject jsonObj = new JSONObject((LinkedHashMap)mBrands.get(position));

                    Intent intent = new Intent(mContext, RemoteActivity.class);
                    intent.putExtra("data", jsonObj.toString());
                    intent.putExtra("mode", RemoteActivity.MODE_SETUP);
                    mContext.startActivity(intent);															
				}
			});
    }
    @Override
    public int getItemCount() {
        return mBrands.size();
    }
	
	@Override
	public LinkedHashMap<String, Integer> getMapIndex() {
		return this.mMapIndex;
	}
	
	@Override
	public Filter getFilter() {
		return new Filter() {
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                mBrands = (ArrayList) results.values;
                notifyDataSetChanged();
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                ArrayList filteredResults = null;
                if (constraint.toString().length() == 0) {
                    filteredResults = mBrandsCopy;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }
        };
    }

	private ArrayList getFilteredResults(String constraint) {
        ArrayList results = new ArrayList<>();

        for (LinkedHashMap item : mBrandsCopy) {
			for(LinkedHashMap.Entry entry: item.entrySet()) {
				if(entry.getKey().toString().equalsIgnoreCase("name")) {
					if (entry.getValue().toString().toLowerCase().contains(constraint.toLowerCase())) {
						results.add(item);
					}
				}
			}    
        }
		
        return results;
	}

    public class SearchRemoteViewHolder extends RecyclerView.ViewHolder {

		private TextView mListTitle;
        private TextView mListText;
        
        public SearchRemoteViewHolder(View itemView) {
            super(itemView);

			mListTitle = itemView.findViewById(R.id.search_list_title_text);
            mListText = itemView.findViewById(R.id.search_list_text);
			
			mListTitle.setVisibility(View.GONE);
        }
    }
}
