package com.nheledio.app.oneremote.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.nheledio.app.oneremote.Adapter.SelectRemoteAdapter;
import com.nheledio.app.oneremote.R;
import com.nheledio.app.oneremote.Utils.Constant;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class SelectRemoteAdapter extends RecyclerView.Adapter<SelectRemoteAdapter.SavedDeviceViewHolder> {

    private Context mContext;
    private ArrayList mSaveRemote;
    
    public SelectRemoteAdapter(Context context, ArrayList saveRemote) {

		this.mContext = context;
        this.mSaveRemote = saveRemote;
	}

    @Override
    public SavedDeviceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

		View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.remote_select_2, parent, false);
		SavedDeviceViewHolder viewHolder = new SavedDeviceViewHolder(mView);

		return viewHolder;
    }

    @Override
    public void onBindViewHolder(SavedDeviceViewHolder holder, final int position) {

		if(position == 0) {
			holder.mListTitle1.setVisibility(View.VISIBLE);
			holder.mListTitle1.setText("IR Remote");
			
			holder.mListTitle2.setVisibility(View.VISIBLE);
			holder.mListTitle2.setText(((LinkedHashMap)mSaveRemote.get(position)).get("save_category2").toString());
		} else {
			if(!((LinkedHashMap)mSaveRemote.get(position)).get("save_category2").toString().equalsIgnoreCase(((LinkedHashMap)mSaveRemote.get(position-1)).get("save_category2").toString())) {
				holder.mListTitle1.setVisibility(View.VISIBLE);
				holder.mListTitle1.setText("IR Remote");
				
				holder.mListTitle2.setVisibility(View.VISIBLE);
				holder.mListTitle2.setText(((LinkedHashMap)mSaveRemote.get(position)).get("save_category2").toString());
			} else {
				holder.mListTitle1.setVisibility(View.GONE);
				holder.mListTitle2.setVisibility(View.GONE);
			}										
		}
		
		holder.mListText.setText(((LinkedHashMap)mSaveRemote.get(position)).get("save_name").toString());
        holder.mListImage.setImageDrawable(mContext.getResources().getDrawable(GetCategotyImageDrawableID(((LinkedHashMap)mSaveRemote.get(position)).get("save_logo").toString())));
    }
	
    @Override
    public int getItemCount() {
        return mSaveRemote.size();
    }
	
	private int GetCategotyImageDrawableID(String category) {
		int drawableID = 0;

		if(!category.isEmpty()) {	
			String[] key = Constant.REMOTE_CATEGORY_NAME;
			int[] res = Constant.REMOTE_CATEGORY_ID;

			for(int i=0; i<key.length; i++) {
				if(category.equalsIgnoreCase(key[i])) {
					drawableID = res[i];
				}
			}	
		}

		return drawableID;
	}

    public class SavedDeviceViewHolder extends RecyclerView.ViewHolder {

		private TextView mListTitle1;
		private TextView mListTitle2;
		private ImageView mListImage;
        private TextView mListText;

        public SavedDeviceViewHolder(View itemView) {
            super(itemView);

			mListTitle1 = itemView.findViewById(R.id.save_list_title_text1);
			mListTitle2 = itemView.findViewById(R.id.save_list_title_text2);
			mListImage = itemView.findViewById(R.id.save_list_image);
            mListText = itemView.findViewById(R.id.save_list_text);

			mListTitle1.setVisibility(View.GONE);
			mListTitle2.setVisibility(View.GONE);
        }
    }
}
