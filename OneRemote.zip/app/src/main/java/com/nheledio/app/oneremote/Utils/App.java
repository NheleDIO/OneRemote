package com.nheledio.app.oneremote.Utils;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import androidx.multidex.MultiDexApplication;
import android.content.res.Configuration;
import androidx.appcompat.app.AppCompatDelegate;

public class App extends MultiDexApplication {

    private static App instance = null;

    public static App getInstance() {
        if(instance == null) {
            instance = new App();
        }
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        
        instance = this;
    } 
}
